
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-2">
        <h4 class="mb-0 font-size-18">Issue</h4>

        <a href="<?php echo e(route('admin.diamonds.index')); ?>" class="btn btn-sm btn-primary">
          <i class="mdi mdi-arrow-right-bold-circle-outline me-1"></i> Diamonds List
        </a>

        <a href="<?php echo e(route('admin.issue.index')); ?>" class="btn btn-sm btn-success">
          <i class="mdi mdi-arrow-left-bold-circle-outline me-1"></i> Issue
        </a>

        <a href="<?php echo e(route('admin.return.index')); ?>" class="btn btn-sm btn-danger">
          <i class="mdi mdi-arrow-left-bold-circle-outline me-1"></i> Return
        </a>
      </div>
    </div>
  </div>
</div>
<!-- end page title -->

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">

        <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('admin.issue.index')); ?>" method="get">
          <?php echo csrf_field(); ?>

          <div data-repeater-list="group-a">
            <div data-repeater-item class="row">
              <div class="col-lg-2">
                <label for="kapans_id">Kapan</label>
                <select name="kapans_id" id="kapans_id" class="form-select" required>
                  <option value="">Select Kapan</option>
                  <?php $__currentLoopData = $kapans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kapan->id); ?>" <?php echo e(request()->kapans_id == $kapan->id ? 'selected' : ''); ?>><?php echo e($kapan->kapan_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('kapans_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('kapans_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="col-lg-3">
                <label for="kapan_parts_id">Kapan Part</label>
                <select name="kapan_parts_id" id="kapan_parts_id" class="form-select">
                  <?php if(request('kapans_id')): ?>
                  <option value="">ALL</option>
                  <?php $__currentLoopData = $kapan_parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapanPa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kapanPa->id); ?>" <?php echo e(request()->kapan_parts_id == $kapanPa->id ? 'selected' : ''); ?>><?php echo e($kapanPa->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <option value="">Select Kapan Part</option>
                  <?php endif; ?>
                </select>
                <?php if($errors->has('kapan_parts_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('kapan_parts_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="col-lg-4">
                <button type="submit" class="btn btn-success mt-2 w-md">Submit</button>
                <!-- <a class="btn btn-light mt-2 w-md" href="/admin/issue">Clear</a> -->
              </div>

            </div>

          </div>
        </form>
      </div>
    </div>

    <?php if(count($diamonds) > 0): ?>
    <div class="card">
      <div class="card-body">

        <?php if($errors->has('kapan_parts_id')): ?>
        <div class="alert alert-danger">
          <?php echo e($errors->first('kapan_parts_id')); ?>

        </div>
        <?php endif; ?>

        <form method="POST" id="storeIssuesKapan" action="<?php echo e(route('admin.issue.store')); ?>">
          <?php echo csrf_field(); ?>

          <div class="row align-items-end mb-4">

            <div class="col-lg-3 col-md-4">
              <label class="form-label fw-semibold">Designation</label>
              <select name="designation_id" id="designation" class="form-select" required>
                <option value="">Select Designation</option>
                <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($des->id); ?>"><?php echo e($des->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-lg-3 col-md-4">
              <label class="form-label fw-semibold">Worker</label>
              <select name="worker_id" id="worker_id" class="form-select" required>
                <option value="">Select Worker</option>
              </select>
            </div>

            <input type="hidden" name="kapans_id" value="<?php echo e(request('kapans_id')); ?>">

            <div class="col-lg-4 col-md-4 d-grid">
              <button type="submit" class="btn btn-success btn-lg">
                <i class="mdi mdi-diamond-stone me-1"></i>
                Issue Selected Diamonds
              </button>
            </div>

          </div>

          <table id="datatable" class="table table-bordered mt-3">
            <thead>
              <tr>
                <th>
                  <input type="checkbox" id="checkAll">
                </th>
                <th>Process</th>
                <th>Name</th>
                <th>Barcode</th>
                <th>Weight</th>
                <th>Pridiction Weight</th>
                <th>Shape</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $diamonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diamond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <input type="checkbox"
                    class="partCheckbox"
                    name="diamonds_id[]"
                    value="<?php echo e($diamond->id); ?>">
                </td>
                <td>
                  <?php if($diamond->issues->count()): ?>
                  <?php $__currentLoopData = $diamond->issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge bg-info me-1">
                    <?php echo e($issue->designation->name); ?>

                  </span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <span class="text-muted">-</span>
                  <?php endif; ?>
                </td>
                <td><?php echo e($diamond->diamond_name); ?></td>
                <td><?php echo e($diamond->barcode_number); ?></td>
                <td><?php echo e($diamond->weight); ?></td>
                <td><?php echo e($diamond->prediction_weight); ?></td>
                <td><?php echo e($diamond->shapes->shape_type); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

        </form>
      </div>
    </div>
    <?php elseif(request()->designation != ''): ?>
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <span class="text-danger">No record found</span>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(document).ready(function() {
    $('#designation').change(function() {
      var designation = $(this).val();
      $('#worker_id').empty();

      if (designation == 'all') {
        $('#worker_id').append('<option value="">Select worker</option>');
      } else if (designation && designation != 'all') {
        $.ajax({
          type: 'POST',
          url: '/admin/get-workers',
          data: {
            '_token': '<?php echo e(csrf_token()); ?>',
            'designation': designation,
          },
          success: function(data) {
            $('#worker_id').append('<option value="">Select worker</option>');
            $.each(data, function(key, value) {
              $('#worker_id').append('<option value="' + value.id + '">' + value.fname + ' ' + value.lname + '</option>');
            });
          }
        });
      } else {
        $('#worker_id').append('<option value="">Select worker</option>');
      }
    });

    $('#kapans_id').change(function() {

      var kapan = $(this).val();
      $('#kapan_parts_id').empty();

      if (!kapan || kapan === 'all') {
        $('#kapan_parts_id').append('<option value="">Select kapan part</option>');
        $('#diamondTable tbody').html('');
        $('#addDiamondBtn').addClass('d-none');
        return;
      }

      $.ajax({
        type: 'POST',
        url: '/admin/get-kapan-parts',
        data: {
          _token: '<?php echo e(csrf_token()); ?>',
          kapans_id: kapan
        },
        success: function(data) {

          $('#kapan_parts_id').append('<option value="">Select kapan part</option>');

          $.each(data, function(index, value) {
            if (value) {
              $('#kapan_parts_id').append(
                '<option value="' + value.id + '">' +
                value.name +
                '</option>'
              );
            }
          });
        }
      });
    });
  });
</script>
<script>
  $('#checkAll').on('change', function() {
    $('.partCheckbox').prop('checked', this.checked);
  });

  $('.partCheckbox').on('change', function() {
    if (!this.checked) {
      $('#checkAll').prop('checked', false);
    }
  });
</script>
<script>
  document.getElementById('storeIssuesKapan').addEventListener('submit', function(e) {

    let checked = document.querySelectorAll('.partCheckbox:checked').length;

    if (checked === 0) {
      alert('Please select at least one diamond to issue');
      e.preventDefault();
    }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/issue/index.blade.php ENDPATH**/ ?>