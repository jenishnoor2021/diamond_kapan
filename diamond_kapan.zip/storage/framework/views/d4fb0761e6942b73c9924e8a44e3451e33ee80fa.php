
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">

                <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card-title">khata Expense List</div>

                <div class="col-12 mb-3">
                    <div class="row">

                        <div class="col-md-6">
                            <div class="card text-white bg-primary">
                                <div class="card-body text-center">
                                    <h6>Total Income Amount</h6>
                                    <h4>₹ <?php echo e(number_format($totalIncomeAmount, 2)); ?></h4>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card text-white bg-danger">
                                <div class="card-body text-center">
                                    <h6>Total Expense Amount</h6>
                                    <h4>₹ <?php echo e(number_format($totalExpenseAmount, 2)); ?></h4>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <table class="table align-items-center table-flush table-borderless">
                    <thead>
                        <tr>
                            <th>Khata Amount</th>
                            <th>Total Bill Amount</th>
                            <th>Expence Amount</th>
                            <th>Remaining Amount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $khatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                        $billAmount = $khata->total_bill_amount ?? 0;
                        $expenseAmount = $khata->total_expense_amount ?? 0;
                        $remaining = $billAmount - $expenseAmount;
                        ?>

                        <tr>
                            <td><?php echo e($khata->fname); ?> - <?php echo e($khata->lname); ?></td>
                            <td>₹ <?php echo e(number_format($billAmount, 2)); ?></td>

                            <td>₹ <?php echo e(number_format($expenseAmount, 2)); ?></td>

                            <td class="<?php echo e($remaining < 0 ? 'text-danger fw-bold' : 'text-success'); ?>">
                                ₹ <?php echo e(number_format($remaining, 2)); ?>

                            </td>
                            <td><a href="<?php echo e(route('admin.expnese.edit.simple', $khata->id)); ?>" class="btn btn-outline-primary waves-effect waves-light"><i class="fa fa-edit"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/expense/index.blade.php ENDPATH**/ ?>