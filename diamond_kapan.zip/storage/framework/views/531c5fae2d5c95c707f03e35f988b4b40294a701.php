
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-2">
        <h4 class="mb-0 font-size-18">Diamonds</h4>

        <a href="<?php echo e(route('admin.diamonds.index')); ?>" class="btn btn-sm btn-primary">
          <i class="mdi mdi-arrow-right-bold-circle-outline me-1"></i> Diamonds List
        </a>

        <a href="<?php echo e(route('admin.issue.index')); ?>" class="btn btn-sm btn-success">
          <i class="mdi mdi-arrow-right-bold-circle-outline me-1"></i> Issue
        </a>

        <a href="<?php echo e(route('admin.return.index')); ?>" class="btn btn-sm btn-danger">
          <i class="mdi mdi-arrow-left-bold-circle-outline me-1"></i> Return
        </a>
      </div>
    </div>
  </div>
</div>
<!-- end page title -->

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">

        <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('admin.diamonds.index')); ?>" method="get">
          <?php echo csrf_field(); ?>

          <div data-repeater-list="group-a">
            <div data-repeater-item class="row">
              <div class="col-lg-2">
                <label for="kapans_id">Kapan</label>
                <select name="kapans_id" id="kapans_id" class="form-select" onchange="this.form.submit();" required>
                  <option value="">Select Kapan</option>
                  <?php $__currentLoopData = $kapans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kapan->id); ?>" <?php echo e(request()->kapans_id == $kapan->id ? 'selected' : ''); ?>><?php echo e($kapan->kapan_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('kapans_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('kapans_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="col-lg-4">
                <!-- <button type="submit" class="btn btn-success mt-2 w-md">List</button> -->
                <a class="btn btn-light mt-2 w-md" href="/admin/diamonds">Clear</a>
              </div>

            </div>

          </div>
        </form>
      </div>
    </div>

    <?php if(count($diamonds) > 0): ?>
    <div class="card">
      <div class="card-body">

        <table id="datatable" class="table table-bordered mt-3">
          <thead>
            <tr>
              <th>Action</th>
              <!-- <th>Kapan</th> -->
              <th>Kapan Part</th>
              <th>Name</th>
              <th>Weight</th>
              <th>Barcode</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $diamonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diamond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <a href="<?php echo e(route('admin.diamond.edit', $diamond->id)); ?>" target="_blank" class="btn btn-outline-primary waves-effect waves-light"><i class="fa fa-edit"></i></a>
                <!-- <a href="<?php echo e(route('admin.diamond.destroy', $diamond->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');" class="btn btn-outline-danger waves-effect waves-light"><i class="fa fa-trash"></i></a> -->
              </td>
              <!-- <td><?php echo e($diamond->kapan->kapan_name ?? '-'); ?></td> -->
              <td><?php echo e($diamond->kapanPart->name ?? '-'); ?></td>
              <td><?php echo e($diamond->diamond_name); ?></td>
              <td><?php echo e(number_format($diamond->weight, 2)); ?></td>
              <td><?php echo e($diamond->barcode_number ?? '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php elseif(request()->kapans_id != ''): ?>
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <span class="text-danger">No record found</span>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(document).ready(function() {
    $('#designation').change(function() {
      var designation = $(this).val();
      $('#worker_id').empty();

      if (designation == 'all') {
        $('#worker_id').append('<option value="">Select worker</option>');
      } else if (designation && designation != 'all') {
        $.ajax({
          type: 'POST',
          url: '/admin/get-workers',
          data: {
            '_token': '<?php echo e(csrf_token()); ?>',
            'designation': designation,
          },
          success: function(data) {
            $('#worker_id').append('<option value="">Select worker</option>');
            $.each(data, function(key, value) {
              $('#worker_id').append('<option value="' + value.id + '">' + value.fname + ' ' + value.lname + '</option>');
            });
          }
        });
      } else {
        $('#worker_id').append('<option value="">Select worker</option>');
      }
    });
  });
</script>
<script>
  $('#checkAll').on('change', function() {
    $('.partCheckbox').prop('checked', this.checked);
  });

  $('.partCheckbox').on('change', function() {
    if (!this.checked) {
      $('#checkAll').prop('checked', false);
    }
  });
</script>
<script>
  document.getElementById('storeIssuesKapan').addEventListener('submit', function(e) {

    let checked = document.querySelectorAll('.partCheckbox:checked').length;

    if (checked === 0) {
      alert('Please select at least one part to issue');
      e.preventDefault();
    }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/diamond/index.blade.php ENDPATH**/ ?>