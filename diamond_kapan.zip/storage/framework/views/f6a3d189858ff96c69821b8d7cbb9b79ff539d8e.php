
<?php $__env->startSection('style'); ?>
    <style>
        /* Add your styling here */
        .accordion {
            display: flex;
            flex-direction: column;
            max-width: 100%;
            margin: 0px 10px;
            /* Adjust as needed */
        }

        .accordion-item {
            border: 1px solid #000;
            margin-bottom: 5px;
            overflow: hidden;
        }

        .accordion-header {
            background-color: transparent;
            padding: 10px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .accordion-content {
            display: none;
            padding: 10px;
        }

        .accordion-arrow {
            transition: transform 0.3s ease-in-out;
        }

        .accordion-item.active .accordion-arrow {
            transform: rotate(180deg);
        }

        .remove-bottom-space {
            margin-bottom: 0px;
        }

        .tox .tox-notification--in {
            opacity: 0 !important;
        }

        .box-body {
            padding: 10px 20px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">Edit Invoice</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Edit Invoice</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Edit</h4>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-check-all me-2"></i>
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-block-helper me-2"></i>
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="accordion">
                        <div class="accordion-item">
                            <div class="accordion-header">
                                <span><b>Invoice and Customer Detail</b></span>
                                <span class="accordion-arrow">&#9658;</span>
                            </div>
                            <div class="accordion-content">

                                <?php echo Form::model($invoice, [
                                    'method' => 'PATCH',
                                    'action' => ['AdminInvoiceController@update', $invoice->id],
                                    'files' => true,
                                    'class' => 'form-horizontal',
                                    'name' => 'editinvoiceform',
                                ]); ?>

                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="parties_id">Party Name</label>
                                            <select name="parties_id" id="parties_id" class="form-select" required>
                                                <option value="">Select Party</option>
                                                <?php $__currentLoopData = $partyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($party->id); ?>"
                                                        <?php echo e($invoice->parties_id == $party->id ? 'selected' : ''); ?>>
                                                        <?php echo e($party->fname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('parties_id')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('parties_id')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="companies_id">Company Name</label>
                                            <select name="companies_id" id="companies_id" class="form-select" required>
                                                <option value="">Select Company</option>
                                                <?php $__currentLoopData = $companyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($company->id); ?>"
                                                        <?php echo e($invoice->companies_id == $company->id ? 'selected' : ''); ?>>
                                                        <?php echo e($company->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('companies_id')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('companies_id')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="invoice_no">Invoice number</label>
                                            <input type="text" name="invoice_no" class="form-control" id="invoice_no"
                                                placeholder="Enter Invoice number" value="<?php echo e($invoice->invoice_no); ?>"
                                                required>
                                            <?php if($errors->has('invoice_no')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('invoice_no')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="invoice_date">Invoice Date</label>
                                            <input type="date" name="invoice_date" class="form-control" id="invoice_date"
                                                placeholder="Enter invoice date" value="<?php echo e($invoice->invoice_date); ?>"
                                                required>
                                            <?php if($errors->has('invoice_date')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('invoice_date')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="place_to_supply">Place To Supply</label>
                                            <input type="text" name="place_to_supply" class="form-control"
                                                id="place_to_supply" placeholder="Enter Place To Supply"
                                                value="<?php echo e($invoice->place_to_supply); ?>" required>
                                            <?php if($errors->has('place_to_supply')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('place_to_supply')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="due_date">due_date</label>
                                            <input type="date" name="due_date" class="form-control"
                                                value="<?php echo e($invoice->due_date); ?>" id="due_date" required>
                                            <?php if($errors->has('due_date')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('due_date')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <button type="submit" class="btn btn-primary w-md">Submit</button>
                                </div>
                                </form>

                            </div>
                        </div>
                    </div>


                    <div class="box-body" id="addInvoiceDetail">

                        <?php echo Form::open([
                            'method' => 'POST',
                            'action' => 'AdminInvoiceController@storeInvoiceData',
                            'files' => true,
                            'class' => 'form-horizontal',
                            'name' => 'addInvoiceDetailForm',
                        ]); ?>

                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="invoice_id" value="<?php echo e($invoice->id); ?>">

                        <div class="row">
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="item" class="control-label">Items :</label>
                                    <input type="text" class="form-control" name="item" id="item"
                                        placeholder="Enter items" required>
                                    <?php if($errors->has('item')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('item')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="hsn_no" class="control-label">HSN Number :</label>
                                    <input type="text" class="form-control" name="hsn_no" id="hsn_no"
                                        placeholder="Enter HSN No" required>
                                    <?php if($errors->has('hsn_no')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('hsn_no')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="tax" class="control-label">Tax:</label>
                                    <input type="text" class="form-control" name="tax" id="tax"
                                        placeholder="Enter Tax" required>
                                    <?php if($errors->has('tax')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('tax')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="quntity" class="control-label">Quntity:</label>
                                    <input type="number" class="form-control" name="quntity" id="quntity"
                                        oninput="calculateAmounts()" placeholder="Enter quntity" required>
                                    <?php if($errors->has('check_in')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('check_in')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="rate" class="control-label">Rate :</label>
                                    <input type="number" class="form-control" name="rate" id="rate"
                                        placeholder="Enter rate" oninput="calculateAmounts()" placeholder="Enter rate"
                                        required>
                                    <?php if($errors->has('rate')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('rate')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="per" class="control-label">per :</label>
                                    <input type="text" class="form-control" name="per" id="per"
                                        placeholder="Enter per" required>
                                    <?php if($errors->has('per')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('per')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="total_amount" class="control-label">Total Amount :</label>
                                    <input type="number" class="form-control" name="total_amount" id="total_amount"
                                        placeholder="Enter Total amout" required>
                                    <?php if($errors->has('total_amount')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('total_amount')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary w-md">Submit</button>
                            <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/invoice')); ?>">Back</a>
                        </div>

                        <?php echo Form::close(); ?>


                    </div>

                    <?php if(count($invoicedatas) > 0): ?>
                        <?php $__currentLoopData = $invoicedatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoicedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="box-body" id="editInvoiceDetail<?php echo e($invoicedata->id); ?>" style="display:none;">

                                <?php echo Form::model($invoicedata, [
                                    'method' => 'PATCH',
                                    'action' => ['AdminInvoiceController@updateInvoiceData', $invoicedata->id],
                                    'files' => true,
                                    'class' => 'form-horizontal',
                                    'name' => 'editInvoiceDataForm',
                                ]); ?>

                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="invoice_id" value="<?php echo e($invoice->id); ?>">

                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="item" class="control-label">Items :</label>
                                            <input type="text" class="form-control" name="item"
                                                id="item<?php echo e($invoicedata->id); ?>" placeholder="Enter items"
                                                value="<?php echo e($invoicedata->item); ?>" required>
                                            <?php if($errors->has('item')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('item')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="hsn_no" class="control-label">HSN Number :</label>
                                            <input type="text" class="form-control" name="hsn_no"
                                                id="hsn_no<?php echo e($invoicedata->id); ?>" placeholder="Enter HSN No"
                                                value="<?php echo e($invoicedata->hsn_no); ?>" required>
                                            <?php if($errors->has('hsn_no')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('hsn_no')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="tax" class="control-label">Tax:</label>
                                            <input type="text" class="form-control" name="tax"
                                                id="tax<?php echo e($invoicedata->id); ?>" placeholder="Enter Tax"
                                                value="<?php echo e($invoicedata->tax); ?>" required>
                                            <?php if($errors->has('tax')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('tax')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="mb-3">
                                            <label for="quntity" class="control-label">Quntity:</label>
                                            <input type="number" class="form-control" name="quntity"
                                                id="quntity<?php echo e($invoicedata->id); ?>"
                                                oninput="editcalculateAmounts(<?php echo e($invoicedata->id); ?>)"
                                                placeholder="Enter quntity" value="<?php echo e($invoicedata->quntity); ?>" required>
                                            <?php if($errors->has('check_in')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('check_in')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="rate" class="control-label">Rate :</label>
                                            <input type="number" class="form-control" name="rate"
                                                id="rate<?php echo e($invoicedata->id); ?>" placeholder="Enter quntity"
                                                oninput="editcalculateAmounts(<?php echo e($invoicedata->id); ?>)"
                                                value="<?php echo e($invoicedata->rate); ?>" placeholder="Enter rate" required>
                                            <?php if($errors->has('rate')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('rate')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="per" class="control-label">per :</label>
                                            <input type="text" class="form-control" name="per"
                                                id="per<?php echo e($invoicedata->id); ?>" placeholder="Enter per"
                                                value="<?php echo e($invoicedata->per); ?>" required>
                                            <?php if($errors->has('per')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('per')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="total_amount" class="control-label">Total Amount :</label>
                                            <input type="number" class="form-control" name="total_amount"
                                                id="total_amount<?php echo e($invoicedata->id); ?>" placeholder="Enter Total amout"
                                                value="<?php echo e($invoicedata->total_amount); ?>" required>
                                            <?php if($errors->has('total_amount')): ?>
                                                <div class="error text-danger"><?php echo e($errors->first('total_amount')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>


                                <div>
                                    <button type="submit" class="btn btn-primary w-md">Update</button>
                                    <a class="btn btn-light w-md" href="javascript::void(0);" onclick="location.reload();">Cancel</a>
                                </div>

                                <?php echo Form::close(); ?>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <div class="box box-info">
                        <div class="box-header with-border ms-3">
                            <a href="<?php echo e(route('admin.invoice.pdf', $invoice->id)); ?>"
                                class="btn btn-outline-warning waves-effect waves-light">Generate Invoice</a>
                            <?php if($invoice->file != ''): ?>
                                <a href="<?php echo e(asset('invoices/' . $invoice->file)); ?>" target="_blank"
                                    class="btn btn-outline-info waves-effect waves-light">View Invoice</a>
                            <?php endif; ?>
                        </div>

                        <div class="box-body">
                            <?php if(count($invoicedatas) > 0): ?>
                                <table id="" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                                    <thead class="bg-primary">
                                        <tr>
                                            <th>Action</th>
                                            <th>Item</th>
                                            <th>Hsn No</th>
                                            <th>Tax</th>
                                            <th>Quntity</th>
                                            <th>Rate</th>
                                            <th>Per</th>
                                            <th>Total Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $invoicedatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoicedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a id="<?php echo e($invoicedata->id); ?>" onclick="editfun(this.id)"
                                                        class="btn btn-outline-primary waves-effect waves-light"><i
                                                            class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(route('admin.invoicedata.destroy', $invoicedata->id)); ?>"
                                                        onclick="return confirm('Sure ! You want to delete ?');"
                                                        class="btn btn-outline-danger waves-effect waves-light"><i
                                                            class="fa fa-trash"></i></a>
                                                </td>
                                                <td><?php echo e($invoicedata->item); ?></td>
                                                <td><?php echo e($invoicedata->hsn_no); ?></td>
                                                <td><?php echo e($invoicedata->tax); ?></td>
                                                <td><?php echo e($invoicedata->quntity); ?></td>
                                                <td><?php echo e($invoicedata->rate); ?></td>
                                                <td><?php echo e($invoicedata->per); ?></td>
                                                <td><?php echo e($invoicedata->total_amount); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="6"></td>
                                            <td>
                                                <h4><b>Total</b></h4>
                                            </td>
                                            <td>
                                                <h4><b><?php echo e($invoice->invoice_total); ?></b></h4>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(function() {
            $("form[name='editinvoiceform']").validate({
                rules: {
                    parties_id: {
                        required: true,
                    },
                    companies_id: {
                        required: true,
                    },
                    invoice_no: {
                        required: true,
                    },
                    invoice_date: {
                        required: true,
                    },
                    place_to_supply: {
                        required: true,
                    },
                    due_date: {
                        required: true,
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
            $("form[name='addInvoiceDetailForm']").validate({
                rules: {
                    item: {
                        required: true,
                    },
                    hsn_no: {
                        required: true,
                    },
                    tax: {
                        required: true,
                    },
                    quntity: {
                        required: true,
                    },
                    rate: {
                        required: true,
                    },
                    per: {
                        required: true,
                    },
                    total_amount: {
                        required: true,
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
            $("form[name='editInvoiceDataForm']").validate({
                rules: {
                    item: {
                        required: true,
                    },
                    hsn_no: {
                        required: true,
                    },
                    tax: {
                        required: true,
                    },
                    quntity: {
                        required: true,
                    },
                    rate: {
                        required: true,
                    },
                    per: {
                        required: true,
                    },
                    total_amount: {
                        required: true,
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });

        $(document).ready(function() {
            // Toggle accordion content and arrow rotation when clicking on the header
            $('.accordion-header').click(function() {
                $(this).parent('.accordion-item').toggleClass('active');
                $(this).find('.accordion-arrow').text(function(_, text) {
                    return text === '►' ? '▼' : '►';
                });
                $(this).next('.accordion-content').slideToggle();
                $(this).parent('.accordion-item').siblings('.accordion-item').removeClass('active').find(
                    '.accordion-content').slideUp();
                $(this).parent('.accordion-item').siblings('.accordion-item').find('.accordion-arrow').text(
                    '►');
            });
        });

        function calculateAmounts() {
            const quntity = parseFloat(document.getElementById('quntity').value) || 0;
            const amount = parseFloat(document.getElementById('rate').value) || 0;

            // Calculate the total amount including GST
            const totalAmount = quntity * amount;

            // Update the total_amount field
            document.getElementById('total_amount').value = totalAmount.toFixed(2);
        }

        function editcalculateAmounts(id) {
            const quntity = parseFloat(document.getElementById('quntity' + id).value) || 0;
            const amount = parseFloat(document.getElementById('rate' + id).value) || 0;

            // Calculate the total amount including GST
            const totalAmount = quntity * amount;

            // Update the total_amount field
            document.getElementById('total_amount' + id).value = totalAmount.toFixed(2);
        }

        function editfun(element) {
            var id = element;
            var div = document.getElementById("editInvoiceDetail" + id);
            var divadd = document.getElementById("addInvoiceDetail");

            <?php $__currentLoopData = $invoicedatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoicedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                document.getElementById('editInvoiceDetail<?php echo e($invoicedata->id); ?>').style.display = 'none';
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            if (div.style.display !== "block") {
                div.style.display = "block";
                divadd.style.display = "none";
            } else {
                div.style.display = "none";
                divadd.style.display = "block";
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/invoice/edit.blade.php ENDPATH**/ ?>