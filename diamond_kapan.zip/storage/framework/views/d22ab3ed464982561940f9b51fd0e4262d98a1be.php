<?php

use App\Models\Dimond;
?>


<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <h4 class="mb-sm-0 font-size-18">DHYANI IMPEX List</h4>

      <!-- <div class="page-title-right">
        <ol class="breadcrumb m-0">
          <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboards</a></li>
          <li class="breadcrumb-item active">DIAMOND</li>
        </ol>
      </div> -->

    </div>
  </div>
</div>
<!-- end page title -->

<div class="row">
  <div class="col-xl-12">
    <div class="card">
      <div class="card-body">
        <a href="/admin/hr-export" class="btn btn-success">Export Slip</a>

        <ul class="nav nav-tabs nav-tabs-custom mt-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#transactions-repair-tab" role="tab">Repair (<?php echo e(count($repairDimonds)); ?>)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#transactions-delivery-tab" role="tab">Delivered (<?php echo e(count($deliveredDimonds)); ?>)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#transactions-complete-tab" role="tab">Completed (<?php echo e(count($completedDimonds)); ?>)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#transactions-processing-tab" role="tab">Processing (<?php echo e(count($processingDimonds)); ?>)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#transactions-pending-tab" role="tab">Pending (<?php echo e(count($pendingDimonds)); ?>)</a>
          </li>
        </ul>

        <div class="tab-content mt-4">
          <div class="tab-pane" id="transactions-repair-tab" role="tabpanel">
            <div class="table-responsive" data-simplebar style="max-height: 330px;">
              <table class="table table-hover datatable dt-responsive nowrap">
                <thead>
                  <tr>
                    <th>Show</th>
                    <th>Party Name</th>
                    <th>Dimond Name</th>
                    <th>Weight</th>
                    <th>Barcode</th>
                    <th>Shap</th>
                    <th>clarity</th>
                    <th>color</th>
                    <th>cut</th>
                    <th>polish</th>
                    <th>symmetry</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $repairDimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repairdimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <?php
                    $dimond = Dimond::where('id', $repairdimond->dimonds_id)->first();
                    ?>
                    <td>
                      <a href="<?php echo e(route('admin.dimond.show', $dimond->barcode_number)); ?>"><i class="fa fa-eye" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                    </td>
                    <td><?php echo e($dimond->parties->party_code); ?></td>
                    <td><?php echo e($dimond->dimond_name); ?></td>
                    <td><?php echo e($dimond->weight); ?></td>
                    <td><?php echo $dimond->barcode_number; ?></td>
                    <td><?php echo e($dimond->shape); ?></td>
                    <td><?php echo e($dimond->clarity); ?></td>
                    <td><?php echo e($dimond->color); ?></td>
                    <td><?php echo e($dimond->cut); ?></td>
                    <td><?php echo e($dimond->polish); ?></td>
                    <td><?php echo e($dimond->symmetry); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="tab-pane" id="transactions-delivery-tab" role="tabpanel">
            <div class="table-responsive" data-simplebar style="max-height: 330px;">
              <table class="table table-hover datatable dt-responsive nowrap">
                <thead>
                  <tr>
                    <th>Repair</th>
                    <!-- <th>Slip</th> -->
                    <th>Party Name</th>
                    <th>Date</th>
                    <th>Dimond Name</th>
                    <th>Weight</th>
                    <th>Barcode</th>
                    <th>Shap</th>
                    <th>clarity</th>
                    <th>color</th>
                    <th>cut</th>
                    <th>polish</th>
                    <th>symmetry</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $deliveredDimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><a href="/admin/repair/<?php echo e($dimond->id); ?>" class="btn btn-info">Repair</a></td>
                    <!-- <td><a href="/admin/print-slipe/<?php echo e($dimond->id); ?>" class="btn btn-primary" target="_blank">Print</a></td> -->
                    <td><?php echo e($dimond->parties->party_code); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($dimond->delevery_date)->format('d-m-Y')); ?></td>
                    <td><?php echo e($dimond->dimond_name); ?></td>
                    <td><?php echo e($dimond->weight); ?></td>
                    <td><?php echo $dimond->barcode_number; ?></td>
                    <td><?php echo e($dimond->shape); ?></td>
                    <td><?php echo e($dimond->clarity); ?></td>
                    <td><?php echo e($dimond->color); ?></td>
                    <td><?php echo e($dimond->cut); ?></td>
                    <td><?php echo e($dimond->polish); ?></td>
                    <td><?php echo e($dimond->symmetry); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="tab-pane active" id="transactions-complete-tab" role="tabpanel">
            <div class="table-responsive" data-simplebar style="max-height: 330px;">
              <table class="table align-middle table-nowrap">
                <thead>
                  <tr>
                    <th>Slip</th>
                    <th>Party Name</th>
                    <th>Dimond Name</th>
                    <th>Weight</th>
                    <th>Barcode</th>
                    <th>Shap</th>
                    <th>clarity</th>
                    <th>color</th>
                    <th>cut</th>
                    <th>polish</th>
                    <th>symmetry</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $completedDimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><a href="/admin/print-slipe/<?php echo e($dimond->id); ?>" class="btn btn-primary" target="_blank">Print</a></td>
                    <td><?php echo e($dimond->parties->party_code); ?></td>
                    <td><?php echo e($dimond->dimond_name); ?></td>
                    <td><?php echo e($dimond->weight); ?></td>
                    <td><?php echo $dimond->barcode_number; ?></td>
                    <td><?php echo e($dimond->shape); ?></td>
                    <td><?php echo e($dimond->clarity); ?></td>
                    <td><?php echo e($dimond->color); ?></td>
                    <td><?php echo e($dimond->cut); ?></td>
                    <td><?php echo e($dimond->polish); ?></td>
                    <td><?php echo e($dimond->symmetry); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="tab-pane" id="transactions-processing-tab" role="tabpanel">
            <div class="table-responsive" data-simplebar style="max-height: 330px;">
              <table class="table align-middle table-nowrap">
                <thead>
                  <tr>
                    <th>Party Name</th>
                    <th>Dimond Name</th>
                    <th>Weight</th>
                    <th>Barcode</th>
                    <th>Shap</th>
                    <th>clarity</th>
                    <th>color</th>
                    <th>cut</th>
                    <th>polish</th>
                    <th>symmetry</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $processingDimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($dimond->parties->party_code); ?></td>
                    <td><?php echo e($dimond->dimond_name); ?></td>
                    <td><?php echo e($dimond->weight); ?></td>
                    <td><?php echo $dimond->barcode_number; ?></td>
                    <td><?php echo e($dimond->shape); ?></td>
                    <td><?php echo e($dimond->clarity); ?></td>
                    <td><?php echo e($dimond->color); ?></td>
                    <td><?php echo e($dimond->cut); ?></td>
                    <td><?php echo e($dimond->polish); ?></td>
                    <td><?php echo e($dimond->symmetry); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="tab-pane" id="transactions-pending-tab" role="tabpanel">
            <div class="table-responsive" data-simplebar style="max-height: 330px;">
              <table class="table align-middle table-nowrap">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Party Name</th>
                    <th>Dimond Name</th>
                    <th>Weight</th>
                    <th>Barcode</th>
                    <th>Shap</th>
                    <th>clarity</th>
                    <th>color</th>
                    <th>cut</th>
                    <th>polish</th>
                    <th>symmetry</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $pendingDimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($dimond->created_at)->format('d-m-Y')); ?></td>
                    <td><?php echo e($dimond->parties->party_code); ?></td>
                    <td><?php echo e($dimond->dimond_name); ?></td>
                    <td><?php echo e($dimond->weight); ?></td>
                    <td><?php echo $dimond->barcode_number; ?></td>
                    <td><?php echo e($dimond->shape); ?></td>
                    <td><?php echo e($dimond->clarity); ?></td>
                    <td><?php echo e($dimond->color); ?></td>
                    <td><?php echo e($dimond->cut); ?></td>
                    <td><?php echo e($dimond->polish); ?></td>
                    <td><?php echo e($dimond->symmetry); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template_github\resources\views/admin/dimond/hrdimond.blade.php ENDPATH**/ ?>