
<?php $__env->startSection('style'); ?>
<style>
   /* Add your styling here */
   .accordion {
      display: flex;
      flex-direction: column;
      max-width: 100%;
      margin: 0px 10px;
      /* Adjust as needed */
   }

   .accordion-item {
      border: 1px solid #000;
      margin-bottom: 5px;
      overflow: hidden;
   }

   .accordion-header {
      background-color: transparent;
      padding: 10px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
   }

   .accordion-content {
      display: none;
      padding: 10px;
   }

   .accordion-arrow {
      transition: transform 0.3s ease-in-out;
   }

   .accordion-item.active .accordion-arrow {
      transform: rotate(180deg);
   }

   .remove-bottom-space {
      margin-bottom: 0px;
   }

   .tox .tox-notification--in {
      opacity: 0 !important;
   }

   .box-body {
      padding: 10px 20px;
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
   <div class="col-lg-12 mx-auto">
      <div class="card">
         <div class="card-body">
            <?php if(session()->has('success')): ?>
            <div class="alert text-white" style="background-color:green">
               <?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
            <div class="alert pl-3 pt-2 pb-2" style="background-color:red;color:#fff;">
               <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>

            <div class="card-title">Edit Invoice</div>

            <div class="accordion p-3">
               <div class="accordion-item">
                  <div class="accordion-header">
                     <span><b>Invoice and Customer Detail</b></span>
                     <span class="accordion-arrow">&#9658;</span>
                  </div>
                  <div class="accordion-content">

                     <?php echo Form::model($invoice, ['method'=>'PATCH', 'action'=> ['AdminInvoiceController@update', $invoice->id],'files'=>true,'class'=>'form-horizontal', 'name'=>'editinvoiceform']); ?>

                     <?php echo csrf_field(); ?>

                     <div class="row">
                        <div class="col-4">
                           <div class="form-group">
                              <label for="parties_id">Party Name</label>
                              <select name="parties_id" id="parties_id" class="custom-select form-control form-control-rounded">
                                 <option value="">Select Party</option>
                                 <?php $__currentLoopData = $partyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($party->id); ?>" <?php echo e($invoice->parties_id == $party->id ? 'selected' : ''); ?>><?php echo e($party->fname); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <?php if($errors->has('parties_id')): ?>
                              <div class="error text-danger"><?php echo e($errors->first('parties_id')); ?></div>
                              <?php endif; ?>
                           </div>
                        </div>
                        <div class="col-4">
                           <div class="form-group">
                              <label for="companies_id">Company Name</label>
                              <select name="companies_id" id="companies_id" class="custom-select form-control form-control-rounded">
                                 <option value="">Select Company</option>
                                 <?php $__currentLoopData = $companyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($company->id); ?>" <?php echo e($invoice->companies_id == $company->id ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <?php if($errors->has('companies_id')): ?>
                              <div class="error text-danger"><?php echo e($errors->first('companies_id')); ?></div>
                              <?php endif; ?>
                           </div>
                        </div>
                        <div class="col-4">
                           <div class="form-group">
                              <label for="invoice_no">Invoice number</label>
                              <input type="text" name="invoice_no" class="form-control form-control-rounded" id="invoice_no" placeholder="Enter Invoice number" value="<?php echo e($invoice->invoice_no); ?>" required>
                              <?php if($errors->has('invoice_no')): ?>
                              <div class="error text-danger"><?php echo e($errors->first('invoice_no')); ?></div>
                              <?php endif; ?>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-4">
                           <div class="form-group">
                              <label for="invoice_date">Invoice Date</label>
                              <input type="date" name="invoice_date" class="form-control form-control-rounded" id="invoice_date" placeholder="Enter invoice date" value="<?php echo e($invoice->invoice_date); ?>" required>
                              <?php if($errors->has('invoice_date')): ?>
                              <div class="error text-danger"><?php echo e($errors->first('invoice_date')); ?></div>
                              <?php endif; ?>
                           </div>
                        </div>
                        <div class="col-4">
                           <div class="form-group">
                              <label for="place_to_supply">Place To Supply</label>
                              <input type="text" name="place_to_supply" class="form-control form-control-rounded" id="place_to_supply" placeholder="Enter Place To Supply" value="<?php echo e($invoice->place_to_supply); ?>" required>
                              <?php if($errors->has('place_to_supply')): ?>
                              <div class="error text-danger"><?php echo e($errors->first('place_to_supply')); ?></div>
                              <?php endif; ?>
                           </div>
                        </div>
                        <div class="col-4">
                           <div class="form-group">
                              <label for="due_date">due_date</label>
                              <input type="date" name="due_date" class="form-control form-control-rounded" id="due_date" value="<?php echo e($invoice->due_date); ?>" required>
                              <?php if($errors->has('due_date')): ?>
                              <div class="error text-danger"><?php echo e($errors->first('due_date')); ?></div>
                              <?php endif; ?>
                           </div>
                        </div>
                     </div>
                     <div class="form-group">
                        <button type="submit" class="btn btn-light btn-round px-5">Update</button>
                     </div>
                     </form>

                  </div>
               </div>
            </div>


            <div class="box-body" id="addInvoiceDetail">

               <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminInvoiceController@storeInvoiceData','files'=>true,'class'=>'form-horizontal', 'name'=>'addInvoiceDetailForm']); ?>

               <?php echo csrf_field(); ?>
               <input type="hidden" name="invoice_id" value="<?php echo e($invoice->id); ?>">

               <div class="form-group row">
                  <div class="col-sm-4">
                     <label for="item" class="control-label">Items :</label>
                     <input type="text" class="form-control" name="item" id="item" placeholder="Enter items" required>
                     <?php if($errors->has('item')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('item')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="hsn_no" class="control-label">HSN Number :</label>
                     <input type="text" class="form-control" name="hsn_no" id="hsn_no" placeholder="Enter HSN No" required>
                     <?php if($errors->has('hsn_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('hsn_no')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="tax" class="control-label">Tax:</label>
                     <input type="text" class="form-control" name="tax" id="tax" placeholder="Enter Tax" required>
                     <?php if($errors->has('tax')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('tax')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="quntity" class="control-label">Quntity:</label>
                     <input type="number" class="form-control" name="quntity" id="quntity" oninput="calculateAmounts()" placeholder="Enter quntity" required>
                     <?php if($errors->has('check_in')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('check_in')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>

               <div class="form-group row">
                  <div class="col-sm-2">
                     <label for="rate" class="control-label">Rate :</label>
                     <input type="number" class="form-control" name="rate" id="rate" placeholder="Enter rate" oninput="calculateAmounts()" placeholder="Enter rate" required>
                     <?php if($errors->has('rate')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('rate')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="per" class="control-label">per :</label>
                     <input type="text" class="form-control" name="per" id="per" placeholder="Enter per" required>
                     <?php if($errors->has('per')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('per')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="total_amount" class="control-label">Total Amount :</label>
                     <input type="number" class="form-control" name="total_amount" id="total_amount" placeholder="Enter Total amout" required>
                     <?php if($errors->has('total_amount')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('total_amount')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-md-3 col-sm-2 control-label">
                     <div class="col-md-3 col-sm-2 control-label">
                        <?php echo Form::submit('Add', ['class'=>'btn btn-success text-white mt-1']); ?>

                     </div>
                  </div>
               </div>
               <?php echo Form::close(); ?>


            </div>

            <?php if(count($invoicedatas)>0): ?>
            <?php $__currentLoopData = $invoicedatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoicedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box-body" id="editInvoiceDetail<?php echo e($invoicedata->id); ?>" style="display:none;">

               <?php echo Form::model($invoicedata, ['method'=>'PATCH', 'action'=> ['AdminInvoiceController@updateInvoiceData', $invoicedata->id],'files'=>true,'class'=>'form-horizontal', 'name'=>'editInvoiceDataForm']); ?>

               <?php echo csrf_field(); ?>
               <input type="hidden" name="invoice_id" value="<?php echo e($invoice->id); ?>">

               <div class="form-group row">
                  <div class="col-sm-4">
                     <label for="item" class="control-label">Items :</label>
                     <input type="text" class="form-control" name="item" id="item<?php echo e($invoicedata->id); ?>" placeholder="Enter items" value="<?php echo e($invoicedata->item); ?>" required>
                     <?php if($errors->has('item')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('item')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="hsn_no" class="control-label">HSN Number :</label>
                     <input type="text" class="form-control" name="hsn_no" id="hsn_no<?php echo e($invoicedata->id); ?>" placeholder="Enter HSN No" value="<?php echo e($invoicedata->hsn_no); ?>" required>
                     <?php if($errors->has('hsn_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('hsn_no')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="tax" class="control-label">Tax:</label>
                     <input type="text" class="form-control" name="tax" id="tax<?php echo e($invoicedata->id); ?>" placeholder="Enter Tax" value="<?php echo e($invoicedata->tax); ?>" required>
                     <?php if($errors->has('tax')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('tax')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="quntity" class="control-label">Quntity:</label>
                     <input type="number" class="form-control" name="quntity" id="quntity<?php echo e($invoicedata->id); ?>" oninput="editcalculateAmounts(<?php echo e($invoicedata->id); ?>)" placeholder="Enter quntity" value="<?php echo e($invoicedata->quntity); ?>" required>
                     <?php if($errors->has('check_in')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('check_in')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>

               <div class="form-group row">
                  <div class="col-sm-2">
                     <label for="rate" class="control-label">Rate :</label>
                     <input type="number" class="form-control" name="rate" id="rate<?php echo e($invoicedata->id); ?>" placeholder="Enter quntity" oninput="editcalculateAmounts(<?php echo e($invoicedata->id); ?>)" value="<?php echo e($invoicedata->rate); ?>" placeholder="Enter rate" required>
                     <?php if($errors->has('rate')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('rate')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="per" class="control-label">per :</label>
                     <input type="text" class="form-control" name="per" id="per<?php echo e($invoicedata->id); ?>" placeholder="Enter per" value="<?php echo e($invoicedata->per); ?>" required>
                     <?php if($errors->has('per')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('per')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-sm-2">
                     <label for="total_amount" class="control-label">Total Amount :</label>
                     <input type="number" class="form-control" name="total_amount" id="total_amount<?php echo e($invoicedata->id); ?>" placeholder="Enter Total amout" value="<?php echo e($invoicedata->total_amount); ?>" required>
                     <?php if($errors->has('total_amount')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('total_amount')); ?></div>
                     <?php endif; ?>
                  </div>
                  <div class="col-md-3 col-sm-2 control-label">
                     <div class="col-md-3 col-sm-2 control-label">
                        <?php echo Form::submit('Add', ['class'=>'btn btn-success text-white mt-1']); ?>

                     </div>
                  </div>
               </div>


               <?php echo Form::close(); ?>


            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>


            <div class="box box-info" style="margin-left:15px; margin-right:15px;">
               <div class="box-header with-border">
                  <a href="<?php echo e(route('admin.invoice.pdf', $invoice->id)); ?>" class="bg-success text-white text-decoration-none" style="padding:8px 12px;margin-left:15px;font-size:20px">Generate Invoice</a>
                  <?php if($invoice->file != ''): ?>
                  <a href="<?php echo e(asset('invoices/'.$invoice->file)); ?>" target="_blank" class="bg-info text-white text-decoration-none" style="padding:8px 12px;margin-left:15px;font-size:20px">View Invoice</a>
                  <?php endif; ?>
               </div>

               <div class="box-body">
                  <?php if(count($invoicedatas)>0): ?>
                  <table id="" class="table table-bordered table-striped">
                     <thead class="bg-primary">
                        <tr>
                           <th>Action</th>
                           <th>Item</th>
                           <th>Hsn No</th>
                           <th>Tax</th>
                           <th>Quntity</th>
                           <th>Rate</th>
                           <th>Per</th>
                           <th>Total Amount</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $invoicedatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoicedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td>
                              <a id="<?php echo e($invoicedata->id); ?>" onclick="editfun(this.id)" style="cursor: pointer;"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);color:blue;padding:8px;"></i></a>
                              <!-- <a href="<?php echo e(route('admin.invoice.editdata', $invoicedata->id)); ?>"><i class="fa fa-edit" style="font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a> -->
                              <a href="<?php echo e(route('admin.invoicedata.destroy', $invoicedata->id)); ?>" onclick="return confirm('Sure ! You want to delete reocrd ?');"><i class="fa fa-trash" style="font-size:15px;background-color:rgba(255, 255, 255, 0.25);color:red;padding:8px;"></i></a>
                           </td>
                           <td><?php echo e($invoicedata->item); ?></td>
                           <td><?php echo e($invoicedata->hsn_no); ?></td>
                           <td><?php echo e($invoicedata->tax); ?></td>
                           <td><?php echo e($invoicedata->quntity); ?></td>
                           <td><?php echo e($invoicedata->rate); ?></td>
                           <td><?php echo e($invoicedata->per); ?></td>
                           <td><?php echo e($invoicedata->total_amount); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td>
                              <h4><b>Total</b></h4>
                           </td>
                           <td>
                              <h4><b><?php echo e($invoice->invoice_total); ?></b></h4>
                           </td>
                        </tr>
                     </tbody>
                  </table>
                  <?php endif; ?>
               </div>
            </div>

         </div>
      </div>
   </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
   $(function() {
      $("form[name='editinvoiceform']").validate({
         rules: {
            parties_id: {
               required: true,
            },
            companies_id: {
               required: true,
            },
            invoice_no: {
               required: true,
            },
            invoice_date: {
               required: true,
            },
            place_to_supply: {
               required: true,
            },
            due_date: {
               required: true,
            },
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
      $("form[name='addInvoiceDetailForm']").validate({
         rules: {
            item: {
               required: true,
            },
            hsn_no: {
               required: true,
            },
            tax: {
               required: true,
            },
            quntity: {
               required: true,
            },
            rate: {
               required: true,
            },
            per: {
               required: true,
            },
            total_amount: {
               required: true,
            },
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
      $("form[name='editInvoiceDataForm']").validate({
         rules: {
            item: {
               required: true,
            },
            hsn_no: {
               required: true,
            },
            tax: {
               required: true,
            },
            quntity: {
               required: true,
            },
            rate: {
               required: true,
            },
            per: {
               required: true,
            },
            total_amount: {
               required: true,
            },
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });

   $(document).ready(function() {
      // Toggle accordion content and arrow rotation when clicking on the header
      $('.accordion-header').click(function() {
         $(this).parent('.accordion-item').toggleClass('active');
         $(this).find('.accordion-arrow').text(function(_, text) {
            return text === '►' ? '▼' : '►';
         });
         $(this).next('.accordion-content').slideToggle();
         $(this).parent('.accordion-item').siblings('.accordion-item').removeClass('active').find('.accordion-content').slideUp();
         $(this).parent('.accordion-item').siblings('.accordion-item').find('.accordion-arrow').text('►');
      });
   });

   function calculateAmounts() {
      const quntity = parseFloat(document.getElementById('quntity').value) || 0;
      const amount = parseFloat(document.getElementById('rate').value) || 0;

      // Calculate the total amount including GST
      const totalAmount = quntity * amount;

      // Update the total_amount field
      document.getElementById('total_amount').value = totalAmount.toFixed(2);
   }

   function editcalculateAmounts(id) {
      const quntity = parseFloat(document.getElementById('quntity' + id).value) || 0;
      const amount = parseFloat(document.getElementById('rate' + id).value) || 0;

      // Calculate the total amount including GST
      const totalAmount = quntity * amount;

      // Update the total_amount field
      document.getElementById('total_amount' + id).value = totalAmount.toFixed(2);
   }

   function editfun(element) {
      var id = element;
      var div = document.getElementById("editInvoiceDetail" + id);
      var divadd = document.getElementById("addInvoiceDetail");

      <?php $__currentLoopData = $invoicedatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoicedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      document.getElementById('editInvoiceDetail<?php echo e($invoicedata->id); ?>').style.display = 'none';
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      if (div.style.display !== "block") {
         div.style.display = "block";
         divadd.style.display = "none";
      } else {
         div.style.display = "none";
         divadd.style.display = "block";
      }
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/invoice/edit.blade.php ENDPATH**/ ?>