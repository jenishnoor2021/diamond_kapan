<?php

use App\Models\WorkerRate;
?>


<?php $__env->startSection('style'); ?>
<style>
   /* Add your styling here */
   .accordion {
      display: flex;
      flex-direction: column;
      max-width: 100%;
      /* Adjust as needed */
   }

   .accordion-item {
      border: 1px solid #ddd;
      margin-bottom: 5px;
      overflow: hidden;
   }

   .accordion-header {
      background-color: transparent;
      padding: 10px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
   }

   .accordion-content {
      display: none;
      padding: 10px;
   }

   .accordion-arrow {
      transition: transform 0.3s ease-in-out;
   }

   .accordion-item.active .accordion-arrow {
      transform: rotate(180deg);
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Worker Rate</h4>
            <div class="card-action">
            </div>
         </div>
         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
         <?php if(session('error')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:red">
            <?php echo e(session('error')); ?>

         </div>
         <?php endif; ?>
         <div class="accordion p-3">
            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion-item">
               <div class="accordion-header">
                  <span><?php echo e($designation->name); ?></span>
                  <span class="accordion-arrow">&#9658;</span>
               </div>
               <div class="accordion-content">
                  <table class="table align-items-center table-flush table-borderless">
                     <thead>
                        <tr>
                           <th>Range</th>
                           <th>Rate</th>
                        </tr>
                     </thead>
                     <?php
                     $workerrates = WorkerRate::where('designation', $designation->name)->get();
                     ?>
                     <tbody>
                        <?php if(count($workerrates) > 0): ?>
                        
                        <?php $__currentLoopData = $workerrates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerrate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workerrate->key == 'key_1'): ?>
                        <tr>
                           <td>1.00 to 1.49</td>
                           <?php echo Form::model($workerrate, ['method'=>'PATCH', 'action'=> ['AdminWorkerRateController@update', $workerrate->id],'files'=>true,'class'=>'form-horizontal']); ?>

                           <?php echo csrf_field(); ?>
                           <td>
                              <input type="text" name="value" value="<?php echo e($workerrate->value); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..?)\../g, '$1');">&nbsp;
                              <button type="submit" class="btn btn-light btn-round px-5">Update</button>
                           </td>
                           </form>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php $__currentLoopData = $workerrates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerrate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workerrate->key == 'key_2'): ?>
                        <tr>
                           <td>1.50 to 1.99</td>
                           <?php echo Form::model($workerrate, ['method'=>'PATCH', 'action'=> ['AdminWorkerRateController@update', $workerrate->id],'files'=>true,'class'=>'form-horizontal']); ?>

                           <?php echo csrf_field(); ?>
                           <td>
                              <input type="text" name="value" value="<?php echo e($workerrate->value); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..?)\../g, '$1');">&nbsp;
                              <button type="submit" class="btn btn-light btn-round px-5">Update</button>
                           </td>
                           </form>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        
                        <?php $__currentLoopData = $workerrates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerrate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workerrate->key == 'key_3'): ?>
                        <tr>
                           <td>2.00 to 2.99</td>
                           <?php echo Form::model($workerrate, ['method'=>'PATCH', 'action'=> ['AdminWorkerRateController@update', $workerrate->id],'files'=>true,'class'=>'form-horizontal']); ?>

                           <?php echo csrf_field(); ?>
                           <td>
                              <input type="text" name="value" value="<?php echo e($workerrate->value); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..?)\../g, '$1');">&nbsp;
                              <button type="submit" class="btn btn-light btn-round px-5">Update</button>
                           </td>
                           </form>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        
                        <?php $__currentLoopData = $workerrates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerrate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workerrate->key == 'key_4'): ?>
                        <tr>
                           <td>3.00 to more</td>
                           <?php echo Form::model($workerrate, ['method'=>'PATCH', 'action'=> ['AdminWorkerRateController@update', $workerrate->id],'files'=>true,'class'=>'form-horizontal']); ?>

                           <?php echo csrf_field(); ?>
                           <td>
                              <input type="text" name="value" value="<?php echo e($workerrate->value); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..?)\../g, '$1');">&nbsp;
                              <button type="submit" class="btn btn-light btn-round px-5">Update</button>
                           </td>
                           </form>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php else: ?>
                        <p> No Data</p>
                        <?php endif; ?>
                     </tbody>
                  </table>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>

      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(document).ready(function() {
      // Toggle accordion content and arrow rotation when clicking on the header
      $('.accordion-header').click(function() {
         $(this).parent('.accordion-item').toggleClass('active');
         $(this).find('.accordion-arrow').text(function(_, text) {
            return text === '►' ? '▼' : '►';
         });
         $(this).next('.accordion-content').slideToggle();
         $(this).parent('.accordion-item').siblings('.accordion-item').removeClass('active').find('.accordion-content').slideUp();
         $(this).parent('.accordion-item').siblings('.accordion-item').find('.accordion-arrow').text('►');
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/workerrate/index.blade.php ENDPATH**/ ?>