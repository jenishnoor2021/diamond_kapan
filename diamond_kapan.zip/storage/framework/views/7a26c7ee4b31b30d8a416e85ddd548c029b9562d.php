
<?php $__env->startSection('style'); ?>
<style>
   /* Add your styling here */
   .accordion {
      display: flex;
      flex-direction: column;
      max-width: 100%;
      /* Adjust as needed */
   }

   .accordion-item {
      border: 1px solid #ddd;
      margin-bottom: 5px;
      overflow: hidden;
   }

   .accordion-header {
      background-color: transparent;
      padding: 10px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
   }

   .accordion-content {
      display: none;
      padding: 10px;
   }

   .accordion-arrow {
      transition: transform 0.3s ease-in-out;
   }

   .accordion-item.active .accordion-arrow {
      transform: rotate(180deg);
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <div class="card-header">
            <h4>Dimond Detail</h4>
            <div class="card-action">
            </div>
         </div>

         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>

         <?php if(session('error')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:red">
            <?php echo e(session('error')); ?>

         </div>
         <?php endif; ?>

         <div class="accordion p-3">
            <div class="accordion-item">
               <div class="accordion-header">
                  <span>Show Dimond Detail</span>
                  <span class="accordion-arrow">&#9658;</span>
               </div>
               <div class="accordion-content">
                  <div class="row p-2">
                     <div class="col-md-6">
                        <table class="table border border-white">
                           <tbody>
                              <tr>
                                 <th>Detail</th>
                              </tr>
                              <tr>
                                 <td class="text-warning">Party Name :</td>
                                 <td><?php echo e($barcodeDetail->parties->party_code); ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning">Dimond Name :</td>
                                 <td><?php echo e($barcodeDetail->dimond_name); ?></td>
                              </tr>
                              <!-- <tr>
                           <td class="text-warning">Dimond barcode :</td>
                           <td><?php echo $barcodeDetail->barcode; ?></td>
                        </tr> -->
                              <tr>
                                 <td class="text-warning">Dimond barcode :</td>
                                 <td>
                                    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
                                    <script>
                                       window.onload = function() {
                                          generateBarcode('<?php echo e($barcodeDetail->barcode_number); ?>');
                                       };
                                    </script>
                                    <svg id="barcode"></svg>
                                 </td>
                              </tr>
                              <tr>
                                 <td class="text-warning">Status :</td>
                                 <td><?php echo e($barcodeDetail->status); ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning">Created At :</td>
                                 <td><?php echo e(\Carbon\Carbon::parse($barcodeDetail->created_at)->format('d-m-Y H:i:s')); ?></td>
                              </tr>
                           </tbody>
                        </table>
                        <br />
                     </div>
                     <div class="col-md-6">
                        <table class="table border border-white">
                           <tbody>
                              <tr>
                                 <th>Parameter</th>
                                 <th>Issue</th>
                                 <th>Final/Return</th>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Row Weight :</strong></td>
                                 <td><?php echo e($barcodeDetail->weight); ?></td>
                                 <td><?= isset($final_result->return_weight) ? $final_result->return_weight : '' ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Polished Weight :</strong></td>
                                 <td><?php echo e($barcodeDetail->required_weight); ?></td>
                                 <td>-</td>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Shape :</strong></td>
                                 <td><?php echo e($barcodeDetail->shape); ?></td>
                                 <td><?= isset($final_result->shape) ? $final_result->shape : '' ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Color :</strong></td>
                                 <td><?php echo e($barcodeDetail->color); ?></td>
                                 <td><?= isset($final_result->r_color) ? $final_result->r_color : '' ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Clarity :</strong></td>
                                 <td><?php echo e($barcodeDetail->clarity); ?></td>
                                 <td><?= isset($final_result->r_clarity) ? $final_result->r_clarity : '' ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Cut :</strong></td>
                                 <td><?php echo e($barcodeDetail->cut); ?></td>
                                 <td><?= isset($final_result->r_cut) ? $final_result->r_cut : '' ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Polish :</strong></td>
                                 <td><?php echo e($barcodeDetail->polish); ?></td>
                                 <td><?= isset($final_result->r_polish) ? $final_result->r_polish : '' ?></td>
                              </tr>
                              <tr>
                                 <td class="text-warning"><strong>Symmetry :</strong></td>
                                 <td><?php echo e($barcodeDetail->symmetry); ?></td>
                                 <td><?= isset($final_result->r_symmetry) ? $final_result->r_symmetry : '' ?></td>
                              </tr>
                           </tbody>
                        </table>
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div class="row">
            <div class="col-md-8">
               <?php if($barcodeDetail->status != 'Completed' && $barcodeDetail->status != 'Delivered'): ?>
               <?php if(!isset($procee_return)): ?>
               <div id="section<?php echo e($barcodeDetail->id); ?>" onclick='addissue(this.id)' style="cursor: pointer;padding-left: 1rem;padding-bottom:1rem;"><i style="color:white;font-size:15px;background-color:green;padding:8px;">Issues</i></div>
               <?php else: ?>
               <div id="editButton<?php echo e($procee_return->id); ?>" onclick='editfun(this)' data-id="<?php echo e($procee_return->id); ?>" style="cursor: pointer; padding-left: 1rem;padding-bottom:1rem;" style="margin-left:10px;cursor: pointer;"><i style="color:white;font-size:15px;background-color:red;padding:8px;">Return</i></div>
               <?php endif; ?>
               <?php endif; ?>
            </div>
         </div>

         <div id="createsection<?php echo e($barcodeDetail->id); ?>" style="display:none;padding:1rem;">
            <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminProcessController@store','files'=>true,'class'=>'form-horizontal']); ?>

            <?php echo csrf_field(); ?>
            <input type="hidden" name="dimonds_id" value="<?php echo e($barcodeDetail->id); ?>">
            <input type="hidden" name="dimonds_barcode" value="<?php echo e($barcodeDetail->barcode_number); ?>">
            <?php if(count($processes) == 0): ?>
            <input type="hidden" name="issue_weight" value="<?php echo e($barcodeDetail->weight); ?>">
            <?php else: ?>
            <input type="hidden" name="issue_weight" value="<?php echo e($lastweight->return_weight); ?>">
            <?php endif; ?>
            <div class="row form-group" style="margin-top:15px;">
               <div class="col-sm-2">
                  <label for="designation">Designation</label>
                  <select name="designation" id="designation" class="custom-select form-control form-control-rounded" required>
                     <option value="">Select designation</option>
                     <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($designation->name); ?>"><?php echo e($designation->name); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
               </div>
               <div class="col-sm-2">
                  <label for="worker_name">Worker</label>
                  <select name="worker_name" id="worker_name" class="custom-select form-control form-control-rounded" required>
                     <option value="">Select worker</option>
                  </select>
               </div>
               <div class="col-sm-2">
                  <label for="issue_date">Issue Date</label>
                  <input type="datetime-local" name="issue_date" class="form-control form-control-rounded" id="issue_date" required>
               </div>
               <div class="col-sm-1">
                  <div class="form-group">
                     <button type="submit" class="btn btn-light btn-round px-5">Save</button>
                  </div>
               </div>
            </div>
            <?php echo Form::close(); ?>

         </div>

         <?php if(count($processes)>0): ?>
         <?php $__currentLoopData = $processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div id="editsection<?php echo e($process->id); ?>" style="display:none;padding:1rem;">
            <?php echo Form::open(['method'=>'post', 'action'=> 'AdminProcessController@update','files'=>true,'class'=>'form-horizontal']); ?>

            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="id<?php echo e($process->id); ?>" value="">
            <input type="hidden" name="dimonds_id" id="dimonds_id<?php echo e($process->id); ?>" value="">
            <input type="hidden" name="dimonds_barcode" id="dimonds_barcode<?php echo e($process->id); ?>" value="">
            <div class="row form-group" style="margin-top:15px;">
               <div class="col-sm-2">
                  <label for="designation">Designation</label>
                  <input type="text" name="designation" class="form-control form-control-rounded" id="designatio<?php echo e($process->id); ?>" value="" disabled>
               </div>
               <div class="col-sm-2">
                  <label for="worker_name">Worker</label>
                  <input type="text" name="worker_name" class="form-control form-control-rounded" id="worker_nam<?php echo e($process->id); ?>" value="" disabled>
               </div>
               <div class="col-sm-2">
                  <label for="return_date">return Date</label>
                  <input type="datetime-local" name="return_date" class="form-control form-control-rounded" id="return_dat<?php echo e($process->id); ?>" value="">
               </div>
               <div class="col-sm-2">
                  <label for="return_weight">return weight</label>
                  <input type="text" name="return_weight" class="form-control form-control-rounded" id="return_weigh<?php echo e($process->id); ?>" placeholder="00.00" oninput="formatWeight(this);" value="">
               </div>
               <label>
                  <input type="checkbox" name="ratecut" id="ratecut<?php echo e($process->id); ?>">
                  RateCut
               </label>
            </div>

            <?php if($process->designation == 'Grading'): ?>
            <div class="row">
               <div class="col-2">
                  <div class="form-group">
                     <label for="r_shape">Shape</label>
                     <input type="text" name="r_shape" class="form-control form-control-rounded" value="<?php echo e($barcodeDetail->shape); ?>" disabled>
                     <!-- <select name="r_shape" id="r_shape<?php echo e($process->id); ?>" class="custom-select form-control-rounded" style="width:100%">
                        <option value="">Select shape</option>
                        <option value="Round">Round</option>
                        <option value="Oval">Oval</option>
                        <option value="Pear">Pear</option>
                        <option value="Cush Mod">Cush Mod</option>
                        <option value="Cush Brill">Cush Brill</option>
                        <option value="Emeraid">Emeraid</option>
                        <option value="Radiant">Radiant</option>
                        <option value="Princess">Princess</option>
                        <option value="Asscher">Asscher</option>
                        <option value="Square">Square</option>
                        <option value="Marquise">Marquise</option>
                        <option value="Heart">Heart</option>
                        <option value="Trilliant">Trilliant</option>
                        <option value="Euro Cut">Euro Cut</option>
                        <option value="Old Miner">Old Miner</option>
                        <option value="Briolette">Briolette</option>
                     </select> -->
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="r_clarity">Clarity</label>
                     <select name="r_clarity" id="r_clarity" class="custom-select form-control-rounded">
                        <option value="" <?php echo e($barcodeDetail->clarity == '' ? 'selected' : ''); ?>>Select clarity</option>
                        <option value="FL" <?php echo e($barcodeDetail->clarity == 'FL' ? 'selected' : ''); ?>>FL</option>
                        <option value="IF" <?php echo e($barcodeDetail->clarity == 'IF' ? 'selected' : ''); ?>>IF</option>
                        <option value="VVS1" <?php echo e($barcodeDetail->clarity == 'VVS1' ? 'selected' : ''); ?>>VVS1</option>
                        <option value="VVS2" <?php echo e($barcodeDetail->clarity == 'VVS2' ? 'selected' : ''); ?>>VVS2</option>
                        <option value="VS1" <?php echo e($barcodeDetail->clarity == 'VS1' ? 'selected' : ''); ?>>VS1</option>
                        <option value="VS2" <?php echo e($barcodeDetail->clarity == 'VS2' ? 'selected' : ''); ?>>VS2</option>
                        <option value="SI1" <?php echo e($barcodeDetail->clarity == 'SI1' ? 'selected' : ''); ?>>SI1</option>
                        <option value="SI2" <?php echo e($barcodeDetail->clarity == 'SI2' ? 'selected' : ''); ?>>SI2</option>
                        <option value="SI3" <?php echo e($barcodeDetail->clarity == 'SI3' ? 'selected' : ''); ?>>SI3</option>
                        <option value="I1" <?php echo e($barcodeDetail->clarity == 'I1' ? 'selected' : ''); ?>>I1</option>
                        <option value="I2" <?php echo e($barcodeDetail->clarity == 'I2' ? 'selected' : ''); ?>>I2</option>
                        <option value="I3" <?php echo e($barcodeDetail->clarity == 'I3' ? 'selected' : ''); ?>>I3</option>
                     </select>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="r_color">Color</label>
                     <select name="r_color" id="r_color" class="custom-select form-control-rounded">
                        <option value="" <?php echo e($barcodeDetail->color == '' ? 'selected' : ''); ?>>Select color</option>
                        <option value="D" <?php echo e($barcodeDetail->color == 'D' ? 'selected' : ''); ?>>D</option>
                        <option value="E" <?php echo e($barcodeDetail->color == 'E' ? 'selected' : ''); ?>>E</option>
                        <option value="F" <?php echo e($barcodeDetail->color == 'F' ? 'selected' : ''); ?>>F</option>
                        <option value="G" <?php echo e($barcodeDetail->color == 'G' ? 'selected' : ''); ?>>G</option>
                        <option value="H" <?php echo e($barcodeDetail->color == 'H' ? 'selected' : ''); ?>>H</option>
                        <option value="I" <?php echo e($barcodeDetail->color == 'I' ? 'selected' : ''); ?>>I</option>
                        <option value="J" <?php echo e($barcodeDetail->color == 'J' ? 'selected' : ''); ?>>J</option>
                        <option value="K" <?php echo e($barcodeDetail->color == 'K' ? 'selected' : ''); ?>>K</option>
                        <option value="L" <?php echo e($barcodeDetail->color == 'L' ? 'selected' : ''); ?>>L</option>
                        <option value="M" <?php echo e($barcodeDetail->color == 'M' ? 'selected' : ''); ?>>M</option>
                        <option value="N" <?php echo e($barcodeDetail->color == 'N' ? 'selected' : ''); ?>>N</option>
                        <option value="O" <?php echo e($barcodeDetail->color == 'O' ? 'selected' : ''); ?>>O</option>
                        <option value="P" <?php echo e($barcodeDetail->color == 'P' ? 'selected' : ''); ?>>P</option>
                        <option value="Q" <?php echo e($barcodeDetail->color == 'Q' ? 'selected' : ''); ?>>Q</option>
                        <option value="R" <?php echo e($barcodeDetail->color == 'R' ? 'selected' : ''); ?>>R</option>
                        <option value="S" <?php echo e($barcodeDetail->color == 'S' ? 'selected' : ''); ?>>S</option>
                     </select>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="r_cut">Cut</label>
                     <select name="r_cut" id="r_cut" class="custom-select form-control-rounded">
                        <option value="" <?php echo e($barcodeDetail->cut == '' ? 'selected' : ''); ?>>Select cut</option>
                        <option value="Ideal" <?php echo e($barcodeDetail->cut == 'Ideal' ? 'selected' : ''); ?>>Ideal</option>
                        <option value="EX" <?php echo e($barcodeDetail->cut == 'EX' ? 'selected' : ''); ?>>EX</option>
                        <option value="VG" <?php echo e($barcodeDetail->cut == 'VG' ? 'selected' : ''); ?>>VG</option>
                        <option value="GD" <?php echo e($barcodeDetail->cut == 'GD' ? 'selected' : ''); ?>>GD</option>
                     </select>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="r_polish">Polish</label>
                     <select name="r_polish" id="r_polish" class="custom-select form-control-rounded">
                        <option value="" <?php echo e($barcodeDetail->polish == '' ? 'selected' : ''); ?>>Select polish</option>
                        <option value="Ideal" <?php echo e($barcodeDetail->polish == 'Ideal' ? 'selected' : ''); ?>>Ideal</option>
                        <option value="EX" <?php echo e($barcodeDetail->polish == 'EX' ? 'selected' : ''); ?>>EX</option>
                        <option value="VG" <?php echo e($barcodeDetail->polish == 'VG' ? 'selected' : ''); ?>>VG</option>
                        <option value="GD" <?php echo e($barcodeDetail->polish == 'GD' ? 'selected' : ''); ?>>GD</option>
                     </select>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="r_symmetry">Symmetry</label>
                     <select name="r_symmetry" id="r_symmetry" class="custom-select form-control-rounded">
                        <option value="" <?php echo e($barcodeDetail->symmetry == '' ? 'selected' : ''); ?>>Select symmetry</option>
                        <option value="Ideal" <?php echo e($barcodeDetail->symmetry == 'Ideal' ? 'selected' : ''); ?>>Ideal</option>
                        <option value="EX" <?php echo e($barcodeDetail->symmetry == 'EX' ? 'selected' : ''); ?>>EX</option>
                        <option value="VG" <?php echo e($barcodeDetail->symmetry == 'VG' ? 'selected' : ''); ?>>VG</option>
                        <option value="GD" <?php echo e($barcodeDetail->symmetry == 'GD' ? 'selected' : ''); ?>>GD</option>
                     </select>
                  </div>
               </div>
            </div>
            <?php endif; ?>

            <div class="col-sm-1">
               <div class="form-group">
                  <button type="submit" class="btn btn-light btn-round px-5">update</button>
               </div>
            </div>

            <?php echo Form::close(); ?>

         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>

         <?php if(count($processes)>0): ?>
         <div class="table-responsive">
            <table class="table align-items-center table-flush table-borderless">
               <thead>
                  <tr>
                     <?php if($barcodeDetail->status != 'Delivered'): ?>
                     <th>Action</th>
                     <?php endif; ?>
                     <th>Designation</th>
                     <th>Worker</th>
                     <th>Issues date</th>
                     <th>return date</th>
                     <th>Issues weight</th>
                     <th>return weight</th>
                     <th>Price</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php $__currentLoopData = $processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($barcodeDetail->status != 'Delivered'): ?>
                     <td>
                        <a id="editButton<?php echo e($process->id); ?>" onclick="editfun(this)" data-id="<?php echo e($process->id); ?>" style="cursor: pointer;"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                        <!-- <a href="<?php echo e(route('admin.process.edit', $process->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a> -->
                        <a href="<?php echo e(route('admin.process.destroy', $process->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                     </td>
                     <?php endif; ?>
                     <td><?php echo e($process->designation); ?></td>
                     <td><?php echo e($process->worker_name); ?></td>
                     <td><?php echo e(\Carbon\Carbon::parse($process->issue_date)->format('d-m-Y')); ?></td>
                     <td><?php echo e(\Carbon\Carbon::parse($process->return_date)->format('d-m-Y')); ?></td>
                     <td><?php echo e($process->issue_weight); ?></td>
                     <td><?php echo e($process->return_weight); ?></td>
                     <td><?php echo e($process->price); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
         <?php endif; ?>

      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   function addissue(cli_id) {
      var div = document.getElementById("create" + cli_id);
      if (div.style.display !== "block") {
         div.style.display = "block";
      } else {
         div.style.display = "none";
      }
   }

   function todaydatetime() {
      var currentDate = new Date();
      // Get today's date in the format "YYYY-MM-DD"
      var today = currentDate.toISOString().split('T')[0];
      var hours = currentDate.getHours();
      var minutes = currentDate.getMinutes();

      // Format hours and minutes as "HH:mm"
      var formattedTime = ('0' + hours).slice(-2) + ':' + ('0' + minutes).slice(-2);

      // Concatenate date and time in the expected format
      var formattedDateTime = today + ' ' + formattedTime;
      return formattedDateTime;
   }

   document.addEventListener('DOMContentLoaded', function() {
      document.getElementById('issue_date').value = todaydatetime();
   });

   $(document).ready(function() {
      $('#designation').change(function() {
         var designation = $(this).val();
         if (designation) {
            $.ajax({
               type: 'POST',
               url: '/admin/get-workers',
               data: {
                  '_token': '<?php echo e(csrf_token()); ?>',
                  'designation': designation,
                  'dimond_id': <?= $barcodeDetail->id ?>
               },
               success: function(data) {
                  $('#worker_name').empty();
                  $.each(data, function(key, value) {
                     $('#worker_name').append('<option value="' + value.fname + '">' + value.fname + ' ' + value.lname + '</option>');
                  });
               }
            });
         } else {
            $('#worker_name').empty();
         }
      });
      $('input[type="checkbox"]').on('change', function() {
         // If checkbox is unchecked, set its value to 0
         if (!$(this).prop('checked')) {
            $(this).val(0);
         } else {
            $(this).val(1);
         }
      });
   });
</script>
<script>
   function editfun(element) {
      var id = element.getAttribute('data-id');
      var div = document.getElementById("editsection" + id);

      if (div.style.display !== "block") {
         div.style.display = "block";
      } else {
         div.style.display = "none";
      }
      $.ajax({
         url: '/admin/process/edit/' + id,
         type: 'GET',
         dataType: 'json',
         success: function(response) {
            $('#id' + id).val(response.data.id);
            $('#designatio' + id).val(response.data.designation);
            $('#worker_nam' + id).val(response.data.worker_name);
            $('#dimonds_barcode' + id).val(response.data.dimonds_barcode);
            $('#dimonds_id' + id).val(response.data.dimonds_id);
            $('#issue_dat' + id).val(response.data.issue_date);
            $('#issue_weigh' + id).val(response.data.issue_weight);
            $('#return_weigh' + id).val(response.data.return_weight);
            $('#r_shape' + id).val(response.data.r_shape);
            $('#r_clarity' + id).val(response.data.r_clarity);
            $('#r_color' + id).val(response.data.r_color);
            $('#r_cut' + id).val(response.data.r_cut);
            $('#r_polish' + id).val(response.data.r_polish);
            $('#r_symmetry' + id).val(response.data.r_symmetry);
            $('#ratecut' + id).prop('checked', response.data.ratecut == 1);

            if (response.data.return_date == null) {
               document.getElementById('return_dat' + id).value = todaydatetime();
            } else {
               $('#return_dat' + id).val(response.data.return_date);
            }

         },
         error: function(error) {
            console.error('Ajax request failed: ' + error.responseText);
         }
      });
      $('#designatio' + id).change(function() {
         var designation = $(this).val();
         if (designation) {
            $.ajax({
               type: 'POST',
               url: '/admin/get-workers',
               data: {
                  '_token': '<?php echo e(csrf_token()); ?>',
                  'designation': designation
               },
               success: function(data) {
                  $('#worker_nam' + id).empty();
                  $.each(data, function(key, value) {
                     $('#worker_nam' + id).append('<option value="' + value.fname + '">' + value.fname + ' ' + value.lname + '</option>');
                  });
               }
            });
         } else {
            $('#worker_nam' + id).empty();
         }
      });
   }
</script>
<script>
   function formatWeight(input) {
      // Remove any non-numeric characters
      var cleanedValue = input.value.replace(/[^0-9.]/g, '');

      // Ensure valid pattern: either empty, '0.00', or '00.00'
      var match = cleanedValue.match(/^(\d{0,2}(\.\d{0,2})?)?$/);

      // Update the input value with the formatted result
      input.value = match ? match[1] || '' : '';
   }
</script>
<script>
   $(document).ready(function() {
      // Capture the change event of the dropdown
      $('#status').on('change', function() {
         // Trigger form submission when the dropdown changes
         $('#myForm').submit();
      });
   });
</script>
<script>
   function generateBarcode(value) {
      JsBarcode("#barcode", value, {
         format: "CODE128",
         displayValue: true,
      });
   }
</script>
<script>
   $(document).ready(function() {
      // Toggle accordion content and arrow rotation when clicking on the header
      $('.accordion-header').click(function() {
         $(this).parent('.accordion-item').toggleClass('active');
         $(this).find('.accordion-arrow').text(function(_, text) {
            return text === '►' ? '▼' : '►';
         });
         $(this).next('.accordion-content').slideToggle();
         $(this).parent('.accordion-item').siblings('.accordion-item').removeClass('active').find('.accordion-content').slideUp();
         $(this).parent('.accordion-item').siblings('.accordion-item').find('.accordion-arrow').text('►');
      });
   });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/dimond/show.blade.php ENDPATH**/ ?>