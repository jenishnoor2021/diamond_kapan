
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
   <div class="col-lg-8 mx-auto">
      <div class="card">
         <div class="card-body">
            <?php if(session()->has('message')): ?>
            <div class="alert text-white" style="background-color:green">
               <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card-title">Edit Designation</div>
            <hr>
            <?php echo Form::model($designation, ['method'=>'PATCH', 'action'=> ['AdminDesignationController@update', $designation->id],'files'=>true,'class'=>'form-horizontal','name'=>'editdesignationform']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="category">Designation Category</label>
                     <select name="category" id="category" class="custom-select form-control form-control-rounded" style="width:100%" required>
                        <option value="">Select category</option>
                        <option value="Inner" <?php echo e($designation->category == 'Inner' ? 'selected' : ''); ?>>Inner</option>
                        <option value="Outter" <?php echo e($designation->category == 'Outter' ? 'selected' : ''); ?>>Outter</option>
                     </select>
                     <?php if($errors->has('category')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('category')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="name">Designation Name</label>
                     <input type="text" name="name" class="form-control form-control-rounded" id="name" placeholder="Enter First name" onkeypress='return (event.charCode != 32)' value="<?php echo e($designation->name); ?>">
                     <?php if($errors->has(' name')): ?> <div class="error text-danger"><?php echo e($errors->first('name')); ?>

                     </div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="rate_apply_on">Rate Calculate On</label>
                     <select name="rate_apply_on" id="rate_apply_on" class="custom-select form-control form-control-rounded" style="width:100%" required>
                        <option value="">Select weight</option>
                        <option value="issue_weight" <?php echo e($designation->rate_apply_on == 'issue_weight' ? 'selected' : ''); ?>>Issue weight</option>
                        <option value="return_weight" <?php echo e($designation->rate_apply_on == 'return_weight' ? 'selected' : ''); ?>>Return weight</option>
                        <option value="diff_weight" <?php echo e($designation->rate_apply_on == 'diff_weight' ? 'selected' : ''); ?>>Diffrence weight</option>
                     </select>
                     <?php if($errors->has('rate_apply_on')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('rate_apply_on')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="form-group">
               <button type="submit" class="btn btn-light btn-round px-5">Update</button>
            </div>
            </form>
         </div>
      </div>
   </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editdesignationform']").validate({
         rules: {
            name: {
               required: true,
            },
            category: {
               required: true,
            }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/foobbshh/public_html/diamondhr/resources/views/admin/designation/edit.blade.php ENDPATH**/ ?>