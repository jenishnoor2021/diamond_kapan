
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Direct Issues Return</h4>

            <!-- <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                    <li class="breadcrumb-item active">Direct Issues Return</li>
                </ol>
            </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-xl-12">
        <div class="row">

            <div class="col-md-2">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-muted fw-medium">Total</p>
                                <h4 class="mb-0"><?php echo e($dimondcount); ?></h4>
                            </div>

                            <div class="flex-shrink-0 align-self-center">
                                <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                    <span class="avatar-title">
                                        <i class="bx bx-copy-alt font-size-24"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-2">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-muted fw-medium">Pending</p>
                                <h4 class="mb-0"><?php echo e($pendingcount); ?></h4>
                            </div>

                            <div class="flex-shrink-0 align-self-center">
                                <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                    <span class="avatar-title">
                                        <i class="bx bx-copy-alt font-size-24"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-2">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-muted fw-medium">Processing</p>
                                <h4 class="mb-0"><?php echo e($outercount + $issuecount); ?></h4>
                            </div>

                            <div class="flex-shrink-0 align-self-center">
                                <div class="avatar-sm rounded-circle bg-primary mini-stat-icon">
                                    <span class="avatar-title rounded-circle bg-primary">
                                        <i class="bx bx-purchase-tag-alt font-size-24"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-2">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-muted fw-medium">Inner</p>
                                <h4 class="mb-0"><?php echo e($issuecount); ?></h4>
                            </div>

                            <div class="flex-shrink-0 align-self-center ">
                                <div class="avatar-sm rounded-circle bg-primary mini-stat-icon">
                                    <span class="avatar-title rounded-circle bg-primary">
                                        <i class="bx bx-archive-in font-size-24"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-2">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-muted fw-medium">Outter</p>
                                <h4 class="mb-0"><?php echo e($outercount); ?></h4>
                            </div>

                            <div class="flex-shrink-0 align-self-center">
                                <div class="avatar-sm rounded-circle bg-primary mini-stat-icon">
                                    <span class="avatar-title rounded-circle bg-primary">
                                        <i class="bx bx-purchase-tag-alt font-size-24"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- end row -->
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-block-helper me-2"></i>
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <div id="right">
                    <div id="menu" class="mb-3">

                        <span id="menu-navi"
                            class="d-sm-flex flex-wrap text-center text-sm-start justify-content-sm-between">
                            <div class="">
                                <h4 class="render-range fw-bold pt-1 mx-3">
                                    <h5><span class="text-warning">Count:</span> <?php echo e($scancount); ?></h5>
                                </h4>
                            </div>

                            <div>
                                <form method="POST" action="<?php echo e(route('admin.daily-status.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" id="inputField2" name="inputField" class="form-control" placeholder="Search barcode" required>
                                </form>
                            </div>

                            <div class="align-self-start mt-3 mt-sm-0 mb-2">
                                <a href="/admin/daily-status/refresh" class="btn btn-primary text-white">
                                    <i class="fas fa-sync"></i>
                                </a>
                            </div>
                        </span>

                    </div>
                </div>

                <table id="dailytable" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Dimond Name</th>
                            <th>Barcode</th>
                            <th>Date</th>
                            <!-- <th>Stage</th> -->
                            <th>Current Status</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $dailys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.dimond.show', $dimond->barcode)); ?>" class="btn btn-info"><i
                                        class="fa fa-eye"></i></a>
                                
                            </td>
                            <td><?php echo e($dimond->dimonds->dimond_name); ?></td>
                            <td><?php echo e($dimond->barcode); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($dimond->updated_at)->format('d-m-Y')); ?></td>
                            <td><?php echo e($dimond->dimonds->status); ?></td>
                            <!-- <td><b><span class="<?php echo e($dimond->stage == 'issue' ? 'text-success' : 'text-danger'); ?>"><?php echo e($dimond->stage); ?></span></b></td> -->
                            <td><a href="/admin/daily-status/statusupdate/<?php echo e($dimond->id); ?>"
                                    class="btn <?php echo e($dimond->status == 0 ? 'btn-danger' : 'btn-success'); ?>"><?php echo e($dimond->stage); ?></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-focus on the input field when the page loads
        document.getElementById('inputField2').focus();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/daily/index.blade.php ENDPATH**/ ?>