
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
         <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Company</h4>
            <div class="card-action">
               <div class="dropdown-menu-right">
                  <a class="dropdown-item" style="background-color:darkorchid;" href="<?php echo e(route('admin.company.create')); ?>"><i class="fa fa-plus editable" style="font-size:15px;">&nbsp;ADD</i></a>
               </div>
            </div>
         </div>
         <div class="table-responsive">
            <table id="partytable" class="table align-items-center table-flush table-borderless">
               <thead>
                  <tr>
                     <th>Action</th>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Contact</th>
                     <th>GST</th>
                     <th>PAN</th>
                     <th>CGST</th>
                     <th>SGST</th>
                     <th>Address</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php $__currentLoopData = $comapyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <td>
                        <a href="<?php echo e(route('admin.company.edit', $company->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                        <a href="<?php echo e(route('admin.company.destroy', $company->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                     </td>
                     <td><?php echo e($company->name); ?></td>
                     <td><?php echo e($company->email); ?></td>
                     <td><?php echo e($company->contact); ?></td>
                     <td><?php echo e($company->gst_no); ?></td>
                     <td><?php echo e($company->pan_no); ?></td>
                     <td><?php echo e($company->cgst); ?></td>
                     <td><?php echo e($company->sgst); ?></td>
                     <td><?php if(strlen($company->address) > 50): ?>
                        <?php echo substr($company->address,0,50); ?>

                        <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                        <span class="read-more-content"> <?php echo e(substr($company->address,50,strlen($company->address))); ?>

                           <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span> </span>
                        <?php else: ?>
                        <?php echo e($company->address); ?>

                        <?php endif; ?>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(document).ready(function() {
      // Capture the change event of the dropdown
      $('#status').on('change', function() {
         // Trigger form submission when the dropdown changes
         $('#myForm').submit();
      });
   });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/foobbshh/public_html/diamondhr/resources/views/admin/company/index.blade.php ENDPATH**/ ?>