
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
   <div class="col-lg-8 mx-auto">
      <div class="card">
         <div class="card-body">
            <?php if(session()->has('message')): ?>
            <div class="alert text-white" style="background-color:green">
               <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card-title">Edit Expense</div>
            <hr>
            <?php echo Form::model($company, ['method'=>'PATCH', 'action'=> ['AdminCompanyController@update', $company->id],'files'=>true,'class'=>'form-horizontal', 'name'=>'editcompanyform']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="name">Comapny Name</label>
                     <input type="text" name="name" class="form-control form-control-rounded" id="name" placeholder="Enter name" value="<?php echo e($company->name); ?>" required>
                     <?php if($errors->has('name')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('name')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="gst_no">GST No</label>
                     <input type="text" name="gst_no" class="form-control form-control-rounded" id="gst_no" placeholder="Enter GST No" value="<?php echo e($company->gst_no); ?>" required>
                     <?php if($errors->has('gst_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('gst_no')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="pan_no">PAN No</label>
                     <input type="text" name="pan_no" class="form-control form-control-rounded" id="pan_no" placeholder="Enter PAN No" value="<?php echo e($company->pan_no); ?>" required>
                     <?php if($errors->has('pan_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('pan_no')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="form-group">
               <label for="address">Address</label>
               <textarea type="text" name="address" class="form-control form-control-rounded" id="address" placeholder="Enter detail"><?php echo e($company->address); ?></textarea>
            </div>
            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="email">Email</label>
                     <input type="email" name="email" class="form-control form-control-rounded" id="email" placeholder="Enter email" value="<?php echo e($company->email); ?>" required>
                     <?php if($errors->has('email')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('email')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="contact">Contact</label>
                     <input type="number" name="contact" class="form-control form-control-rounded" id="contact" placeholder="Enter contact No" value="<?php echo e($company->contact); ?>" required>
                     <?php if($errors->has('contact')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('contact')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="sign">Sign</label>
                     <input type="file" name="sign" class="form-control form-control-rounded" id="sign">
                     <img src="<?php echo e($company->sign); ?>" alt="Your Logo" width="100px">
                     <?php if($errors->has('sign')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('sign')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="cgst">CGST</label>
                     <input type="number" name="cgst" class="form-control form-control-rounded" id="cgst" placeholder="Enter CGST" value="<?php echo e($company->cgst); ?>" required>
                     <?php if($errors->has('cgst')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('cgst')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="sgst">SGST</label>
                     <input type="number" name="sgst" class="form-control form-control-rounded" id="sgst" placeholder="Enter SGST" value="<?php echo e($company->sgst); ?>" required>
                     <?php if($errors->has('sgst')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('sgst')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <?php $bank_info = $company['bank_info'] ? json_decode($company['bank_info'], true) : '' ?>

            <div class="row">
               <div class="col-3">
                  <div class="form-group">
                     <label for="bank_name">Bank</label>
                     <input type="name" name="bank_name" class="form-control form-control-rounded" id="bank_name" placeholder="Enter bank name" value="<?= $bank_info['bank_name'] ?? ''; ?>">
                     <?php if($errors->has('bank_name')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('bank_name')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-3">
                  <div class="form-group">
                     <label for="account_no">Account No</label>
                     <input type="number" name="account_no" class="form-control form-control-rounded" id="account_no" placeholder="Enter account no" value="<?= $bank_info['account_no'] ?? ''; ?>">
                     <?php if($errors->has('account_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('account_no')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-3">
                  <div class="form-group">
                     <label for="ifsc_code">IFSC code</label>
                     <input type="text" name="ifsc_code" class="form-control form-control-rounded" id="ifsc_code" value="<?= $bank_info['ifsc_code'] ?? ''; ?>">
                     <?php if($errors->has('ifsc_code')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('ifsc_code')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-3">
                  <div class="form-group">
                     <label for="branch">Branch</label>
                     <input type="text" name="branch" class="form-control form-control-rounded" id="branch" placeholder="Enter branch" value="<?= $bank_info['branch'] ?? ''; ?>">
                     <?php if($errors->has('branch')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('branch')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="form-group">
               <button type="submit" class="btn btn-light btn-round px-5">Update</button>
            </div>
            </form>
         </div>
      </div>
   </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editcompanyform']").validate({
         rules: {
            name: {
               required: true,
            },
            gst_no: {
               required: true,
            },
            pan_no: {
               required: true,
            },
            email: {
               required: true,
            },
            contact: {
               required: true,
            },
            address: {
               required: true,
            },
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/foobbshh/public_html/diamondhr/resources/views/admin/company/edit.blade.php ENDPATH**/ ?>