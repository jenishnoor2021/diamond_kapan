<?php

use App\Models\Process;
?>

<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <h4 class="mb-sm-0 font-size-18">Designation wise Diamond</h4>

      <!-- <div class="page-title-right">
        <ol class="breadcrumb m-0">
          <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
          <li class="breadcrumb-item active">Designation wise Diamond</li>
        </ol>
      </div> -->

    </div>
  </div>
</div>
<!-- end page title -->

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <i class="mdi mdi-check-all me-2"></i>
          <?php echo e(session('success')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <i class="mdi mdi-block-helper me-2"></i>
          <?php echo e(session('error')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div id="right">
          <div id="menu" class="mb-3">

            <span id="menu-navi"
              class="d-sm-flex flex-wrap text-center text-sm-start justify-content-sm-between">
              <div class="d-sm-flex flex-wrap gap-1">
              </div>

              <div class="align-self-start mt-3 mt-sm-0 mb-2">
              </div>
            </span>

          </div>
        </div>

        <table id="datatable" class="table table-bordered dt-responsive nowrap w-100 mt-3">
          <thead>
            <tr>
              <th>Action</th>
              <th>Dimond Name</th>
              <th>Barcode</th>
              <th>Date</th>
              <th>Current Status</th>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $dailys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php if($dimond->dimonds): ?>
                <a href="<?php echo e(route('admin.dimond.show', $dimond->dimonds_barcode)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                <?php endif; ?>
              </td>
              <td><?php echo e($dimond->dimonds?->dimond_name); ?></td>
              <td><?php echo e($dimond->dimonds_barcode); ?></td>
              <td><?php echo e(\Carbon\Carbon::parse($dimond->updated_at)->format('d-m-Y')); ?></td>
              <td><?php echo e($dimond->dimonds?->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

      </div>
    </div>
  </div> <!-- end col -->
</div> <!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template_github\resources\views/admin/dimond/designationselected.blade.php ENDPATH**/ ?>