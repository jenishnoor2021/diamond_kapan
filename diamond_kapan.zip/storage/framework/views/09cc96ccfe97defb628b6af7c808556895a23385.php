<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Diamond Process Flow</title>
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
      font-family: Arial, sans-serif;
      margin-top: 40px;
    }

    th,
    td {
      border: 1px solid #000;
      padding: 12px;
      vertical-align: top;
    }

    th {
      background-color: #f2f2f2;
      text-align: left;
    }

    td div {
      margin-bottom: 6px;
    }

    .label {
      font-weight: bold;
    }

    .process_data {
      display: flex;
      gap: 15px;
      overflow: auto;
    }

    .process_data-item {
      min-width: 30%;
    }

    .stone-id {
      min-width: 200px;
    }

    @media(max-width: 991px) {
      .process_data-item {
        min-width: 50%;
      }
    }

    @media(max-width: 767px) {
      .process_data-item {
        min-width: 75%;
      }
    }

    @media(max-width: 543px) {
      .process_data-item {
        min-width: 85%;
      }
    }

    .text-orang {
      color: orange;
    }
  </style>
</head>

<body>

  <?php if(count($data)>0): ?>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <table>
    <tr>
      <th>Stone ID</th>
      <th>Process</th>
    </tr>
    <tr>
      <td class="stone-id">
        <div><span class="label">ID (Diamond):</span> <?php echo e($item['diamond']->dimond_name); ?></div>
        <div><span class="label">Date:</span> <?php echo e(\Carbon\Carbon::parse($item['diamond']->created_at)->format('d-m-Y')); ?></div>
        <div><span class="label">Party Name:</span> <?php echo e($item['diamond']->parties->fname); ?></div>
        <div><span class="label">R Weight:</span> <?php echo e($item['diamond']->weight); ?></div>
        <div><span class="label">C Weight:</span> <?php echo e($item['diamond']->required_weight); ?></div>
      </td>
      <td class="process_data">
        <?php $__currentLoopData = $item['processes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="process_data-item">
          <div class="<?php if($da->return_weight == ''): ?> text-orang <?php endif; ?>"><span class="label">Process:</span> <?php echo e($da->designation); ?></div>
          <div><span class="label">Name (Worker):</span> <?php echo e($da->worker_name); ?></div>
          <div><span class="label">I Date:</span> <?php echo e(\Carbon\Carbon::parse($da->issue_date)->format('d-m-Y')); ?></div>
          <div><span class="label">R Date:</span> <?php echo e(\Carbon\Carbon::parse($da->return_date)->format('d-m-Y')); ?></div>
          <div><span class="label">I Weight:</span> <?php echo e($da->issue_weight); ?></div>
          <div><span class="label">R Weight:</span> <?php echo e($da->return_weight); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- <div class="process_data-item">
          <div><span class="label">P Name:</span> Polish</div>
          <div><span class="label">Date:</span> 2025-04-10</div>
          <div><span class="label">R Weight:</span> 1.20</div>
          <div><span class="label">C Weight:</span> 1.18</div>
          <div><span class="label">E Name (Employee):</span> Jane Smith</div>
        </div>
        <div class="process_data-item">
          <div><span class="label">P Name:</span> Polish</div>
          <div><span class="label">Date:</span> 2025-04-10</div>
          <div><span class="label">R Weight:</span> 1.20</div>
          <div><span class="label">C Weight:</span> 1.18</div>
          <div><span class="label">E Name (Employee):</span> Jane Smith</div>
        </div>
        <div class="process_data-item">
          <div><span class="label">P Name:</span> Polish</div>
          <div><span class="label">Date:</span> 2025-04-10</div>
          <div><span class="label">R Weight:</span> 1.20</div>
          <div><span class="label">C Weight:</span> 1.18</div>
          <div><span class="label">E Name (Employee):</span> Jane Smith</div>
        </div> -->
      </td>
    </tr>
  </table>
  <br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
  <h1>No Data Found</h1>
  <?php endif; ?>

</body>

</html><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/dimond/diamond_flow_pdf.blade.php ENDPATH**/ ?>