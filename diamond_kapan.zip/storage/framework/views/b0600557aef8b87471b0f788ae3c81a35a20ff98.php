<?php

use Carbon\Carbon;
?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<style>
  .dt-button.buttons-html5 {
    background-color: aliceblue;
  }
</style>
<?php $__env->stopSection(); ?>
<div class="row mt-3">
  <div class="col-lg-12 mx-auto">
    <div class="card">
      <div class="card-body">
        <div class="card-title">
          <h4>Party Filter</h4>
        </div>
        <hr>
        <form action="<?php echo e(route('party.filter')); ?>" method="GET">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-3">
              <div class="form-group">
                <label for="party_id">Party Name</label>
                <select name="party_id" id="party_id" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select party</option>
                  <option value="All" <?php echo e(request()->party_id == 'All' ? 'selected' : ''); ?>>ALL</option>
                  <?php $__currentLoopData = $partyLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($partyList->id); ?>" <?php echo e(request()->party_id == $partyList->id ? 'selected' : ''); ?>><?php echo e($partyList->fname); ?>&nbsp;&nbsp;<?php echo e($partyList->lname); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('party_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('party_id')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-2">
              <div class="form-group">
                <label>Status:</label>
                <div>
                  <label>
                    <input type="checkbox" name="status[]" value="Pending" <?php echo e(in_array('Pending', (array) request()->status) ? 'checked' : ''); ?>>
                    Pending
                  </label>
                  <br>
                  <label>
                    <input type="checkbox" name="status[]" value="Processing" <?php echo e(in_array('Processing', (array) request()->status) ? 'checked' : ''); ?>>
                    Processing
                  </label>
                  <br>
                  <label>
                    <input type="checkbox" name="status[]" value="OutterProcessing" <?php echo e(in_array('OutterProcessing', (array) request()->status) ? 'checked' : ''); ?>>
                    Outter Processing
                  </label>
                  <br>
                  <label>
                    <input type="checkbox" name="status[]" value="Completed" <?php echo e(in_array('Completed', (array) request()->status) ? 'checked' : ''); ?>>
                    Completed
                  </label>
                  <br>
                  <label>
                    <input type="checkbox" name="status[]" value="Delivered" <?php echo e(in_array('Delivered', (array) request()->status) ? 'checked' : ''); ?>>
                    Delivered
                  </label>
                </div>
                <?php if($errors->has('status')): ?>
                <div class="error text-danger"><?php echo e($errors->first('status')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-2">
              <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" class="form-control form-control-rounded" id="start_date" value="<?php echo e(request()->start_date); ?>">
                <?php if($errors->has('start_date')): ?>
                <div class="error text-danger"><?php echo e($errors->first('start_date')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-2">
              <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" class="form-control form-control-rounded" id="end_date" value="<?php echo e(request()->end_date); ?>">
                <?php if($errors->has('end_date')): ?>
                <div class="error text-danger"><?php echo e($errors->first('end_date')); ?></div>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-light btn-round px-5">Report</button>
          </div>
        </form>
      </div>
      <div>
        <?php if(count($dimonds) > 0): ?>
        <?php $__currentLoopData = $partyLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <center>
          <h3><u><?php echo e($partyList->fname); ?>&nbsp;<?php echo e($partyList->lname); ?>&nbsp;(<?php echo e($partyList->party_code); ?>)</u></h3>
        </center>
        <?php
        $dimondsForParty = count($dimonds) > 0 ? $dimonds->where('parties_id', $partyList->id) : [];
        ?>
        <?php if(count($dimondsForParty)> 0): ?>
        <div class="table-responsive">
          <table id="exportTable" class="table align-items-center table-flush table-borderless partyFTable">
            <thead>
              <tr>
                <th>Action</th>
                <th>Party Code</th>
                <th>Dimond Name</th>
                <th>Row Weight</th>
                <th>Polished Weight</th>
                <th>Barcode</th>
                <th>Status</th>
                <th>Shap</th>
                <th>clarity</th>
                <th>color</th>
                <th>cut</th>
                <th>polish</th>
                <th>symmetry</th>
                <th>Created</th>
                <!-- <th>Last Modified</th> -->
                <th>Deliverd</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $dimondsForParty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="<?php echo e(route('admin.dimond.show', $dimond->barcode_number)); ?>"><i class="fa fa-eye" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a></td>
                <td><?php echo e($dimond->parties->party_code); ?></td>
                <td><?php echo e($dimond->dimond_name); ?></td>
                <td><?php echo e($dimond->weight); ?></td>
                <td><?php echo e($dimond->required_weight); ?></td>
                <td><?php echo $dimond->barcode_number; ?></td>
                <td><?php echo $dimond->status; ?></td>
                <td><?php echo e($dimond->shape); ?></td>
                <td><?php echo e($dimond->clarity); ?></td>
                <td><?php echo e($dimond->color); ?></td>
                <td><?php echo e($dimond->cut); ?></td>
                <td><?php echo e($dimond->polish); ?></td>
                <td><?php echo e($dimond->symmetry); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($dimond->created_at)->format('d-m-Y')); ?></td>
                <!-- <td><?php echo e(\Carbon\Carbon::parse($dimond->updated_at)->format('d-m-Y')); ?></td> -->
                <td><?php echo e(\Carbon\Carbon::parse($dimond->delevery_date)->format('d-m-Y')); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
        <center>
          <h5 style="color:#000">No Record Found</h5>
        </center>
        <br />
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br />
        <?php endif; ?>
      </div>
    </div>
  </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>

<script>
  $(document).ready(function() {
    $(".partyFTable").DataTable({
      dom: 'Blfrtip',
      buttons: [{
          extend: 'pdf',
        },
        {
          extend: 'csv',
        },
        {
          extend: 'excel',
        }
      ]
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/reports/party_filter.blade.php ENDPATH**/ ?>