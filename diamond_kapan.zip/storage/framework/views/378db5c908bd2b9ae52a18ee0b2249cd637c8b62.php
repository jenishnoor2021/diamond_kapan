<?php
use App\Models\Dimond;
use App\Models\Process;
?>

<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">Worker Report</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Worker Report</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-check-all me-2"></i>
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-block-helper me-2"></i>
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('generate-worker-pdf')); ?>" id="myWorkerForm" method="get">
                        <?php echo csrf_field(); ?>

                        <div data-repeater-list="group-a">
                            <div data-repeater-item class="row">
                                <div class="mb-3 col-lg-2">
                                    <label for="category">Category</label>
                                    <select name="category" id="category" class="form-select" required>
                                        <option value="">Select category</option>
                                        <option value="all" <?php echo e(request()->category == 'all' ? 'selected' : ''); ?>>ALL
                                        </option>
                                        <option value="Inner" <?php echo e(request()->category == 'Inner' ? 'selected' : ''); ?>>Inner
                                            Worker</option>
                                        <option value="Outter" <?php echo e(request()->category == 'Outter' ? 'selected' : ''); ?>>
                                            Outter Worker</option>
                                    </select>
                                    <?php if($errors->has('designation')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="designation">Designation</label>
                                    <select name="designation" id="designation" class="form-select" required>
                                        <option value="">Select designation</option>
                                        <option value="all" <?php echo e(request()->designation == 'all' ? 'selected' : ''); ?>>ALL
                                        </option>
                                        <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($designation->name); ?>"
                                                <?php echo e(request()->designation == $designation->name ? 'selected' : ''); ?>>
                                                <?php echo e($designation->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('designation')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="worker_name">Worker</label>
                                    <select name="worker_name" id="worker_name" class="form-select" required>
                                        <option value="">Select worker</option>
                                    </select>
                                    <?php if($errors->has('worker_name')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('worker_name')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="which_diamond">Type</label>
                                    <select name="which_diamond" id="which_diamond" class="form-select" required>
                                        <option value="delevery_date">Deliverd</option>
                                        <option value="updated_at">Reguler</option>
                                    </select>
                                    <?php if($errors->has('worker_name')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('worker_name')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="start_date">Start Date:</label>
                                    <input type="date" name="start_date" class="form-control"
                                        id="start_date" value="<?php echo e(old('start_date')); ?>" required>
                                    <?php if($errors->has('start_date')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('start_date')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="end_date">End Date:</label>
                                    <input type="date" name="end_date" class="form-control"
                                        id="end_date" value="<?php echo e(old('end_date')); ?>" required>
                                    <?php if($errors->has('end_date')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('end_date')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-lg-2 align-self-center">
                                <div class="d-flex gap-2">
                                    <button type="button" id="get_list" class="btn btn-success w-md">List</button>
                                    <button type="button" id="download_list" class="btn btn-info w-md">Download</button>
                                    <a class="btn btn-light w-md" href="/admin/worker_report">Clear</a>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>

            <?php if(count($data) > 0): ?>
                <?php $__currentLoopData = $worker_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="card-body">

                            <center>
                                <h4><?php echo e($worker->fname); ?>&nbsp;<?php echo e($worker->lname); ?></h4>
                            </center>

                            <table id="exportworkerTable_<?php echo e($worker->id); ?>"
                                class="table table-bordered dt-responsive nowrap w-100 mt-3">
                                <thead>
                                    <tr>
                                        <th>Sr.</th>
                                        <th>Dimond Name</th>
                                        <th>Dimond barcode</th>
                                        <th>Issues Date</th>
                                        <th>Return Date</th>
                                        <th>Shape</th>
                                        <th>clarity</th>
                                        <th>color</th>
                                        <th>cut</th>
                                        <th>polish</th>
                                        <th>symmetry</th>
                                        <th>Issues Weight</th>
                                        <th>Return Weight</th>
                                        <th width="20%">Amount</th>
                                        <th>Created date</th>
                                        <th>Delivery date</th>
                                    </tr>
                                </thead>
                                <?php
                                    $p = 1;
                                ?>
                                <tbody>
                                    <?php
                                    $dimondsBarcodeArray = [];
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($worker->fname == $da->worker_name): ?>
                                            <?php
                                            $category = $_GET['category'];
                                            $getdimond = Dimond::where('barcode_number', $da->dimonds_barcode)->first();
                                            $which_diamond = $_GET['which_diamond'];
                                            if ($which_diamond == 'updated_at') {
                                              $rw = $da->return_weight;
                                            } else {
                                              $returndimond = Process::where('dimonds_barcode', $da->dimonds_barcode)->where('designation', 'Grading')->latest()->first();
                                              $rw = isset($returndimond->return_weight) ? $returndimond->return_weight : '';
                                            }

                                            if (isset($getdimond) && ($da->price != 0) && ($category == "Inner")) { ?>
                                            <tr>
                                                <td><?php echo e($p); ?></td>
                                                <td><?php echo e($da->dimonds->dimond_name); ?></td>
                                                <td><?php echo e($da->dimonds_barcode); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($da->issue_date)->format('d-m-Y')); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($da->return_date)->format('d-m-Y')); ?></td>
                                                <td><?php echo e($getdimond->shape); ?></td>
                                                <td><?php echo e($getdimond->clarity); ?></td>
                                                <td><?php echo e($getdimond->color); ?></td>
                                                <td><?php echo e($getdimond->cut); ?></td>
                                                <td><?php echo e($getdimond->polish); ?></td>
                                                <td><?php echo e($getdimond->symmetry); ?></td>
                                                <td><?php echo e($da->issue_weight); ?></td>
                                                <td><?php echo e(isset($rw) ? $rw : ''); ?></td>
                                                <td><?php echo e($da->price); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($getdimond->created_at)->format('d-m-Y')); ?>

                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($getdimond->delevery_date)->format('d-m-Y')); ?>

                                                </td>
                                                <?php
                                                    $p += 1;
                                                ?>
                                            </tr>
                                            <?php } elseif ($category == "Outter" && !in_array($da->dimonds_barcode, $dimondsBarcodeArray)) {
                                            $dimondsBarcodeArray[] = $da->dimonds_barcode;
                                            ?>
                                            <tr>
                                                <td><?php echo e($p); ?></td>
                                                <td><?php echo e($da->dimonds->dimond_name); ?></td>
                                                <td><?php echo e($da->dimonds_barcode); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($da->issue_date)->format('d-m-Y')); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($da->return_date)->format('d-m-Y')); ?></td>
                                                <td><?php echo e($getdimond->shape); ?></td>
                                                <td><?php echo e($getdimond->clarity); ?></td>
                                                <td><?php echo e($getdimond->color); ?></td>
                                                <td><?php echo e($getdimond->cut); ?></td>
                                                <td><?php echo e($getdimond->polish); ?></td>
                                                <td><?php echo e($getdimond->symmetry); ?></td>
                                                <td><?php echo e($da->issue_weight); ?></td>
                                                <td><?php echo e(isset($rw) ? $rw : ''); ?></td>
                                                <td><?php echo e($da->price); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($getdimond->created_at)->format('d-m-Y')); ?>

                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($getdimond->delevery_date)->format('d-m-Y')); ?>

                                                </td>
                                                <?php
                                                    $p += 1;
                                                ?>
                                            </tr>
                                            <?php } else {
                                        if ($da->price != 0) { ?>
                                            <tr>
                                                <td><?php echo e($p); ?></td>
                                                <td><?php echo e($da->dimonds->dimond_name); ?></td>
                                                <td><?php echo e($da->dimonds_barcode); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($da->issue_date)->format('d-m-Y')); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($da->return_date)->format('d-m-Y')); ?></td>
                                                <td><?php echo e($getdimond->shape); ?></td>
                                                <td><?php echo e($getdimond->clarity); ?></td>
                                                <td><?php echo e($getdimond->color); ?></td>
                                                <td><?php echo e($getdimond->cut); ?></td>
                                                <td><?php echo e($getdimond->polish); ?></td>
                                                <td><?php echo e($getdimond->symmetry); ?></td>
                                                <td><?php echo e($da->issue_weight); ?></td>
                                                <td><?php echo e(isset($rw) ? $rw : ''); ?></td>
                                                <td><?php echo e($da->price); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($getdimond->created_at)->format('d-m-Y')); ?>

                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($getdimond->delevery_date)->format('d-m-Y')); ?>

                                                </td>
                                                <?php
                                                    $p += 1;
                                                ?>
                                            </tr>
                                            <?php }
                                        } ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            <?php $__currentLoopData = $worker_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $("#exportworkerTable_<?php echo e($worker->id); ?>").DataTable({
                    dom: 'Blfrtip',
                    buttons: [{
                            extend: 'pdf',
                        },
                        {
                            extend: 'csv',
                        },
                        {
                            extend: 'excel',
                        }
                    ]
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#designation').change(function() {
                var designation = $(this).val();
                if (designation == 'all') {
                    $('#worker_name').append('<option value="all" selected>ALL</option>');
                } else if (designation && designation != 'all') {
                    $.ajax({
                        type: 'POST',
                        url: '/admin/get-workers',
                        data: {
                            '_token': '<?php echo e(csrf_token()); ?>',
                            'designation': designation,
                        },
                        success: function(data) {
                            $('#worker_name').empty();
                            $('#worker_name').append(
                                '<option value="">Select worker</option><option value="all">ALL</option>'
                            );
                            $.each(data, function(key, value) {
                                $('#worker_name').append('<option value="' + value
                                    .fname + '">' + value.fname + ' ' + value
                                    .lname + '</option>');
                            });
                        }
                    });
                } else {
                    $('#worker_name').empty();
                }
            });
            $('#category').change(function() {
                var category = $(this).val();
                if (category) {
                    $.ajax({
                        type: 'POST',
                        url: '/admin/get-designation',
                        data: {
                            '_token': '<?php echo e(csrf_token()); ?>',
                            'category': category,
                        },
                        success: function(data) {
                            $('#designation').empty();
                            $('#designation').append(
                                '<option value="">Select designation</option><option value="all">ALL</option>'
                            );
                            $.each(data, function(key, value) {
                                $('#designation').append('<option value="' + value
                                    .name + '">' + value.name + '</option>');
                            });
                        }
                    });
                } else {
                    $('#designation').empty();
                }
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var form = document.getElementById('myWorkerForm');
            var button1 = document.getElementById('get_list');
            var button2 = document.getElementById('download_list');

            button1.addEventListener('click', function() {
                if (document.getElementById('start_date').value == '') {
                    alert("Enter Start date");
                    return false;
                }

                if (document.getElementById('end_date').value == '') {
                    alert("Enter End date");
                    return false;
                }
                // Change the form action for button 1
                form.action = "<?php echo e(route('admin.worker.report')); ?>";
                // Submit the form
                form.submit();
            });

            button2.addEventListener('click', function() {
                if (document.getElementById('start_date').value == '') {
                    alert("Enter Start date");
                    return false;
                }

                if (document.getElementById('end_date').value == '') {
                    alert("Enter End date");
                    return false;
                }
                // Change the form action for button 2
                form.action = "<?php echo e(route('generate-worker-pdf')); ?>";
                // Submit the form
                form.submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/reports/worker_report.blade.php ENDPATH**/ ?>