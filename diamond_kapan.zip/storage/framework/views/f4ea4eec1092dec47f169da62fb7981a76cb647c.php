<?php

use App\Models\Process;
?>


<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <h4 class="mb-sm-0 font-size-18">Export Delievery Slip</h4>

      <!-- <div class="page-title-right">
        <ol class="breadcrumb m-0">
          <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
          <li class="breadcrumb-item active">Export Delievery Slip</li>
        </ol>
      </div> -->

    </div>
  </div>
</div>
<!-- end page title -->

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('admin.hr.export')); ?>" method="GET" class="repeater">
          <?php echo csrf_field(); ?>
          <div data-repeater-list="group-a">
            <div data-repeater-item class="row">
              <div class="mb-3 col-lg-2">
                <label for="party_id">Party Name</label>
                <select class="form-select" name="party_id" id="validationCustom03" required="">
                  <option value="<?php echo e(request()->party_id); ?>">Select party</option>
                  <?php $__currentLoopData = $partyLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($partyList->id); ?>" <?php echo e(request()->party_id == $partyList->id ? 'selected' : ''); ?>><?php echo e($partyList->fname); ?>&nbsp;&nbsp;<?php echo e($partyList->lname); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="mb-3 col-lg-2">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e(request()->start_date); ?>" placeholder="Enter date" required />
              </div>

              <div class="mb-3 col-lg-2">
                <label for="end_date">End Date</label>
                <input type="date" name="end_date" id="end_date" class="form-control" placeholder="Enter date" value="<?php echo e(request()->end_date); ?>" required />
              </div>

              <div class="col-lg-1 align-self-center">
                <div class="d-flex gap-2">
                  <input type="submit" class="btn btn-success mt-3 mt-lg-0" value="Show" />
                  <a class="btn btn-light mt-3 mt-lg-0" href="<?php echo e(URL::to('/admin/hr-export')); ?>">Back</a>
                </div>
              </div>
            </div>

          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php if(count($data) > 0): ?>
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-body">

        <form action="<?php echo e(route('admin.hr.exportpdf')); ?>" method="GET">
          <?php echo csrf_field(); ?>

          <input type="hidden" name="party_id" value="<?php echo e(request()->party_id); ?>">
          <input type="hidden" name="start_date" value="<?php echo e(request()->start_date); ?>">
          <input type="hidden" name="end_date" value="<?php echo e(request()->end_date); ?>">

          <input type="submit" class="btn btn-success mt-1 mt-lg-0 mb-2" value="Export" />

        </form>

        <div class="table-responsive">
          <table class="table align-middle table-nowrap mb-0" id="diamondprintTable">
            <thead class="table-light">
              <tr>
                <th>Sr.</th>
                <th>Stone Id</th>
                <th>RW</th>
                <th>PW</th>
                <th>SHP</th>
                <th>CL</th>
                <th>PRT</th>
                <th>CUT</th>
                <th>PL</th>
                <th>STN</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
              $process = Process::where(['designation' => 'Grading', 'dimonds_id' => $da->id])->first();
              ?>
              <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($da->dimond_name); ?></td>
                <td><?php echo e($da->weight); ?></td>
                <td><?php echo e(isset($process->return_weight) ?$process->return_weight: ''); ?></td>
                <td><?php echo e(isset($process->r_shape) ?$process->r_shape: ''); ?></td>
                <td><?php echo e(isset($process->r_clarity) ?$process->r_clarity: ''); ?></td>
                <td><?php echo e(isset($process->r_color) ?$process->r_color: ''); ?></td>
                <td><?php echo e(isset($process->r_cut) ?$process->r_cut: ''); ?></td>
                <td><?php echo e(isset($process->r_polish) ?$process->r_polish: ''); ?></td>
                <td><?php echo e(isset($process->r_symmetry) ?$process->r_symmetry: ''); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- end table-responsive -->
      </div>
    </div>
  </div>
</div>
<?php elseif(request()->party_id != ''): ?>
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-body">
        <span class="text-danger">No record found</span>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template_github\resources\views/admin/reports/hr_report.blade.php ENDPATH**/ ?>