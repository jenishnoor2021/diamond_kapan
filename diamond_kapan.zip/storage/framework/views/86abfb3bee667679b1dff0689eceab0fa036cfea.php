
<?php $__env->startSection('style'); ?>
<style>
  form {
    width: 300px;
    padding: 20px;
    border-radius: 5px;
  }

  input {
    width: 100%;
    padding: 2px;
    margin-bottom: 16px;
    box-sizing: border-box;
    background-color: transparent;
    color: white
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <?php if(session('success')): ?>
      <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
        <?php echo e(session('success')); ?>

      </div>
      <?php endif; ?>
      <?php if(session('error')): ?>
      <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:red">
        <?php echo e(session('error')); ?>

      </div>
      <?php endif; ?>
      <div class="card-header d-flex justify-content-between align-items-center">
        <h4>Check Out</h4>
        <form method="POST" action="<?php echo e(route('admin.check-out.store')); ?>">
          <?php echo csrf_field(); ?>
          <input type="number" id="inputField" name="inputField" placeholder="Search barcode" required>
        </form>
        <h5></h5>
      </div>

      <div class="">
        <table id="dailytable" class="table align-items-center table-flush table-borderless">
          <thead>
            <tr>
              <th>Worker Name</th>
              <th>Date</th>
              <th>check In</th>
              <th>check Out</th>
              <th>Duration</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $todayattendanceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$todayattendanceRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($todayattendanceRecord->worker->fname); ?>&nbsp;<?php echo e($todayattendanceRecord->worker->lname); ?></td>
              <td><?php echo e(\Carbon\Carbon::parse($todayattendanceRecord->date)->format('d-m-Y')); ?></td>
              <td><?php echo e(\Carbon\Carbon::parse($todayattendanceRecord->check_in)->format('g:i A')); ?></td>
              <td><?php echo e($todayattendanceRecord->check_out ? \Carbon\Carbon::parse($todayattendanceRecord->check_out)->format('g:i A') : ''); ?></td>
              <td><?php echo e($todayattendanceRecord->duration); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Auto-focus on the input field when the page loads
    document.getElementById('inputField').focus();
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\dimond\resources\views/admin/worker_attendance/checkout.blade.php ENDPATH**/ ?>