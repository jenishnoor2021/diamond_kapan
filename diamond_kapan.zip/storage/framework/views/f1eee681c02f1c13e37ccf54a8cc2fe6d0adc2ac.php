<?php

use App\Models\Process;
?>

<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Company</h4>

            <!-- <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                    <li class="breadcrumb-item active">Company</li>
                </ol>
            </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <div id="right">
                    <div id="menu" class="mb-3">

                        <span id="menu-navi"
                            class="d-sm-flex flex-wrap text-center text-sm-start justify-content-sm-between">
                            <div class="d-sm-flex flex-wrap gap-1">
                                <h4>Company</h4>
                            </div>

                            <h4 class="render-range fw-bold pt-1 mx-3">
                            </h4>

                            <?php if(count($comapyes) == 0): ?>
                            <div class="align-self-start mt-3 mt-sm-0 mb-2">
                                <a class="btn btn-primary" href="<?php echo e(route('admin.company.create')); ?>"><i
                                        class="fa fa-plus">&nbsp;ADD</i></a>
                            </div>
                            <?php endif; ?>
                        </span>

                    </div>
                </div>

                <table id="datatable" class="table table-bordered dt-responsive w-100 mt-3">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>GST</th>
                            <th>PAN</th>
                            <th>Address</th>
                            <th>CGST</th>
                            <th>SGST</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $comapyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.company.edit', $company->id)); ?>"
                                    class="btn btn-outline-primary waves-effect waves-light"><i
                                        class="fa fa-edit"></i></a>
                                <?php if(count($comapyes) > 1): ?>
                                <a href="<?php echo e(route('admin.company.destroy', $company->id)); ?>"
                                    onclick="return confirm('Sure ! You want to delete ?');"
                                    class="btn btn-outline-danger waves-effect waves-light"><i
                                        class="fa fa-trash"></i></a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($company->name); ?></td>
                            <td><?php echo e($company->email); ?></td>
                            <td><?php echo e($company->contact); ?></td>
                            <td><?php echo e($company->gst_no); ?></td>
                            <td><?php echo e($company->pan_no); ?></td>
                            <td>
                                <?php if(strlen($company->address) > 50): ?>
                                <?php echo substr($company->address, 0, 50); ?>

                                <span class="read-more-show hide_content">More<i
                                        class="fa fa-angle-down"></i></span>
                                <span class="read-more-content">
                                    <?php echo e(substr($company->address, 50, strlen($company->address))); ?>

                                    <span class="read-more-hide hide_content">Less <i
                                            class="fa fa-angle-up"></i></span> </span>
                                <?php else: ?>
                                <?php echo e($company->address); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($company->cgst); ?></td>
                            <td><?php echo e($company->sgst); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        // Capture the change event of the dropdown
        $('#status').on('change', function() {
            // Trigger form submission when the dropdown changes
            $('#myForm').submit();
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template_github\resources\views/admin/company/index.blade.php ENDPATH**/ ?>