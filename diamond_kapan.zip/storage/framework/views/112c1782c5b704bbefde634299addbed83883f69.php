
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
         <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Worker List</h4>
            <div class="card-action">
               <div class="dropdown-menu-right">
                  <a class="dropdown-item" style="background-color:darkorchid;" href="<?php echo e(route('admin.worker.create')); ?>"><i class="fa fa-plus editable" style="font-size:15px;">&nbsp;ADD</i></a>
               </div>
            </div>
         </div>
         <div class="table-responsive">
            <table id="workertable" class="table align-items-center table-flush table-borderless">
               <thead>
                  <tr>
                     <th>Action</th>
                     <th>Designation</th>
                     <th>First name</th>
                     <th>Last Name</th>
                     <th>Address</th>
                     <th>Mobile no</th>
                     <th>Aadhar no</th>
                     <th>Active/De-active</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <td>
                        <a href="<?php echo e(route('admin.worker.edit', $worker->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                        <a href="<?php echo e(route('admin.worker.destroy', $worker->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                     </td>
                     <td><?php echo e($worker->designation); ?></td>
                     <td><?php echo e($worker->fname); ?></td>
                     <td><?php echo e($worker->lname); ?></td>
                     <td><?php if(strlen($worker->address) > 100): ?>
                        <?php echo substr($worker->address,0,100); ?>

                        <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                        <span class="read-more-content"> <?php echo e(substr($worker->address,100,strlen($worker->address))); ?>

                           <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span> </span>
                        <?php else: ?>
                        <?php echo e($worker->address); ?>

                        <?php endif; ?>
                     </td>
                     <td><?php echo e($worker->mobile); ?></td>
                     <td><?php echo e($worker->aadhar_no); ?></td>
                     <td>
                        <?php if($worker->is_active == 1): ?>
                        <a href="/admin/worker/active/<?php echo e($worker->id); ?>" class="btn btn-success">Active</a>
                        <?php else: ?>
                        <a href="/admin/worker/active/<?php echo e($worker->id); ?>" class="btn btn-danger">De-active</a>
                        <?php endif; ?>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/worker/index.blade.php ENDPATH**/ ?>