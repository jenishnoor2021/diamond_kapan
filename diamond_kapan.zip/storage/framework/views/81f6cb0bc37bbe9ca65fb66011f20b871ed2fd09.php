
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">Edit Company</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Edit Company</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">

                    <?php echo Form::model($company, [
                        'method' => 'PATCH',
                        'action' => ['AdminCompanyController@update', $company->id],
                        'files' => true,
                        'class' => 'form-horizontal',
                        'name' => 'editcompanyform',
                    ]); ?>

                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="name">Comapny Name</label>
                                <input type="text" name="name" class="form-control" id="name"
                                    placeholder="Enter name" value="<?php echo e($company->name); ?>" required>
                                <?php if($errors->has('name')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="gst_no">GST No</label>
                                <input type="text" name="gst_no" class="form-control" id="gst_no"
                                    placeholder="Enter GST No" value="<?php echo e($company->gst_no); ?>" required>
                                <?php if($errors->has('gst_no')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('gst_no')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="pan_no">PAN No</label>
                                <input type="text" name="pan_no" class="form-control" id="pan_no"
                                    placeholder="Enter PAN No" value="<?php echo e($company->pan_no); ?>" required>
                                <?php if($errors->has('pan_no')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('pan_no')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="mb-3">
                                <label for="address">Address</label>
                                <textarea type="text" name="address" class="form-control" id="address" placeholder="Enter detail"><?php echo e($company->address); ?></textarea>
                                <?php if($errors->has('address')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('address')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="mb-3">
                                <label for="email">Email</label>
                                <input type="email" name="email" class="form-control" id="email"
                                    placeholder="Enter email" value="<?php echo e($company->email); ?>" required>
                                <?php if($errors->has('email')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-3">
                            <div class="mb-3">
                                <label for="contact">Contact</label>
                                <input type="number" name="contact" class="form-control" id="contact"
                                    placeholder="Enter contact No" value="<?php echo e($company->contact); ?>" required>
                                <?php if($errors->has('contact')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('contact')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="mb-3">
                                <label for="sign">Sign</label>
                                <input type="file" name="sign" class="form-control" id="sign" required>
                                <img src="<?php echo e($company->sign); ?>" alt="Your Logo" width="100px">
                                <?php if($errors->has('sign')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('sign')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="mb-3">
                                <label for="cgst">CGST</label>
                                <input type="number" name="cgst" class="form-control" id="cgst"
                                    placeholder="Enter CGST" value="<?php echo e($company->cgst); ?>" required>
                                <?php if($errors->has('cgst')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('cgst')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="mb-3">
                                <label for="sgst">SGST</label>
                                <input type="number" name="sgst" class="form-control" id="sgst"
                                    placeholder="Enter SGST" value="<?php echo e($company->sgst); ?>" required>
                                <?php if($errors->has('sgst')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('sgst')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <?php $bank_info = $company['bank_info'] ? json_decode($company['bank_info'], true) : ''; ?>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="bank_name">Bank</label>
                                <input type="name" name="bank_name" class="form-control" id="bank_name"
                                    placeholder="Enter bank name" value="<?= $bank_info['bank_name'] ?? '' ?>">
                                <?php if($errors->has('bank_name')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('bank_name')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="account_no">Account No</label>
                                <input type="number" name="account_no" class="form-control" id="account_no"
                                    placeholder="Enter account no" value="<?= $bank_info['account_no'] ?? '' ?>">
                                <?php if($errors->has('account_no')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('account_no')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="ifsc_code">IFSC code</label>
                                <input type="text" name="ifsc_code" class="form-control" id="ifsc_code"
                                    value="<?= $bank_info['ifsc_code'] ?? '' ?>">
                                <?php if($errors->has('ifsc_code')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('ifsc_code')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="branch">Branch</label>
                                <input type="text" name="branch" class="form-control"
                                    id="branch" placeholder="Enter branch" value="<?= $bank_info['branch'] ?? '' ?>">
                                <?php if($errors->has('branch')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('branch')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-md">Submit</button>
                        <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/company')); ?>">Back</a>
                    </div>
                    </form>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {

            $("form[name='editcompanyform']").validate({
                rules: {
                    name: {
                        required: true,
                    },
                    gst_no: {
                        required: true,
                    },
                    pan_no: {
                        required: true,
                    },
                    email: {
                        required: true,
                    },
                    contact: {
                        required: true,
                    },
                    address: {
                        required: true,
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/company/edit.blade.php ENDPATH**/ ?>