
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
         <h4 class="mb-sm-0 font-size-18">Edit Color</h4>

         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
               <li class="breadcrumb-item active">Edit Color</li>
            </ol>
         </div>

      </div>
   </div>
</div>
<!-- end page title -->

<div class="row">
   <div class="col-xl-12">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title mb-4">Edit</h4>

            <?php echo Form::model($color, ['method'=>'PATCH', 'action'=> ['AdminColorController@update', $color->id],'files'=>true,'class'=>'form-horizontal', 'name'=>'editcolorform']); ?>

            <?php echo csrf_field(); ?>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="c_name" class="form-label">Name</label>
                     <input type="text" name="c_name" class="form-control" id="c_name" placeholder="Enter name" onkeypress='return (event.charCode != 32)' value="<?php echo e($color->c_name); ?>" required>
                     <?php if($errors->has('c_name')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('c_name')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="d-flex gap-2">
               <button type="submit" class="btn btn-primary w-md">Update</button>
               <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/color')); ?>">Back</a>
            </div>
            </form>
         </div>
         <!-- end card body -->
      </div>
      <!-- end card -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editcolorform']").validate({
         rules: {
            c_name: {
               required: true,
            },
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/color/edit.blade.php ENDPATH**/ ?>