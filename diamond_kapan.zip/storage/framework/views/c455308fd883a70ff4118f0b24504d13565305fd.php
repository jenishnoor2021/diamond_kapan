<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <i class="mdi mdi-check-all me-2"></i>
  <?php echo e(session('success')); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <i class="mdi mdi-block-helper me-2"></i>
  <?php echo e(session('error')); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
  <ul class="mb-0">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>

<div id="ajaxAlert"
  class="alert alert-success position-fixed end-0 m-3 d-none"
  style="z-index: 9999;top:50px !important;">
</div>


<script>
  function showAlert(message, type = 'success') {
    let alertBox = $('#ajaxAlert');

    alertBox
      .removeClass('d-none alert-success alert-danger alert-warning')
      .addClass('alert-' + type)
      .text(message)
      .fadeIn();

    setTimeout(function() {
      alertBox.fadeOut(function() {
        $(this).addClass('d-none');
      });
    }, 5000); // 5 seconds
  }
</script><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/includes/flash_message.blade.php ENDPATH**/ ?>