
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Party Range List</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                    <li class="breadcrumb-item active">Party Range List</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminPartyRangeController@store','files'=>true,'class'=>'form-horizontal','name'=>'addpartyrangeform']); ?>

                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-2">
                        <div class="mb-3">
                            <label for="shape" class="form-label">Shape</label>
                            <select name="shape" id="shape" class="form-select" required>
                                <option value="">Select shape</option>
                                <option value="Round">Round</option>
                                <option value="Other">Other</option>
                            </select>
                            <?php if($errors->has('shape')): ?>
                            <div class="error text-danger"><?php echo e($errors->first('shape')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-3">
                            <label for="min_value" class="form-label">Min</label>
                            <input type="text" name="min_value" class="form-control" style="background-color:#ccc;" id="min_value" placeholder="Enter min value" value="<?php echo e(old('min_value')); ?>" readonly required>
                            <?php if($errors->has('min_value')): ?>
                            <div class="error text-danger"><?php echo e($errors->first('min_value')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-3">
                            <label for="max_value" class="form-label">Max</label>
                            <input type="text" name="max_value" class="form-control" id="max_value" placeholder="Enter max value" value="<?php echo e(old('max_value')); ?>" oninput="formatWeight(this);" required>
                            <?php if($errors->has('max_value')): ?>
                            <div class="error text-danger"><?php echo e($errors->first('max_value')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary w-md">Submit</button>
                            <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/party_range')); ?>">Back</a>
                        </div>
                    </div>
                </div>
                </form>

                <hr style="border:1px solid #000;">
                <table id="" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Key</th>
                            <th>Shape</th>
                            <th>Min</th>
                            <th>Max</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $partyrates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyrate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.party_range.edit', $partyrate->id)); ?>"
                                    class="btn btn-outline-primary waves-effect waves-light"><i
                                        class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.party_range.destroy', $partyrate->id)); ?>"
                                    onclick="return confirm('Sure ! You want to delete ?');"
                                    class="btn btn-outline-danger waves-effect waves-light"><i
                                        class="fa fa-trash"></i></a>
                            </td>
                            <td><?php echo e($partyrate->key); ?></td>
                            <td><?php echo e($partyrate->shape); ?></td>
                            <td><?php echo e($partyrate->min_value); ?></td>
                            <td><?php echo e($partyrate->max_value); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(function() {
        $("form[name='addpartyrangeform']").validate({
            rules: {
                shape: {
                    required: true,
                },
                min_value: {
                    required: true,
                },
                max_value: {
                    required: true,
                },
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });

    function formatWeight(input) {
        // Remove any non-numeric characters
        var cleanedValue = input.value.replace(/[^0-9.]/g, '');

        // Ensure valid pattern: either empty, '0.00', or '00.00'
        var match = cleanedValue.match(/^(\d{0,2}(\.\d{0,2})?)?$/);

        // Update the input value with the formatted result
        input.value = match ? match[1] || '' : '';
    }

    $(document).ready(function() {
        $('#shape').change(function() {
            var selectedShape = $(this).val();

            if (selectedShape) {
                $.ajax({
                    url: '<?php echo e(route("getMinValue")); ?>',
                    type: 'GET',
                    data: {
                        shape: selectedShape
                    },
                    success: function(response) {
                        $('#min_value').val(response.min_value);
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/partyrates/index.blade.php ENDPATH**/ ?>