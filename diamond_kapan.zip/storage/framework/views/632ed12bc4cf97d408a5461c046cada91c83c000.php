
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">Diamond Report</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Diamond Report</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-check-all me-2"></i>
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-block-helper me-2"></i>
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form action="<?php echo e(route('admin.add-dimond.list')); ?>" id="myDiamondList" method="get">
                        <?php echo csrf_field(); ?>
                        <div data-repeater-list="group-a">
                            <div data-repeater-item class="row">
                                <div class="mb-3 col-lg-2">
                                    <label for="start_date">Start Date:</label>
                                    <input type="date" name="start_date" class="form-control"id="start_date"
                                        value="<?= isset(request()->start_date) ? request()->start_date : '' ?>" required>
                                    <?php if($errors->has('start_date')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('start_date')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="end_date">End Date:</label>
                                    <input type="date" name="end_date" class="form-control" id="end_date"
                                        value="<?= isset(request()->end_date) ? request()->end_date : '' ?>" required>
                                    <?php if($errors->has('end_date')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('end_date')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="col-lg-2 align-self-center">
                                    <div class="d-flex gap-2">
                                        <input type="submit" class="btn btn-success w-md" value="Submit" />
                                        <a class="btn btn-light w-md" href="/admin/dimond_list">Clear</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>

            <?php if(count($data) > 0): ?>
                <div class="card">
                    <div class="card-body">

                        <table id="exportworkerTable" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                            <thead>
                                <tr>
                                    <th>Sr.</th>
                                    <th>Dimond Name</th>
                                    <th>Dimond barcode</th>
                                    <th>Created Date</th>
                                    <th>Delivery Date</th>
                                </tr>
                            </thead>
                            <?php
                                $p = 1;
                            ?>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($p); ?></td>
                                        <td><?php echo e($da->dimond_name); ?></td>
                                        <td><?php echo e($da->barcode_number); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($da->created_at)->format('d-m-Y')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($da->delevery_date)->format('d-m-Y')); ?></td>
                                        <?php
                                            $p += 1;
                                        ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $("#exportworkerTable").DataTable({
                dom: 'Blfrtip',
                buttons: [{
                        extend: 'pdf',
                    },
                    {
                        extend: 'csv',
                    },
                    {
                        extend: 'excel',
                    }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/reports/adddimondlist.blade.php ENDPATH**/ ?>