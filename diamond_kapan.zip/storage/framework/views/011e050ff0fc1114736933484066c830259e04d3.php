
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Check In</h4>

            <!-- <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                    <li class="breadcrumb-item active">Check In</li>
                </ol>
            </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-block-helper me-2"></i>
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <div id="right">
                    <div id="menu" class="mb-3">

                        <span id="menu-navi"
                            class="d-sm-flex flex-wrap text-center text-sm-start justify-content-sm-between">
                            <div class="d-sm-flex flex-wrap gap-1">
                                <h4>Check In</h4>
                            </div>

                            <h4 id="" class="render-range fw-bold">
                                <form method="POST" action="<?php echo e(route('admin.check-in.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" id="inputField" class="form-control" name="inputField" placeholder="Check In barcode"
                                        required>
                                </form>
                            </h4>

                            <div class="align-self-start mt-3 mt-sm-0 mb-2">
                            </div>

                        </span>

                    </div>
                </div>

                <table id="dailytable" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                    <thead>
                        <tr>
                            <th>Worker Name</th>
                            <th>Date</th>
                            <th>check In</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $todayattendanceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $todayattendanceRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($todayattendanceRecord->worker->fname); ?>&nbsp;<?php echo e($todayattendanceRecord->worker->lname); ?>

                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($todayattendanceRecord->date)->format('d-m-Y')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($todayattendanceRecord->check_in)->format('g:i A')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-focus on the input field when the page loads
        document.getElementById('inputField').focus();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template_github\resources\views/admin/worker_attendance/checkin.blade.php ENDPATH**/ ?>