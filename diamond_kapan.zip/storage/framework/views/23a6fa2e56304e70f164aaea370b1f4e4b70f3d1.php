
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
         <h4 class="mb-sm-0 font-size-18">ADD Worker</h4>

         <!-- <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
               <li class="breadcrumb-item active">ADD Worker</li>
            </ol>
         </div> -->

      </div>
   </div>
</div>
<!-- end page title -->

<div class="row">
   <div class="col-xl-12">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title mb-4">ADD</h4>

            <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminWorkerController@store','files'=>true,'class'=>'form-horizontal','name'=>'addworkerform']); ?>

            <?php echo csrf_field(); ?>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="fname">First Name</label>
                     <input type="text" name="fname" class="form-control" id="fname" placeholder="Enter First Name" onkeypress='return (event.charCode != 32)' value="<?php echo e(old('fname')); ?>" required>
                     <?php if($errors->has('fname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('fname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="lname">Last Name</label>
                     <input type="text" name="lname" class="form-control" id="lname" placeholder="Enter Last Name" onkeypress='return (event.charCode != 32)' value="<?php echo e(old('lname')); ?>" required>
                     <?php if($errors->has('lname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('lname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="designation">Designation</label>
                     <select name="designation" id="designation" class="form-select" required>
                        <option value="">Select designation</option>
                        <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designation->name); ?>"><?php echo e($designation->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                     <?php if($errors->has('designation')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="mb-3">
               <label for="remark">Remark / katori</label>
               <textarea type="text" name="remark" class="form-control" id="remark" placeholder="Enter Remark / katori"><?php echo e(old('remark')); ?></textarea>
               <?php if($errors->has('remark')): ?>
               <div class="error text-danger"><?php echo e($errors->first('remark')); ?></div>
               <?php endif; ?>
            </div>

            <div class="mb-3">
               <label for="address">Address</label>
               <textarea type="text" name="address" class="form-control" id="address" placeholder="Enter Address"><?php echo e(old('address')); ?></textarea>
               <?php if($errors->has('address')): ?>
               <div class="error text-danger"><?php echo e($errors->first('address')); ?></div>
               <?php endif; ?>
            </div>

            <div class="row">
               <div class="col-lg-4">
                  <div class="mb-3">
                     <label for="mobile">Mobile no</label>
                     <input type="number" name="mobile" class="form-control" id="mobile" placeholder="Enter number" value="<?php echo e(old('mobile')); ?>">
                     <?php if($errors->has('mobile')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('mobile')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="mb-3">
                     <label for="aadhar_no">Aadhar Number</label>
                     <input type="text" name="aadhar_no" class="form-control" id="aadhar_no" oninput="formatAadharInput(this)" placeholder="Enter aadhar no" value="<?php echo e(old('aadhar_no')); ?>">
                     <?php if($errors->has('aadhar_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('aadhar_no')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="mb-3">
               <div class="form-check">
                  <label class="form-check-label" for="roundCheckbox">
                     <input class="form-check-input" type="checkbox" id="roundCheckbox">
                     Round Rate
                  </label>
               </div>
            </div>

            <div id="roundDiv" style="display: none;">
               <?php $__currentLoopData = $roundworkerrangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roundworkerrang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="<?php echo e($roundworkerrang->key); ?>" class="form-label">Rate (<?php echo e($roundworkerrang->min_value); ?> to <?php echo e($roundworkerrang->max_value); ?>)</label>
                     <input type="number" name="<?php echo e($roundworkerrang->key); ?>" class="form-control" id="<?php echo e($roundworkerrang->key); ?>" placeholder="Enter amount" value="">
                     <?php if($errors->has('$roundworkerrang->key')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('$roundworkerrang->key')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mb-3">
               <div class="form-check">
                  <label class="form-check-label" for="fancyCheckbox">
                     <input class="form-check-input" type="checkbox" id="fancyCheckbox">
                     Fancy Rate
                  </label>
               </div>
            </div>

            <div id="fancyDiv" style="display: none;">
               <div class="row">
                  <?php $__currentLoopData = $otherworkerrangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherworkerrang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="<?php echo e($otherworkerrang->key); ?>" class="form-label">Rate (<?php echo e($otherworkerrang->min_value); ?> to <?php echo e($otherworkerrang->max_value); ?>)</label>
                        <input type="number" name="<?php echo e($otherworkerrang->key); ?>" class="form-control" id="<?php echo e($otherworkerrang->key); ?>" placeholder="Enter amount" value="">
                        <?php if($errors->has('$otherworkerrang->key')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('$otherworkerrang->key')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>

            <div class="mb-3">
               <div class="form-check">
                  <label class="form-check-label" for="myCheckbox">
                     <input class="form-check-input" type="checkbox" id="myCheckbox">
                     Add Bank detail
                  </label>
               </div>
            </div>

            <div id="myDiv" style="display: none;">
               <div class="row">
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="bank_name">Bank name</label>
                        <input type="text" name="bank_name" class="form-control" id="bank_name" placeholder="Enter bank name">
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="ifsc_code">IFSC code</label>
                        <input type="text" name="ifsc_code" class="form-control" id="ifsc_code" placeholder="Enter IFSC code">
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="account_holder_name">Account Holder name</label>
                        <input type="text" name="account_holder_name" class="form-control" id="account_holder_name" placeholder="Enter Account Holder name">
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="account_no">Account Number</label>
                        <input type="number" name="account_no" class="form-control" id="account_no" placeholder="Enter Account number">
                     </div>
                  </div>
               </div>
            </div>

            <div class="d-flex gap-2">
               <button type="submit" class="btn btn-primary w-md">Submit</button>
               <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/worker')); ?>">Back</a>
            </div>
            </form>
         </div>
         <!-- end card body -->
      </div>
      <!-- end card -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {
      $("form[name='addworkerform']").validate({
         rules: {
            fname: {
               required: true,
            },
            lname: {
               required: true,
            },
            // address: {
            //    required: true,
            // },
            // mobile: {
            //    required: true,
            // },
            designation: {
               required: true,
            },
            // aadhar_no: {
            //    required: true,
            // }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<script>
   document.addEventListener('DOMContentLoaded', function() {
      var checkbox = document.getElementById('myCheckbox');
      var div = document.getElementById('myDiv');

      var roundcheckbox = document.getElementById('roundCheckbox');
      var rounddiv = document.getElementById('roundDiv');

      var fancycheckbox = document.getElementById('fancyCheckbox');
      var fancydiv = document.getElementById('fancyDiv');

      checkbox.addEventListener('change', function() {
         div.style.display = checkbox.checked ? 'block' : 'none';
      });

      roundcheckbox.addEventListener('change', function() {
         rounddiv.style.display = roundcheckbox.checked ? 'block' : 'none';
      });

      fancycheckbox.addEventListener('change', function() {
         fancydiv.style.display = fancycheckbox.checked ? 'block' : 'none';
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/worker/create.blade.php ENDPATH**/ ?>