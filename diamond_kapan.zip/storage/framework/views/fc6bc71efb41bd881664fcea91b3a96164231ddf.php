<?php

use App\Models\Dimond;
use App\Models\Process;
?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<style>
  .dt-button.buttons-html5 {
    background-color: aliceblue;
  }
</style>
<?php $__env->stopSection(); ?>
<div class="row mt-3">
  <div class="col-lg-12 mx-auto">
    <div class="card">
      <div class="card-body">

        <div class="card-title">
          <h4>Worker Report</h4>
        </div>
        <hr>
        <?php if(session('success')): ?>
        <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
          <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:red">
          <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('generate-worker-pdf')); ?>" id="myWorkerForm" method="get">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-2">
              <div class="form-group">
                <label for="category">Category</label>
                <select name="category" id="category" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select category</option>
                  <option value="all" <?php echo e(request()->category == 'all' ? 'selected' : ''); ?>>ALL</option>
                  <option value="Inner" <?php echo e(request()->category == 'Inner' ? 'selected' : ''); ?>>Inner Worker</option>
                  <option value="Outter" <?php echo e(request()->category == 'Outter' ? 'selected' : ''); ?>>Outter Worker</option>
                </select>
                <?php if($errors->has('designation')): ?>
                <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-3">
              <div class="form-group">
                <label for="designation">Designation</label>
                <select name="designation" id="designation" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select designation</option>
                  <option value="all" <?php echo e(request()->designation == 'all' ? 'selected' : ''); ?>>ALL</option>
                  <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($designation->name); ?>" <?php echo e(request()->designation == $designation->name ? 'selected' : ''); ?>><?php echo e($designation->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('designation')): ?>
                <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-3">
              <div class="form-group">
                <label for="worker_name">Worker</label>
                <select name="worker_name" id="worker_name" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select worker</option>
                </select>
                <?php if($errors->has('worker_name')): ?>
                <div class="error text-danger"><?php echo e($errors->first('worker_name')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-3">
              <div class="form-group">
                <label for="which_diamond">Worker</label>
                <select name="which_diamond" id="which_diamond" class="custom-select form-control form-control-rounded" required>
                  <option value="delevery_date">Deliverd</option>
                  <option value="updated_at">Reguler</option>
                </select>
                <?php if($errors->has('worker_name')): ?>
                <div class="error text-danger"><?php echo e($errors->first('worker_name')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-2">
              <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" class="form-control form-control-rounded" id="start_date" value="<?php echo e(old('start_date')); ?>" required>
                <?php if($errors->has('start_date')): ?>
                <div class="error text-danger"><?php echo e($errors->first('start_date')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-2">
              <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" class="form-control form-control-rounded" id="end_date" value="<?php echo e(old('end_date')); ?>" required>
                <?php if($errors->has('end_date')): ?>
                <div class="error text-danger"><?php echo e($errors->first('end_date')); ?></div>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="form-group">
            <!-- <button type="submit" class="btn btn-light btn-round px-5">Generate PDF</button> -->
            <button type="button" id="get_list" class="btn btn-light btn-round px-5 mt-4">List</button>
            <button type="button" id="download_list" class="btn btn-light btn-round px-5 mt-4">Download</button>
            <a href="/admin/worker_report" class="btn btn-light btn-round px-5 mt-4">Clear</a>
          </div>
        </form>
      </div>
      <div>
        <?php if(count($data) > 0): ?>
        <?php $__currentLoopData = $worker_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <center>
          <h4 style="margin-top:20px"><?php echo e($worker->fname); ?>&nbsp;<?php echo e($worker->lname); ?></h4>
        </center>
        <div class="table-responsive">
          <table id="exportworkerTable_<?php echo e($worker->id); ?>" class="table align-items-center table-flush table-borderless">
            <thead>
              <tr>
                <th>Sr.</th>
                <th>Dimond Name</th>
                <th>Dimond barcode</th>
                <th>Issues Date</th>
                <th>Return Date</th>
                <th>Shape</th>
                <th>Issues Weight</th>
                <th>Return Weight</th>
                <th width="20%">Amount</th>
                <th>Created date</th>
                <th>Delivery date</th>
              </tr>
            </thead>
            <?php
            $p = 1;
            ?>
            <tbody>
              <?php
              $dimondsBarcodeArray = [];
              ?>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($worker->fname == $da->worker_name): ?>
              <?php
              $category = $_GET['category'];
              $getdimond = Dimond::where('barcode_number', $da->dimonds_barcode)->first();
              $which_diamond = $_GET['which_diamond'];
              if ($which_diamond == 'updated_at') {
                $rw = $da->return_weight;
              } else {
                $returndimond = Process::where('dimonds_barcode', $da->dimonds_barcode)->where('designation', 'Grading')->latest()->first();
                $rw = isset($returndimond->return_weight) ? $returndimond->return_weight : '';
              }

              if (isset($getdimond) && ($da->price != 0) && ($category == "Inner")) { ?>
                <tr>
                  <td><?php echo e($p); ?></td>
                  <td><?php echo e($da->dimonds->dimond_name); ?></td>
                  <td><?php echo e($da->dimonds_barcode); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($da->issue_date)->format('d-m-Y')); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($da->return_date)->format('d-m-Y')); ?></td>
                  <td><?php echo e($getdimond->shape); ?></td>
                  <td><?php echo e($da->issue_weight); ?></td>
                  <td><?php echo e(isset($rw) ? $rw : ''); ?></td>
                  <td><?php echo e($da->price); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($getdimond->created_at)->format('d-m-Y')); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($getdimond->delevery_date)->format('d-m-Y')); ?></td>
                  <?php
                  $p += 1;
                  ?>
                </tr>
              <?php } elseif ($category == "Outter" && !in_array($da->dimonds_barcode, $dimondsBarcodeArray)) {
                $dimondsBarcodeArray[] = $da->dimonds_barcode;
              ?>
                <tr>
                  <td><?php echo e($p); ?></td>
                  <td><?php echo e($da->dimonds->dimond_name); ?></td>
                  <td><?php echo e($da->dimonds_barcode); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($da->issue_date)->format('d-m-Y')); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($da->return_date)->format('d-m-Y')); ?></td>
                  <td><?php echo e($getdimond->shape); ?></td>
                  <td><?php echo e($da->issue_weight); ?></td>
                  <td><?php echo e(isset($rw) ? $rw : ''); ?></td>
                  <td><?php echo e($da->price); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($getdimond->created_at)->format('d-m-Y')); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($getdimond->delevery_date)->format('d-m-Y')); ?></td>
                  <?php
                  $p += 1;
                  ?>
                </tr>
                <?php } else {
                if ($da->price != 0) { ?>
                  <tr>
                    <td><?php echo e($p); ?></td>
                    <td><?php echo e($da->dimonds->dimond_name); ?></td>
                    <td><?php echo e($da->dimonds_barcode); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($da->issue_date)->format('d-m-Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($da->return_date)->format('d-m-Y')); ?></td>
                    <td><?php echo e($getdimond->shape); ?></td>
                    <td><?php echo e($da->issue_weight); ?></td>
                    <td><?php echo e(isset($rw) ? $rw : ''); ?></td>
                    <td><?php echo e($da->price); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($getdimond->created_at)->format('d-m-Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($getdimond->delevery_date)->format('d-m-Y')); ?></td>
                    <?php
                    $p += 1;
                    ?>
                  </tr>
              <?php }
              } ?>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        No Record Found
        <?php endif; ?>
      </div>
    </div>
  </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>

<script>
  $(document).ready(function() {
    <?php $__currentLoopData = $worker_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    $("#exportworkerTable_<?php echo e($worker->id); ?>").DataTable({
      dom: 'Blfrtip',
      buttons: [{
          extend: 'pdf',
        },
        {
          extend: 'csv',
        },
        {
          extend: 'excel',
        }
      ]
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  });
</script>

<script>
  $(document).ready(function() {
    $('#designation').change(function() {
      var designation = $(this).val();
      if (designation == 'all') {
        $('#worker_name').append('<option value="all" selected>ALL</option>');
      } else if (designation && designation != 'all') {
        $.ajax({
          type: 'POST',
          url: '/admin/get-workers',
          data: {
            '_token': '<?php echo e(csrf_token()); ?>',
            'designation': designation,
          },
          success: function(data) {
            $('#worker_name').empty();
            $('#worker_name').append('<option value="">Select worker</option><option value="all">ALL</option>');
            $.each(data, function(key, value) {
              $('#worker_name').append('<option value="' + value.fname + '">' + value.fname + ' ' + value.lname + '</option>');
            });
          }
        });
      } else {
        $('#worker_name').empty();
      }
    });
    $('#category').change(function() {
      var category = $(this).val();
      if (category) {
        $.ajax({
          type: 'POST',
          url: '/admin/get-designation',
          data: {
            '_token': '<?php echo e(csrf_token()); ?>',
            'category': category,
          },
          success: function(data) {
            $('#designation').empty();
            $('#designation').append('<option value="">Select designation</option><option value="all">ALL</option>');
            $.each(data, function(key, value) {
              $('#designation').append('<option value="' + value.name + '">' + value.name + '</option>');
            });
          }
        });
      } else {
        $('#designation').empty();
      }
    });
  });
</script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('myWorkerForm');
    var button1 = document.getElementById('get_list');
    var button2 = document.getElementById('download_list');

    button1.addEventListener('click', function() {
      if (document.getElementById('start_date').value == '') {
        alert("Enter Start date");
        return false;
      }

      if (document.getElementById('end_date').value == '') {
        alert("Enter End date");
        return false;
      }
      // Change the form action for button 1
      form.action = "<?php echo e(route('admin.worker.report')); ?>";
      // Submit the form
      form.submit();
    });

    button2.addEventListener('click', function() {
      if (document.getElementById('start_date').value == '') {
        alert("Enter Start date");
        return false;
      }

      if (document.getElementById('end_date').value == '') {
        alert("Enter End date");
        return false;
      }
      // Change the form action for button 2
      form.action = "<?php echo e(route('generate-worker-pdf')); ?>";
      // Submit the form
      form.submit();
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\dimond\resources\views/admin/reports/worker_report.blade.php ENDPATH**/ ?>