
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">ADD Invoice</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">ADD Invoice</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">ADD</h4>

                    <?php echo Form::open([
                        'method' => 'POST',
                        'action' => 'AdminInvoiceController@store',
                        'files' => true,
                        'class' => 'form-horizontal',
                        'name' => 'addinvoiceform',
                    ]); ?>

                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="parties_id">Party Name</label>
                                <select name="parties_id" id="parties_id" class="form-select" required>
                                    <option value="">Select Party</option>
                                    <?php $__currentLoopData = $partyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($party->id); ?>"><?php echo e($party->fname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('parties_id')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('parties_id')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="companies_id">Company Name</label>
                                <select name="companies_id" id="companies_id" class="form-select" required>
                                    <option value="">Select Company</option>
                                    <?php $__currentLoopData = $companyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('companies_id')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('companies_id')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="invoice_no">Invoice number</label>
                                <input type="text" name="invoice_no" class="form-control"
                                    id="invoice_no" placeholder="Enter Invoice number" value="<?php echo e(old('invoice_no')); ?>"
                                    required>
                                <?php if($errors->has('invoice_no')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('invoice_no')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="invoice_date">Invoice Date</label>
                                <input type="date" name="invoice_date" class="form-control"
                                    id="invoice_date" placeholder="Enter invoice date" value="<?php echo e(old('invoice_date')); ?>"
                                    required>
                                <?php if($errors->has('invoice_date')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('invoice_date')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="place_to_supply">Place To Supply</label>
                                <input type="text" name="place_to_supply" class="form-control"
                                    id="place_to_supply" placeholder="Enter Place To Supply"
                                    value="<?php echo e(old('place_to_supply')); ?>" required>
                                <?php if($errors->has('place_to_supply')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('place_to_supply')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="due_date">due_date</label>
                                <input type="date" name="due_date" class="form-control"
                                    id="due_date" required>
                                <?php if($errors->has('due_date')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('due_date')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-md">Submit</button>
                        <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/invoice')); ?>">Back</a>
                    </div>
                    </form>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $("form[name='addinvoiceform']").validate({
                rules: {
                    parties_id: {
                        required: true,
                    },
                    companies_id: {
                        required: true,
                    },
                    invoice_no: {
                        required: true,
                    },
                    invoice_date: {
                        required: true,
                    },
                    place_to_supply: {
                        required: true,
                    },
                    due_date: {
                        required: true,
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/invoice/create.blade.php ENDPATH**/ ?>