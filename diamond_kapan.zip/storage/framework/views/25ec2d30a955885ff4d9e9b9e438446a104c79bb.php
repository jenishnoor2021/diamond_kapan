
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
   <div class="col-lg-12 mx-auto">
      <div class="card">
         <div class="card-body">
            <div class="card-title">Edit Dimond</div>
            <hr>
            <?php echo Form::model($dimond, ['method'=>'PATCH', 'action'=> ['AdminDimondController@update', $dimond->id],'files'=>true,'class'=>'form-horizontal', 'name'=>'editdimondform']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="parties_id">Party</label>
                     <select name="parties_id" id="parties_id" class="custom-select" required>
                        <option value="">Select Party</option>
                        <?php $__currentLoopData = $partys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($party->id); ?>" <?php echo e($party->id == $dimond->parties_id ? 'selected' : ''); ?>><?php echo e($party->party_code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                     <?php if($errors->has('parties_id')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('parties_id')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="janger_no">Janger no</label>
                     <input type="text" name="janger_no" class="form-control" id="janger_no" placeholder="Enter Janger no" value="<?php echo e($dimond->janger_no); ?>" required>
                     <?php if($errors->has('janger_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('janger_no')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="dimond_name">Stone Id</label>
                     <input type="text" name="dimond_name" class="form-control" id="dimond_name" placeholder="Enter Stone Id" value="<?php echo e($dimond->dimond_name); ?>" required>
                     <?php if($errors->has('dimond_name')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('dimond_name')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="weight">Weight</label>
                     <input type="text" name="weight" class="form-control" id="weight" value="<?php echo e($dimond->weight); ?>" placeholder="00.00" oninput="formatWeight(this);" required>
                     <?php if($errors->has('weight')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('weight')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-2">
                  <div class="form-group">
                     <label for="required_weight">Polished Weight</label>
                     <input type="text" name="required_weight" class="form-control" id="required_weight" value="<?php echo e($dimond->required_weight); ?>" placeholder="00.00" oninput="formatWeight(this);" required>
                     <?php if($errors->has('required_weight')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('required_weight')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="shape">Shape</label>
                     <select name="shape" id="shape" class="custom-select" required>
                        <!-- <option value="">Select shape</option> -->
                        <option value="Modifiy" <?php echo e($dimond->shape == 'Modifiy' ? 'selected' : ''); ?>>Modifiy</option>
                        <option value="Round" <?php echo e($dimond->shape == 'Round' ? 'selected' : ''); ?>>Round</option>
                        <option value="Oval" <?php echo e($dimond->shape == 'Oval' ? 'selected' : ''); ?>>Oval</option>
                        <option value="Pear" <?php echo e($dimond->shape == 'Pear' ? 'selected' : ''); ?>>Pear</option>
                        <option value="Cush Mod" <?php echo e($dimond->shape == 'Cush Mod' ? 'selected' : ''); ?>>Cush Mod</option>
                        <option value="Cush Brill" <?php echo e($dimond->shape == 'Cush Brill' ? 'selected' : ''); ?>>Cush Brill</option>
                        <option value="Emeraid" <?php echo e($dimond->shape == 'Emeraid' ? 'selected' : ''); ?>>Emeraid</option>
                        <option value="Radiant" <?php echo e($dimond->shape == 'Radiant' ? 'selected' : ''); ?>>Radiant</option>
                        <option value="Princess" <?php echo e($dimond->shape == 'Princess' ? 'selected' : ''); ?>>Princess</option>
                        <option value="Asscher" <?php echo e($dimond->shape == 'Asscher' ? 'selected' : ''); ?>>Asscher</option>
                        <option value="Square" <?php echo e($dimond->shape == 'Square' ? 'selected' : ''); ?>>Square</option>
                        <option value="Marquise" <?php echo e($dimond->shape == 'Marquise' ? 'selected' : ''); ?>>Marquise</option>
                        <option value="Heart" <?php echo e($dimond->shape == 'Heart' ? 'selected' : ''); ?>>Heart</option>
                        <option value="Trilliant" <?php echo e($dimond->shape == 'Trilliant' ? 'selected' : ''); ?>>Trilliant</option>
                        <option value="Euro Cut" <?php echo e($dimond->shape == 'Euro Cut' ? 'selected' : ''); ?>>Euro Cut</option>
                        <option value="Old Miner" <?php echo e($dimond->shape == 'Old Miner' ? 'selected' : ''); ?>>Old Miner</option>
                        <option value="Briolette" <?php echo e($dimond->shape == 'Briolette' ? 'selected' : ''); ?>>Briolette</option>
                     </select>
                     <?php if($errors->has('shape')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('shape')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="clarity">Clarity</label>
                     <select name="clarity" id="clarity" class="custom-select" required>
                        <!-- <option value="">Select clarity</option> -->
                        <option value="FL" <?php echo e($dimond->clarity == 'FL' ? 'selected' : ''); ?>>FL</option>
                        <option value="IF" <?php echo e($dimond->clarity == 'IF' ? 'selected' : ''); ?>>IF</option>
                        <option value="VVS1" <?php echo e($dimond->clarity == 'VVS1' ? 'selected' : ''); ?>>VVS1</option>
                        <option value="VVS2" <?php echo e($dimond->clarity == 'VVS2' ? 'selected' : ''); ?>>VVS2</option>
                        <option value="VS1" <?php echo e($dimond->clarity == 'VS1' ? 'selected' : ''); ?>>VS1</option>
                        <option value="VS2" <?php echo e($dimond->clarity == 'VS2' ? 'selected' : ''); ?>>VS2</option>
                        <option value="SI1" <?php echo e($dimond->clarity == 'SI1' ? 'selected' : ''); ?>>SI1</option>
                        <option value="SI2" <?php echo e($dimond->clarity == 'SI2' ? 'selected' : ''); ?>>SI2</option>
                        <option value="SI3" <?php echo e($dimond->clarity == 'SI3' ? 'selected' : ''); ?>>SI3</option>
                        <option value="I1" <?php echo e($dimond->clarity == 'I1' ? 'selected' : ''); ?>>I1</option>
                        <option value="I2" <?php echo e($dimond->clarity == 'I2' ? 'selected' : ''); ?>>I2</option>
                        <option value="I3" <?php echo e($dimond->clarity == 'I3' ? 'selected' : ''); ?>>I3</option>
                     </select>
                     <?php if($errors->has('clarity')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('clarity')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="color">Color</label>
                     <select name="color" id="color" class="custom-select" required>
                        <!-- <option value="">Select color</option> -->
                        <option value="D" <?php echo e($dimond->color == 'D' ? 'selected' : ''); ?>>D</option>
                        <option value="E" <?php echo e($dimond->color == 'E' ? 'selected' : ''); ?>>E</option>
                        <option value="F" <?php echo e($dimond->color == 'F' ? 'selected' : ''); ?>>F</option>
                        <option value="G" <?php echo e($dimond->color == 'G' ? 'selected' : ''); ?>>G</option>
                        <option value="H" <?php echo e($dimond->color == 'H' ? 'selected' : ''); ?>>H</option>
                        <option value="I" <?php echo e($dimond->color == 'I' ? 'selected' : ''); ?>>I</option>
                        <option value="J" <?php echo e($dimond->color == 'J' ? 'selected' : ''); ?>>J</option>
                        <option value="K" <?php echo e($dimond->color == 'K' ? 'selected' : ''); ?>>K</option>
                        <option value="L" <?php echo e($dimond->color == 'L' ? 'selected' : ''); ?>>L</option>
                        <option value="M" <?php echo e($dimond->color == 'M' ? 'selected' : ''); ?>>M</option>
                        <option value="N" <?php echo e($dimond->color == 'N' ? 'selected' : ''); ?>>N</option>
                        <option value="O" <?php echo e($dimond->color == 'O' ? 'selected' : ''); ?>>O</option>
                        <option value="P" <?php echo e($dimond->color == 'P' ? 'selected' : ''); ?>>P</option>
                        <option value="Q" <?php echo e($dimond->color == 'Q' ? 'selected' : ''); ?>>Q</option>
                        <option value="R" <?php echo e($dimond->color == 'R' ? 'selected' : ''); ?>>R</option>
                        <option value="S" <?php echo e($dimond->color == 'S' ? 'selected' : ''); ?>>S</option>
                     </select>
                     <?php if($errors->has('color')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('color')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="cut">Cut</label>
                     <select name="cut" id="cut" class="custom-select" required>
                        <option value="EX" <?php echo e($dimond->cut == 'EX' ? 'selected' : ''); ?>>EX</option>
                        <option value="Ideal" <?php echo e($dimond->cut == 'Ideal' ? 'selected' : ''); ?>>Ideal</option>
                        <option value="VG" <?php echo e($dimond->cut == 'VG' ? 'selected' : ''); ?>>VG</option>
                        <option value="GD" <?php echo e($dimond->cut == 'GD' ? 'selected' : ''); ?>>GD</option>
                     </select>
                     <?php if($errors->has('cut')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('cut')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="polish">Polish</label>
                     <select name="polish" id="polish" class="custom-select" required>
                        <option value="EX" <?php echo e($dimond->polish == 'EX' ? 'selected' : ''); ?>>EX</option>
                        <option value="Ideal" <?php echo e($dimond->polish == 'Ideal' ? 'selected' : ''); ?>>Ideal</option>
                        <option value="VG" <?php echo e($dimond->polish == 'VG' ? 'selected' : ''); ?>>VG</option>
                        <option value="GD" <?php echo e($dimond->polish == 'GD' ? 'selected' : ''); ?>>GD</option>
                     </select>
                     <?php if($errors->has('polish')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('polish')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="symmetry">Symmetry</label>
                     <select name="symmetry" id="symmetry" class="custom-select" required>
                        <option value="EX" <?php echo e($dimond->symmetry == 'EX' ? 'selected' : ''); ?>>EX</option>
                        <option value="Ideal" <?php echo e($dimond->symmetry == 'Ideal' ? 'selected' : ''); ?>>Ideal</option>
                        <option value="VG" <?php echo e($dimond->symmetry == 'VG' ? 'selected' : ''); ?>>VG</option>
                        <option value="GD" <?php echo e($dimond->symmetry == 'GD' ? 'selected' : ''); ?>>GD</option>
                     </select>
                     <?php if($errors->has('symmetry')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('symmetry')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="form-group">
               <button type="submit" class="btn btn-light btn-round px-5">Update</button>
            </div>
            </form>
         </div>
      </div>
   </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editdimondform']").validate({
         rules: {
            parties_id: {
               required: true,
            },
            dimond_name: {
               required: true,
            },
            janger_no: {
               required: true,
            },
            shape: {
               required: true,
            },
            weight: {
               required: true,
            },
            clarity: {
               required: true,
            },
            color: {
               required: true,
            },
            cut: {
               required: true,
            },
            polish: {
               required: true,
            },
            symmetry: {
               required: true,
            }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<script>
   function formatWeight(input) {
      // Remove any non-numeric characters
      var cleanedValue = input.value.replace(/[^0-9.]/g, '');

      // Ensure valid pattern: either empty, '0.00', or '00.00'
      var match = cleanedValue.match(/^(\d{0,2}(\.\d{0,2})?)?$/);

      // Update the input value with the formatted result
      input.value = match ? match[1] || '' : '';
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/dimond/edit.blade.php ENDPATH**/ ?>