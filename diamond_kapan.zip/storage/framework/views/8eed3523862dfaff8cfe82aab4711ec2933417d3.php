
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <h4 class="mb-sm-0 font-size-18">Sub Division</h4>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">

        <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('admin.sub-division.index')); ?>" method="get">
          <?php echo csrf_field(); ?>

          <div data-repeater-list="group-a">
            <div data-repeater-item class="row">
              <div class="col-lg-2">
                <label for="kapans_id">Kapan</label>
                <select name="kapans_id" id="kapans_id" class="form-select" required>
                  <option value="">Select Kapan</option>
                  <?php $__currentLoopData = $kapans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kapan->id); ?>" <?php echo e(request()->kapans_id == $kapan->id ? 'selected' : ''); ?>><?php echo e($kapan->kapan_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('kapans_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('kapans_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="col-lg-3">
                <label for="kapan_parts_id">Kapan Part</label>
                <select name="kapan_parts_id" id="kapan_parts_id" class="form-select" required>
                  <?php if(request('kapan_parts_id')): ?>
                  <?php $__currentLoopData = $kapan_parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapanPa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kapanPa->id); ?>" <?php echo e(request()->kapan_parts_id == $kapanPa->id ? 'selected' : ''); ?>>
                    <?php echo e($kapanPa->name); ?>

                    <?php if($kapanPa->diamond_count > 0): ?>
                    &nbsp;&nbsp;&nbsp;(<span class="text-success"><?php echo e($kapanPa->diamond_count); ?></span> 💎)
                    <?php else: ?>
                    &nbsp;&nbsp;&nbsp;(0 💎)
                    <?php endif; ?>
                  </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <option value="">Select Kapan Part</option>
                  <?php endif; ?>
                </select>
                <?php if($errors->has('kapan_parts_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('kapan_parts_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="col-lg-2">
                <button class="btn btn-primary">Submit</button>
                <a href="<?php echo e(route('admin.sub-division.index')); ?>" class="btn btn-light">Clear</a>
              </div>

            </div>

          </div>
        </form>

        <?php if(request('kapans_id') && request('kapan_parts_id') && $kapanPart): ?>
        <div class="card mb-3">
          <div class="card-body">
            <div class="row text-center">

              <div class="col-md-2">
                <h6 class="text-muted mb-1">Kapan Name</h6>
                <h5 class="fw-bold">
                  <?php echo e($kapans->where('id', request('kapans_id'))->first()->kapan_name ?? '-'); ?>

                </h5>
              </div>

              <div class="col-md-2">
                <h6 class="text-muted mb-1">Kapan Part Name</h6>
                <h5 class="fw-bold">
                  <?php echo e($kapanPart ? $kapanPart->name : '-'); ?>

                </h5>
              </div>

              <div class="col-md-2">
                <h6 class="text-muted mb-1">Row weight</h6>
                <h5 class="fw-bold text-primary">
                  <?php echo e(number_format($kapanPart->weight, 2)); ?>

                </h5>
              </div>

              <!-- used Weight -->
              <!-- <div class="col-md-2">
                <h6 class="text-muted mb-1">Used Weight</h6>
                <h5 class="fw-bold text-success">
                  <?php echo e(number_format($usedWeight, 2)); ?>

                </h5>
              </div> -->

              <!-- addition of pridiction weight -->
              <div class="col-md-2">
                <h6 class="text-muted mb-1">Plan Weight</h6>
                <h5 class="fw-bold text-success">
                  <?php echo e(number_format($totalPWeight, 2)); ?>

                </h5>
              </div>

              <!-- total pridiction weight - row weight -->
              <div class="col-md-2">
                <h6 class="text-muted mb-1">Loss Weight</h6>
                <?php
                $rawWeight = $kapanPart->weight ?? 0;
                $lossWeight = max($rawWeight - $totalPWeight, 0);
                ?>
                <h5 class="fw-bold text-danger">
                  <?php echo e(number_format($lossWeight, 2)); ?>

                </h5>
              </div>

              <div class="col-md-2">
                <h6 class="text-muted mb-1">Planing %</h6>
                <?php
                $lossPer = $rawWeight > 0
                ? ($totalPWeight * 100) / $rawWeight
                : 0;
                ?>
                <h5 class="fw-bold text-warning">
                  <?php echo e(number_format($lossPer, 2)); ?> %
                </h5>
              </div>

            </div>
          </div>
        </div>
        <?php endif; ?>

      </div>
    </div>

    <?php if(request('kapans_id')): ?>
    <div class="card">
      <div class="card-body">

        <table class="table table-bordered mt-3">
          <thead>
            <tr>
              <th>Name</th>
              <!-- <th>Weight</th> -->
              <th>Prediction weight</th>
              <th>Shap</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $diamonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diamond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <?php if(request('edit') == $diamond->id): ?>

              <form method="POST" action="<?php echo e(route('admin.diamond.update', $diamond->id)); ?>">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="kapans_id" value="<?php echo e(request('kapans_id')); ?>">
                <input type="hidden" name="kapan_parts_id" value="<?php echo e(request('kapan_parts_id')); ?>">

                <td>
                  <input type="text" name="diamond_name" value="<?php echo e($diamond->diamond_name); ?>" placeholder="Enter name" class="form-control">
                </td>
                <!-- <td>
                  <input type="number" step="0.01" name="weight" value="<?php echo e($diamond->weight); ?>" placeholder="Enter weight" class="form-control">
                </td> -->
                <td>
                  <input type="number" step="0.01" name="prediction_weight" placeholder="Enter prediction weight" value="<?php echo e($diamond->prediction_weight); ?>" class="form-control">
                </td>
                <td>
                  <select name="shape" id="shape" class="form-select" required>
                    <?php $__currentLoopData = $shapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($shape->id); ?>" <?php echo e($shape->id == $diamond->shape ? 'selected' : ''); ?>><?php echo e($shape->shape_type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </td>
                <td>
                  <button class="btn btn-success btn-sm">Save</button>
                  <a href="<?php echo e(route('admin.sub-division.index', request()->except('edit'))); ?>"
                    class="btn btn-secondary btn-sm">Cancel</a>
                </td>
              </form>

              <?php else: ?>
              <td><?php echo e($diamond->diamond_name); ?></td>
              <!-- <td><?php echo e($diamond->weight); ?></td> -->
              <td><?php echo e($diamond->prediction_weight); ?></td>
              <td><?php echo e($diamond->shapes->shape_type); ?></td>
              <td>
                <a href="<?php echo e(route('admin.sub-division.index', array_merge(request()->all(), ['edit' => $diamond->id]))); ?>"
                  class="btn btn-warning btn-sm">Edit</a>

                <form method="POST" action="<?php echo e(route('admin.diamond.delete', $diamond->id)); ?>"
                  class="d-inline">
                  <?php echo csrf_field(); ?>

                  <input type="hidden" name="kapans_id" value="<?php echo e(request('kapans_id')); ?>">
                  <input type="hidden" name="kapan_parts_id" value="<?php echo e(request('kapan_parts_id')); ?>">

                  <button class="btn btn-danger btn-sm"
                    onclick="return confirm('Delete this diamond?')">Delete</button>
                </form>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        <?php if(request('kapans_id') && request('kapan_parts_id') && !request('edit')): ?>
        <form method="POST" action="<?php echo e(route('admin.diamond.store')); ?>" id="addDiamondForm"
          data-total-weight="<?php echo e($kapanPart->weight); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="kapans_id" value="<?php echo e(request('kapans_id')); ?>">
          <input type="hidden" name="kapan_parts_id" value="<?php echo e(request('kapan_parts_id')); ?>">

          <table class="table">
            <tbody>
              <tr>
                <?php
                $diamondCount = $diamonds->count(); // existing diamonds
                $nextAlphabet = chr(65 + $diamondCount); // 65 = 'A'
                ?>

                <td width="12%">
                  <input name="diamond_name" class="form-control" placeholder="Enter name" value="<?php echo e($nextAlphabet); ?>" required>
                  <span class="text-danger" style="font-size:10px;">Just Enter alphbets</span>
                </td>
                <!-- <td width="12%"><input type="number" name="weight" step="0.01" class="form-control" placeholder="Enter weight"></td> -->
                <td width="12%"><input type="number" name="prediction_weight" step="0.01" class="form-control" placeholder="Enter prediction weight" required>
                </td>
                <td width="12%">
                  <select name="shape" id="shape" class="form-select" required>
                    <?php $__currentLoopData = $shapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($shape->id); ?>"><?php echo e($shape->shape_type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </td>
                <?php $disabled = $remainingWeight <= 0; ?>

                  <td width="15%">
                  <button
                    type="submit"
                    class="btn btn-primary btn-sm me-1"
                    <?php echo e($disabled ? 'disabled' : ''); ?>>
                    Add
                  </button>

                  <button
                    type="button"
                    onclick="location.reload();"
                    class="btn btn-light btn-sm"
                    <?php echo e($disabled ? 'disabled' : ''); ?>>
                    Clear
                  </button>
                  </td>
              </tr>
            </tbody>
          </table>
        </form>
        <?php endif; ?>

      </div>
    </div>
    <?php endif; ?>

  </div>
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(document).ready(function() {
    $('#kapans_id').change(function() {

      var kapan = $(this).val();
      $('#kapan_parts_id').empty();

      if (!kapan || kapan === 'all') {
        $('#kapan_parts_id').append('<option value="">Select kapan part</option>');
        $('#diamondTable tbody').html('');
        $('#addDiamondBtn').addClass('d-none');
        return;
      }

      $.ajax({
        type: 'POST',
        url: '/admin/get-kapan-parts',
        data: {
          _token: '<?php echo e(csrf_token()); ?>',
          kapans_id: kapan
        },
        success: function(data) {

          $('#kapan_parts_id').append('<option value="">Select kapan part</option>');

          $.each(data, function(index, value) {

            const label = value.diamond_count > 0 ?
              `${value.name} &nbsp;&nbsp;&nbsp;(${value.diamond_count} 💎 )` :
              `${value.name} &nbsp;&nbsp;&nbsp;(0 💎)`;

            $('#kapan_parts_id').append(
              `<option value="${value.id}">
                ${label}
              </option>`
            );
          });
        }
      });
    });
  });
</script>

<script>
  $(document).ready(function() {

    $('#addDiamondForm').on('submit', function(e) {

      const totalWeight = parseFloat($(this).data('total-weight')) || 0;
      // const usedWeight = parseFloat($(this).data('used-weight')) || 0;

      // const weight = parseFloat($('input[name="weight"]').val()) || 0;
      const predictionWeight = parseFloat($('input[name="prediction_weight"]').val()) || 0;

      // Rule 1: Prediction <= Weight
      if (predictionWeight > totalWeight) {
        alert('Prediction weight cannot be greater than diamond weight.');
        e.preventDefault();
        return false;
      }

      // Rule 2: Used + New <= Kapan Part Weight
      // if ((usedWeight + weight) > totalWeight) {
      //   alert(
      //     'Total weight exceeds Kapan Part weight.\n\n' +
      //     'Remaining Weight: ' + (totalWeight - usedWeight).toFixed(2)
      //   );
      //   e.preventDefault();
      //   return false;
      // }
    });

  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/diamond/sub_division.blade.php ENDPATH**/ ?>