
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
   <div class="col-lg-8 mx-auto">
      <div class="card">
         <div class="card-body">
            <div class="card-title">ADD Party</div>
            <hr>
            <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminPartyController@store','files'=>true,'class'=>'form-horizontal','name'=>'addpartyform']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-6">
                  <div class="form-group">
                     <label for="fname">First Name</label>
                     <input type="text" name="fname" class="form-control form-control-rounded" id="fname" placeholder="Enter First Name" onkeypress='return (event.charCode != 32)' value="<?php echo e(old('fname')); ?>" required>
                     <?php if($errors->has('fname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('fname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-6">
                  <div class="form-group">
                     <label for="lname">Last Name</label>
                     <input type="text" name="lname" class="form-control form-control-rounded" id="lname" placeholder="Enter Last Name" onkeypress='return (event.charCode != 32)' value="<?php echo e(old('lname')); ?>" required>
                     <?php if($errors->has('lname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('lname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="form-group">
               <label for="party_code">Party Code</label>
               <input type="text" name="party_code" class="form-control form-control-rounded" id="party_code" placeholder="Enter party code" onkeypress='return (event.charCode != 32)' value="<?php echo e(old('party_code')); ?>" required>
               <?php if($errors->has('party_code')): ?>
               <div class="error text-danger"><?php echo e($errors->first('party_code')); ?></div>
               <?php endif; ?>
            </div>
            <div class="form-group">
               <label for="address">Address</label>
               <textarea type="text" name="address" class="form-control form-control-rounded" id="address" placeholder="Enter Address" required><?php echo e(old('address')); ?></textarea>
               <?php if($errors->has('address')): ?>
               <div class="error text-danger"><?php echo e($errors->first('address')); ?></div>
               <?php endif; ?>
            </div>
            <div class="row">
               <div class="col-6">
                  <div class="form-group">
                     <label for="mobile">Mobile no</label>
                     <input type="number" name="mobile" class="form-control form-control-rounded" id="mobile" placeholder="Enter number" value="<?php echo e(old('mobile')); ?>" required>
                     <?php if($errors->has('mobile')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('mobile')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-6">
                  <div class="form-group">
                     <label for="gst_no">GST No</label>
                     <input type="text" name="gst_no" class="form-control form-control-rounded" id="gst_no" placeholder="Enter GST No" value="<?php echo e(old('fname')); ?>">
                  </div>
               </div>
            </div>
            <div class="form-group">
               <button type="submit" class="btn btn-light btn-round px-5"><i class="fa fa-plus"></i> ADD</button>
            </div>
            </form>
         </div>
      </div>
   </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='addpartyform']").validate({
         rules: {
            fname: {
               required: true,
            },
            lname: {
               required: true,
            },
            address: {
               required: true,
            },
            mobile: {
               required: true,
            },
            party_code: {
               required: true,
            }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\dimond\resources\views/admin/party/create.blade.php ENDPATH**/ ?>