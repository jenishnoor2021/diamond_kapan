
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
  <div class="col-lg-3">
    <div class="card">
      <div class="card-body">
        <?php if(session()->has('message')): ?>
        <div class="alert text-white" style="background-color:green">
          <?php echo e(session()->get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card-title">
          <h4>Generate Worker Barcode</h4>
        </div>
        <hr>
        <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminWorkerBarcodeController@store','files'=>true,'class'=>'form-horizontal','name'=>'workerbarcodeform']); ?>

        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="category">Worker List</label>
          <select name="worker_id" id="worker_id" class="custom-select form-control form-control-rounded" style="width:100%" required>
            <option value="">Select worker</option>
            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->fname); ?> <?php echo e($worker->lname); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php if($errors->has('worker_id')): ?>
          <div class="error text-danger"><?php echo e($errors->first('worker_id')); ?></div>
          <?php endif; ?>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-light btn-round px-5"><i class="fa fa-plus"></i> Generate Barcode</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-9">
    <div class="card">
      <?php if(session('success')): ?>
      <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
        <?php echo e(session('success')); ?>

      </div>
      <?php endif; ?>
      <div class="card-header d-flex justify-content-between align-items-center">
        <h4>Worker Barcode List</h4>
      </div>
      <div class="table-responsive">
        <table id="workerbarcodelist" class="table align-items-center table-flush table-borderless">
          <thead>
            <tr>
              <th>Action</th>
              <th>Print</th>
              <th>Worker Name</th>
              <th>Barcode</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $barcodeLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcodeList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <a href="<?php echo e(route('admin.worker-barcode.edit', $barcodeList->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:#0275d8;padding:8px;border-radius:500px;"></i></a>
                <a href="<?php echo e(route('admin.worker-barcode.destroy', $barcodeList->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:red;padding:8px;border-radius:500px;"></i></a>
              </td>
              <td>
                <a href="/admin/print-worker-barcode/<?php echo e($barcodeList->id); ?>" target="_blank" class="btn btn-secondary">Print</a>
              </td>
              <td><?php echo e($barcodeList->worker->fname); ?>&nbsp;<?php echo e($barcodeList->worker->lname); ?></td>
              <td><?php echo e($barcodeList->barcode); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(function() {
    $("form[name='workerbarcodeform']").validate({
      rules: {
        worker_id: {
          required: true,
        },
      },
      submitHandler: function(form) {
        form.submit();
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\diamondhr\resources\views/admin/worker_barcode/index.blade.php ENDPATH**/ ?>