
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-2">
        <h4 class="mb-0 font-size-18">Return</h4>

        <a href="<?php echo e(route('admin.diamonds.index')); ?>" class="btn btn-sm btn-primary">
          <i class="mdi mdi-arrow-right-bold-circle-outline me-1"></i> Diamonds List
        </a>

        <a href="<?php echo e(route('admin.issue.index')); ?>" class="btn btn-sm btn-success">
          <i class="mdi mdi-arrow-left-bold-circle-outline me-1"></i> Issue
        </a>

        <a href="<?php echo e(route('admin.return.index')); ?>" class="btn btn-sm btn-danger">
          <i class="mdi mdi-arrow-left-bold-circle-outline me-1"></i> Return
        </a>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">

        <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('admin.return.index')); ?>" method="get">
          <?php echo csrf_field(); ?>

          <div data-repeater-list="group-a">
            <div data-repeater-item class="row">
              <div class="mb-3 col-lg-2">
                <label for="designation">Designation</label>
                <select name="designation" id="designation" class="form-select" required>
                  <option value="">Select designation</option>
                  <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($designation->id); ?>" <?php echo e(request()->designation == $designation->id ? 'selected' : ''); ?>><?php echo e($designation->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('designation')): ?>
                <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                <?php endif; ?>
              </div>

              <div class="mb-3 col-lg-2">
                <label for="worker_id">Worker</label>
                <select name="worker_id" id="worker_id" class="form-select" required>
                  <?php if(request('worker_id')): ?>
                  <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($worker->id); ?>" <?php echo e(request()->worker_id == $worker->id ? 'selected' : ''); ?>><?php echo e($worker->fname); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <option value="">Select worker</option>
                  <?php endif; ?>
                </select>
                <?php if($errors->has('worker_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('worker_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="mb-3 col-lg-2">
                <label for="kapans_id">Kapan</label>
                <select name="kapans_id" id="kapans_id" class="form-select">
                  <option value="">Select Kapan</option>
                  <?php $__currentLoopData = $kapans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kapan->id); ?>" <?php echo e(request()->kapans_id == $kapan->id ? 'selected' : ''); ?>><?php echo e($kapan->kapan_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('kapans_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('kapans_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="mb-3 col-lg-3">
                <label for="kapan_parts_id">Kapan Part</label>
                <select name="kapan_parts_id" id="kapan_parts_id" class="form-select">
                  <?php if(request('kapans_id')): ?>
                  <option value="">ALL</option>
                  <?php $__currentLoopData = $kapan_parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapanPa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kapanPa->id); ?>" <?php echo e(request()->kapan_parts_id == $kapanPa->id ? 'selected' : ''); ?>><?php echo e($kapanPa->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <option value="">Select Kapan Part</option>
                  <?php endif; ?>
                </select>
                <?php if($errors->has('kapan_parts_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('kapan_parts_id')); ?></div>
                <?php endif; ?>
              </div>

              <div class="mb-3 col-lg-2">
                <button class="btn btn-primary">Submit</button>
                <!-- <a href="<?php echo e(route('admin.return.index')); ?>" class="btn btn-light">Clear</a> -->
              </div>

            </div>

          </div>
        </form>
      </div>
    </div>

    <?php if(count($issues) > 0): ?>
    <div class="card">
      <div class="card-body">

        <?php if($issues->count()): ?>
        <table id="datatable" class="table table-bordered">
          <thead>
            <tr>
              <th>Diamond Name</th>
              <?php if(request('designation') != '3'): ?>
              <th>Return Weight</th>
              <th>Return Date</th>
              <th>Action</th>
              <?php else: ?>
              <th>Button</th>
              <?php endif; ?>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <form method="POST" action="<?php echo e(route('admin.return.store')); ?>">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="issue_id" value="<?php echo e($issue->id); ?>">

                <td><?php echo e($issue->diamond->diamond_name); ?></td>

                <?php if(request('designation') != '3'): ?>
                <td>
                  <input type="number"
                    step="0.01"
                    name="return_weight"
                    class="form-control return-weight"
                    value=""
                    max="<?php echo e($issue->diamond->prediction_weight); ?>"
                    data-issue-weight="<?php echo e($issue->diamond->prediction_weight); ?>"
                    placeholder="returm weight"
                    required>
                </td>

                <td>
                  <input type="date"
                    name="return_date"
                    class="form-control return-date"
                    value="<?php echo e(now()->toDateString()); ?>"
                    min="<?php echo e(\Carbon\Carbon::parse($issue->issue_date)->toDateString()); ?>"
                    data-issue-date="<?php echo e(\Carbon\Carbon::parse($issue->issue_date)->toDateString()); ?>"
                    required>
                </td>
                <td>
                  <button class="btn btn-success btn-sm">
                    Save
                  </button>
                </td>
                <?php else: ?>
                <td>
                  <button type="button"
                    class="btn btn-sm btn-info certificateBtn"
                    data-bs-toggle="modal"
                    data-bs-target="#certificateModal"
                    data-id="<?php echo e($issue->id); ?>"
                    data-diamonds_id="<?php echo e($issue->diamonds_id); ?>">
                    Add & save
                  </button>
                </td>
                <?php endif; ?>
              </form>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php endif; ?>

      </div>
    </div>
    <?php elseif(request()->designation != ''): ?>
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <span class="text-danger">No record found</span>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>


<div class="modal fade" id="certificateModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-lg">
    <form method="POST" action="<?php echo e(route('admin.return.store')); ?>">
      <?php echo csrf_field(); ?>

      <input type="hidden" name="issue_id" id="issue_id">
      <input type="hidden" name="diamonds_id" id="diamonds_id">

      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Return from certificate Diamond</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <div class="row">

            <div class="col-md-4 mb-2">
              <label>Certificate #</label>
              <input type="text" name="certi_no" id="certi_no" class="form-control" placeholder="Enter certi no" required>
            </div>

            <div class="col-md-4 mb-2">
              <label>Certificate Url</label>
              <input type="text" name="Certificate_url" class="form-control" placeholder="Enter Certificate Url" required>
            </div>

            <div class="col-md-4 mb-2">
              <label>Availability</label>
              <input type="text" name="availability" id="availability" class="form-control" placeholder="Enter ceavailability" required>
            </div>

            <div class="col-md-4 mb-2">
              <label>Return Weight</label>
              <input type="number"
                step="0.01"
                name="return_weight"
                class="form-control return-weight"
                id="return_weight"
                value=""
                max=""
                data-issue-weight=""
                placeholder="returm weight"
                required>
            </div>

            <div class="col-md-4 mb-2">
              <label>Return Date</label>
              <input type="date"
                name="return_date"
                class="form-control return-date"
                value="<?php echo e(now()->toDateString()); ?>"
                min=""
                data-issue-date=""
                required>
            </div>

            <div class="col-md-4 mb-2">
              <label>Shape</label>
              <select name="r_shape" id="r_shape" class="form-select" required>
                <?php $__currentLoopData = $shapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($shape->shape_type); ?>"><?php echo e($shape->shape_type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>Color</label>
              <select name="r_color" id="r_color" class="form-select" required>
                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($color->c_name); ?>"><?php echo e($color->c_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>Clarity</label>
              <select name="r_clarity" id="r_clarity" class="form-select" required>
                <?php $__currentLoopData = $clarity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($clar->name); ?>"><?php echo e($clar->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>Polish</label>
              <select name="r_polish" id="r_polish" class="form-select" required>
                <?php $__currentLoopData = $polish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pol->name); ?>"><?php echo e($pol->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>Symmetry</label>
              <select name="r_symmetry" id="r_symmetry" class="form-select" required>
                <?php $__currentLoopData = $symmetry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($symme->name); ?>"><?php echo e($symme->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>Price</label>
              <input type="number" step="0.01" name="price" id="price" class="form-control" placeholder="Enter Price">
            </div>

            <div class="col-md-4 mb-2">
              <label>Total price</label>
              <input type="number" step="0.01" name="total_price" id="total_price" class="form-control" placeholder="Enter total price">
            </div>

            <div class="col-md-4 mb-2">
              <label>Image Link</label>
              <input type="text" name="image_link" class="form-control" placeholder="Enter image link">
            </div>

            <div class="col-md-4 mb-2">
              <label>video Link</label>
              <input type="text" name="video_link" class="form-control" placeholder="Enter video link">
            </div>

            <div class="col-md-4 mb-2">
              <label>Depth Percent</label>
              <input type="number" step="0.01" name="depth_percent" class="form-control" placeholder="Enter depth percent">
            </div>

            <div class="col-md-4 mb-2">
              <label>Table Percent</label>
              <input type="number" step="0.01" name="table_percent" class="form-control" placeholder="Enter table percent">
            </div>

            <div class="col-md-4 mb-2">
              <label>Fluorescence Intensity</label>
              <input type="text" name="fluorescence_intensity" class="form-control" placeholder="Enter fluorescence intensity">
            </div>

            <div class="col-md-4 mb-2">
              <label>Lab</label>
              <input type="text" name="lab" class="form-control" placeholder="Enter Lab">
            </div>

            <div class="col-md-4 mb-2">
              <label>Measurements</label>
              <input type="text" name="measurements" class="form-control" placeholder="Enter measurements">
            </div>

            <div class="col-md-4 mb-2">
              <label>BGM</label>
              <input type="text" name="bgm" class="form-control" placeholder="None">
            </div>

            <div class="col-md-4 mb-2">
              <label>H&A</label>
              <select name="h_and_a" id="h_and_a" class="form-select">
                <option value="No">No</option>
                <option value="Yes">Yes</option>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>City</label>
              <select name="city" id="city" class="form-select" required>
                <option value="SURAT">SURAT</option>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>State</label>
              <select name="state" id="state" class="form-select" required>
                <option value="GUJARAT">GUJARAT</option>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>Country</label>
              <select name="country" id="country" class="form-select">
                <option value="India">India</option>
              </select>
            </div>


            <div class="col-md-4 mb-2">
              <label>Eye Clean</label>
              <select name="eye_clean" id="eye_clean" class="form-select">
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>

            <div class="col-md-4 mb-2">
              <label>Growth Type</label>
              <input type="text" name="growth_type" class="form-control" placeholder="CVD">
            </div>

          </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>

      </div>
    </form>
  </div>
</div>


<!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(document).ready(function() {
    $('#designation').change(function() {
      var designation = $(this).val();
      $('#worker_id').empty();

      if (designation == 'all') {
        $('#worker_id').append('<option value="">Select worker</option>');
      } else if (designation && designation != 'all') {
        $.ajax({
          type: 'POST',
          url: '/admin/get-workers',
          data: {
            '_token': '<?php echo e(csrf_token()); ?>',
            'designation': designation,
          },
          success: function(data) {
            $('#worker_id').append('<option value="">Select worker</option>');
            $.each(data, function(key, value) {
              $('#worker_id').append('<option value="' + value.id + '">' + value.fname + ' ' + value.lname + '</option>');
            });
          }
        });
      } else {
        $('#worker_id').append('<option value="">Select worker</option>');
      }
    });

    $('#kapans_id').change(function() {

      var kapan = $(this).val();
      $('#kapan_parts_id').empty();

      if (!kapan || kapan === 'all') {
        $('#kapan_parts_id').append('<option value="">Select kapan part</option>');
        $('#diamondTable tbody').html('');
        $('#addDiamondBtn').addClass('d-none');
        return;
      }

      $.ajax({
        type: 'POST',
        url: '/admin/get-kapan-parts',
        data: {
          _token: '<?php echo e(csrf_token()); ?>',
          kapans_id: kapan
        },
        success: function(data) {

          $('#kapan_parts_id').append('<option value="">Select kapan part</option>');

          $.each(data, function(index, value) {
            if (value) {
              $('#kapan_parts_id').append(
                '<option value="' + value.id + '">' +
                value.name +
                '</option>'
              );
            }
          });
        }
      });
    });
  });


  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.certificateBtn').forEach(button => {
      button.addEventListener('click', function() {
        document.getElementById('issue_id').value = this.dataset.id;
        document.getElementById('diamonds_id').value = this.dataset.diamonds_id;
      });
    });
  });

  $('#return_weight, #price').on('input', function() {
    let weight = parseFloat($('#return_weight').val()) || 0;
    let price = parseFloat($('#price').val()) || 0;

    console.log(weight)
    console.log(price)

    $('#total_price').val((weight * price).toFixed(2));
  });

  <?php /*
  document.addEventListener('input', function(e) {
    if (e.target.classList.contains('return-weight')) {

      let issueWeight = parseFloat(e.target.dataset.issueWeight);
      let returnWeight = parseFloat(e.target.value);

      if (returnWeight > issueWeight) {
        alert('Return weight cannot be greater than diamond weight');
        e.target.value = issueWeight;
      }
    }
  });
  */ ?>

  document.addEventListener('change', function(e) {
    if (e.target.classList.contains('return-date')) {

      let issueDate = new Date(e.target.dataset.issueDate);
      let returnDate = new Date(e.target.value);

      if (returnDate < issueDate) {
        alert('Return date cannot be earlier than Issue date');
        e.target.value = e.target.dataset.issueDate;
      }
    }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/issue/return.blade.php ENDPATH**/ ?>