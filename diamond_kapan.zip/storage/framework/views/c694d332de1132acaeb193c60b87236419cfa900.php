<?php

use Carbon\Carbon;
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PDF Print</title>
  <link href="<?php echo e(asset('assets/css/pdfCss.css')); ?>" rel="stylesheet" type="text/css" />
  <style>
    @media  print {
      .no-print {
        display: none;
      }
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="column">
        <div class="d-flex align-items-center justify-content-center">
          <h1 class="align-center title">DHYANI IMPEX</h1>
        </div>
        <br />
        <div class="d-flex justify-content-center">
          <strong class="align-center title">Slip</strong>&nbsp;
        </div>
        <br />
        <div class="d-flex justify-content-between">
          <div class="d-flex flex-col">
            <span>Bill Date:</span>
            <span><?php echo e(\Carbon\Carbon::parse(Carbon::now())->format('d-m-Y H:i:s')); ?></span>
          </div>
          <br />
        </div>
        <br />
        <table>
          <thead>
            <tr>
              <th width="50%">Party</th>
              <th width="50%">Dimond Detail</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <p>Party Name: <?php echo e($data->parties->party_code); ?></p>
                <p>Dimond Name: <?php echo e($data->dimond_name); ?></p>
                <p>Barcode:</p>
                <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
                <script>
                  window.onload = function() {
                    generateBarcode('<?php echo e($data->barcode_number); ?>');
                  };
                </script>
                <svg id="barcode"></svg>
              </td>
              <td>
                <p>Row Weight: <?php echo e($data->weight); ?></p>
                <p>Polished Weight: <?php echo e($data->required_weight); ?></p>
                <p>Shap: <?php echo e($data->shape); ?></p>
                <p>clarity: <?php echo e($data->clarity); ?></p>
                <p>color: <?php echo e($data->color); ?></p>
                <p>cut: <?php echo e($data->cut); ?></p>
                <p>polish: <?php echo e($data->polish); ?></p>
                <p>symmetry: <?php echo e($data->symmetry); ?></p>
              </td>
            </tr>
          </tbody>
        </table>
        <div>
          <div style="padding-top:50px;"></div>
          <p>Author Sigh</p>
        </div>
      </div>
      <button class="no-print" onclick="window.print()">Print</button>
      <a href="<?php echo e(route('print.slipe', ['id' => $data->id,'action' => 'download'])); ?>" class="no-print">Download PDF</a>
    </div>
  </div>
  <script>
    function generateBarcode(value) {
      JsBarcode("#barcode", value, {
        format: "CODE128",
        displayValue: true,
        height: 100,
        width: 4,
        fontOptions: "bold",
        fontSize: 40,
      });
    }
  </script>
</body>

</html><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/expense/your-print-view.blade.php ENDPATH**/ ?>