
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Designation</h4>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">
                    Generate Worker Barcode
                </h4>

                <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session()->get('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <?php echo Form::open([
                'method' => 'POST',
                'action' => 'AdminDesignationController@store',
                'files' => true,
                'class' => 'form-horizontal',
                'name' => 'designationform',
                ]); ?>

                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="mb-3">
                        <label for="category">Designation Category</label>
                        <select name="category" id="category" class="form-select" required>
                            <option value="">Select category</option>
                            <option value="Inner">Inner</option>
                            <option value="Outter">Outter</option>
                        </select>
                        <?php if($errors->has('category')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('category')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <div class="mb-3">
                        <label for="name">Designation Name</label>
                        <input type="text" name="name" class="form-control" id="name"
                            placeholder="Enter Designation" value="<?php echo e(old('name')); ?>"
                            onkeypress='return (event.charCode != 32)' required>
                        <?php if($errors->has('name')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div>
                    <button type="submit" class="btn btn-primary w-md">Submit</button>
                </div>

                </form>

            </div>
        </div>
    </div> <!-- end col -->

    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">Designation List</h4>

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <table id="datatable" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Category</th>
                            <th>Designation</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($designation->name != 'Certificate'): ?>
                                <a href="<?php echo e(route('admin.designation.edit', $designation->id)); ?>"
                                    class="btn btn-outline-primary waves-effect waves-light"><i
                                        class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.designation.destroy', $designation->id)); ?>"
                                    onclick="return confirm('Sure ! You want to delete ?');"
                                    class="btn btn-outline-danger waves-effect waves-light"><i
                                        class="fa fa-trash"></i></a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($designation->category); ?></td>
                            <td><?php echo e($designation->name); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->

</div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function() {
        $("form[name='designationform']").validate({
            rules: {
                name: {
                    required: true,
                },
                category: {
                    required: true,
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/designation/index.blade.php ENDPATH**/ ?>