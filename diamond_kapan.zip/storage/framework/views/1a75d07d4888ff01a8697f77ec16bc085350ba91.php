
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
         <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Invoices</h4>
            <div class="card-action">
               <div class="dropdown-menu-right">
                  <a class="dropdown-item" style="background-color:darkorchid;" href="<?php echo e(route('admin.invoice.create')); ?>"><i class="fa fa-plus editable" style="font-size:15px;">&nbsp;ADD</i></a>
               </div>
            </div>
         </div>
         <div class="table-responsive">
            <table id="partytable" class="table align-items-center table-flush table-borderless">
               <thead>
                  <tr>
                     <th>Action</th>
                     <th>Party Name</th>
                     <th>Company Name</th>
                     <th>Invoice No</th>
                     <th>Invoice Date</th>
                     <th>Place To Supply</th>
                     <th>Due Date</th>
                     <th>PDF</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <td>
                        <a href="<?php echo e(route('admin.invoice.edit', $invoice->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                        <a href="<?php echo e(route('admin.invoice.destroy', $invoice->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                     </td>
                     <td><?php echo e($invoice->parties_id); ?></td>
                     <td><?php echo e($invoice->companies_id); ?></td>
                     <td><?php echo e($invoice->invoice_no); ?></td>
                     <td><?php echo e($invoice->invoice_date); ?></td>
                     <td><?php echo e($invoice->place_to_supply); ?></td>
                     <td><?php echo e($invoice->due_date); ?></td>
                     <td>
                        <?php if($invoice->file != ''): ?>
                        <a href="<?php echo e(asset('invoices/'.$invoice->file)); ?>" target="_blank"><b>PDF</b></a>
                        <?php endif; ?>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/invoice/index.blade.php ENDPATH**/ ?>