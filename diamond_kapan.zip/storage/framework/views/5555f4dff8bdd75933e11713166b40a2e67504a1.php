<?php

use App\Models\Dimond;
?>

<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Summary</h4>

            <!-- <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Summary</li>
                    </ol>
                </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-block-helper me-2"></i>
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <form id="myForm" action="<?php echo e(route('admin.summary')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <div data-repeater-list="group-a">
                        <div data-repeater-item class="row">
                            <div class="mb-3 col-lg-3">
                                <label for="party_id">Party Name</label>
                                <select name="party_id" id="party_id" class="form-select" required>
                                    <option value="">Select party</option>
                                    <option value="All" <?php echo e(request()->party_id == 'All' ? 'selected' : ''); ?>>ALL
                                    </option>
                                    <?php $__currentLoopData = $partyLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($partyList->id); ?>"
                                        <?php echo e(request()->party_id == $partyList->id ? 'selected' : ''); ?>>
                                        <?php echo e($partyList->fname); ?>&nbsp;&nbsp;<?php echo e($partyList->lname); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('party_id')): ?>
                                <div class="error text-danger"><?php echo e($errors->first('party_id')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="col-lg-6 d-flex">
                                <div class="gap-2">
                                    <button type="button" id="button1" class="btn btn-success mt-2  w-md">Report</button>
                                    <button type="button" id="button2" class="btn btn-info mt-2  w-md">Export</button>
                                    <a class="btn btn-light mt-2 w-md" href="/admin/summary">Clear</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if (isset($_GET['party_id'])) { ?>
            <div class="card">
                <div class="card-body">
                    <?php if ($_GET['party_id'] != 'All') { ?>
                        <table id="summaryTable" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                            <thead>
                                <tr>
                                    <th>Action</th>
                                    <th>Dimond Name</th>
                                    <th>Barcode</th>
                                    <th>Created Date</th>
                                    <th>Updated Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $partyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $allDimonds = Dimond::where('parties_id', $partyList->id)->where('status', '!=', 'Delivered')->get();
                                ?>
                                <?php $__currentLoopData = $allDimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allDimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('admin.dimond.show', $allDimond->barcode_number)); ?>"
                                            class="btn btn-outline-info waves-effect waves-light"><i
                                                class="fa fa-eye"></i>
                                        </a>
                                    </td>
                                    <td><?php echo e($allDimond->dimond_name); ?></td>
                                    <td><?php echo e($allDimond->barcode_number); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($allDimond->created_at)->format('d-m-Y')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($allDimond->updated_at)->format('d-m-Y')); ?></td>
                                    <td><?php echo e($allDimond->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php } else { ?>
                        <table id="" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                            <thead>
                                <tr>
                                    <th>Party Name</th>
                                    <th>Pending</th>
                                    <th>Outter</th>
                                    <th>Processing</th>
                                    <th>Completed</th>
                                    <th>Delivered</th>
                                    <th>Total Dimond</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $partyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $totalDimond = Dimond::where('parties_id', $partyList->id)->count();
                                $outterDimond = Dimond::where(['parties_id' => $partyList->id, 'status' => 'OutterProcessing'])->count();
                                $pendingDimond = Dimond::where(['parties_id' => $partyList->id, 'status' => 'Pending'])->count();
                                $processingDimond = Dimond::where('parties_id', $partyList->id)->where('status', 'Processing')->count();
                                $completedDimond = Dimond::where(['parties_id' => $partyList->id, 'status' => 'Completed'])->count();
                                $deliveredDimond = Dimond::where(['parties_id' => $partyList->id, 'status' => 'Delivered'])->count();
                                ?>
                                <tr>
                                    <td><?php echo e($partyList->fname); ?>&nbsp;<?php echo e($partyList->lname); ?></td>
                                    <td><?php echo e($pendingDimond); ?></td>
                                    <td><?php echo e($outterDimond); ?></td>
                                    <td><?php echo e($processingDimond); ?></td>
                                    <td><?php echo e($completedDimond); ?></td>
                                    <td><?php echo e($deliveredDimond); ?></td>
                                    <td><?php echo e($totalDimond); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>

    </div>
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.getElementById('myForm');
        var button1 = document.getElementById('button1');
        var button2 = document.getElementById('button2');

        button1.addEventListener('click', function() {
            // Change the form action for button 1
            if ($("#party_id").val() == '') {
                alert("Please Select Party");
                return false;
            }

            form.action = "<?php echo e(route('admin.summary')); ?>";
            // Submit the form
            form.submit();
        });

        button2.addEventListener('click', function() {
            if ($("#party_id").val() == '') {
                alert("Please Select Party");
                return false;
            }

            // Change the form action for button 2
            form.action = "<?php echo e(route('admin.summary.export')); ?>";
            // Submit the form
            form.submit();
        });
    });

    $(document).ready(function() {
        $("#summaryTable").DataTable({
            dom: 'Blfrtip',
            buttons: [{
                    extend: 'pdf',
                },
                {
                    extend: 'csv',
                },
                {
                    extend: 'excel',
                }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/reports/summary.blade.php ENDPATH**/ ?>