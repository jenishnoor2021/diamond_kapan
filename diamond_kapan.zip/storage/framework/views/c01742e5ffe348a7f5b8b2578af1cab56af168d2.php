
<?php $__env->startSection('style'); ?>
<style>
   form {
      width: 300px;
      padding: 20px;
      border-radius: 5px;
   }

   input {
      width: 100%;
      padding: 2px;
      margin-bottom: 16px;
      box-sizing: border-box;
      background-color: transparent;
      color: white
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
         <?php if(session('error')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:red">
            <?php echo e(session('error')); ?>

         </div>
         <?php endif; ?>
         <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Direct Issues Return</h4>
            <form method="POST" action="<?php echo e(route('admin.daily-status.store')); ?>">
               <?php echo csrf_field(); ?>
               <input type="text" id="inputField2" name="inputField" placeholder="Search barcode" required>
            </form>
            <h5></h5>
         </div>
         <div class="row">
            <div class="col-6" style="text-align:start">
               <h5><span class="text-warning ml-3">Total Dimonds:</span> <?php echo e($dimondcount); ?></h5>
               <h5><span class="text-warning ml-3">Pending Dimonds:</span> <?php echo e($pendingcount); ?></h5>
               <h5><span class="text-warning ml-3">Processing Dimonds:</span> <?php echo e($issuecount); ?></h5>
               <h5><span class="text-warning ml-3"> Outer Dimond:</span> <?php echo e($outercount); ?></h5>
            </div>
            <div class="col-3" style="text-align:end;">
               <h5><span class="text-warning">Count:</span> <?php echo e($scancount); ?></h5>
            </div>
            <div class="col-3" style="text-align:end;">
               <a href="/admin/daily-status/refresh" class="btn btn-secondary"><i class="fa fa-refresh fa-2x" aria-hidden="true"></i></a>
            </div>
         </div>

         <div class="">
            <table id="dailytable" class="table align-items-center table-flush table-borderless">
               <thead>
                  <tr>
                     <th>Action</th>
                     <th>Dimond Name</th>
                     <th>Barcode</th>
                     <th>Date</th>
                     <!-- <th>Stage</th> -->
                     <th>Current Status</th>
                     <th>Status</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php $__currentLoopData = $dailys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <td>
                        <!-- <a href="<?php echo e(route('admin.daily-status.destroy', $dimond->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a> -->
                        <a href="<?php echo e(route('admin.dimond.show', $dimond->barcode)); ?>"><i class="fa fa-eye" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                     </td>
                     <td><?php echo e($dimond->dimonds->dimond_name); ?></td>
                     <td><?php echo e($dimond->barcode); ?></td>
                     <td><?php echo e(\Carbon\Carbon::parse($dimond->updated_at)->format('d-m-Y')); ?></td>
                     <td><?php echo e($dimond->dimonds->status); ?></td>
                     <!-- <td><b><span class="<?php echo e($dimond->stage == 'issue' ? 'text-success' : 'text-danger'); ?>"><?php echo e($dimond->stage); ?></span></b></td> -->
                     <td><a href="/admin/daily-status/statusupdate/<?php echo e($dimond->id); ?>" class="btn <?php echo e($dimond->status == 0 ? 'btn-danger' : 'btn-success'); ?>"><?php echo e($dimond->stage); ?></a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   document.addEventListener('DOMContentLoaded', function() {
      // Auto-focus on the input field when the page loads
      document.getElementById('inputField2').focus();
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/foobbshh/public_html/diamondhr/resources/views/admin/daily/index.blade.php ENDPATH**/ ?>