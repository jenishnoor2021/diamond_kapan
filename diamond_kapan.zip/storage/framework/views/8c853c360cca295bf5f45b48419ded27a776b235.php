
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
  <div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
      <h4 class="mb-sm-0 font-size-18">Export Delievery Slip</h4>

      <div class="page-title-right">
        <ol class="breadcrumb m-0">
          <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
          <li class="breadcrumb-item active">Export Delievery Slip</li>
        </ol>
      </div>

    </div>
  </div>
</div>
<!-- end page title -->

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('admin.hr.exportpdf')); ?>" method="GET" class="repeater">
          <?php echo csrf_field(); ?>
          <div data-repeater-list="group-a">
            <div data-repeater-item class="row">
              <div class="mb-3 col-lg-2">
                <label for="party_id">Party Name</label>
                <select class="form-select" name="party_id" id="validationCustom03" required="">
                  <option value="">Select party</option>
                  <?php $__currentLoopData = $partyLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($partyList->id); ?>" <?php echo e(request()->party_id == $partyList->id ? 'selected' : ''); ?>><?php echo e($partyList->fname); ?>&nbsp;&nbsp;<?php echo e($partyList->lname); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="mb-3 col-lg-2">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e(request()->start_date); ?>" placeholder="Enter date" />
              </div>

              <div class="mb-3 col-lg-2">
                <label for="end_date">End Date</label>
                <input type="date" name="end_date" id="end_date" class="form-control" placeholder="Enter date" />
              </div>

              <div class="col-lg-1 align-self-center">
                <div class="d-flex gap-2">
                  <input type="submit" class="btn btn-success mt-3 mt-lg-0" value="Export" />
                  <a class="btn btn-light mt-3 mt-lg-0" href="<?php echo e(URL::to('/admin/hrdimond')); ?>">Back</a>
                </div>
              </div>
            </div>

          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/reports/hr_report.blade.php ENDPATH**/ ?>