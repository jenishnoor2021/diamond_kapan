
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
   <div class="col-lg-8 mx-auto">
      <div class="card">
         <div class="card-body">
            <?php if(session()->has('message')): ?>
            <div class="alert text-white" style="background-color:green">
               <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card-title">Edit Worker Barcode</div>
            <hr>
            <?php echo Form::model($workerBarcode, ['method'=>'PATCH', 'action'=> ['AdminWorkerBarcodeController@update', $workerBarcode->id],'files'=>true,'class'=>'form-horizontal','name'=>'editbarcodeform']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-6">
                  <div class="form-group">
                     <label for="worker_id">Worker name</label>
                     <input type="text" name="worker_id" class="form-control form-control-rounded" id="worker_id" value="<?php echo e($workerBarcode->worker_id); ?>" readonly>
                  </div>
               </div>
               <div class="col-6">
                  <div class="form-group">
                     <label for="name">Barcode</label>
                     <input type="text" name="barcode" class="form-control form-control-rounded" id="barcode" value="<?php echo e($workerBarcode->barcode); ?>" required pattern="\d{10}" maxlength="10" minlength="10" title="Barcode must be exactly 10 digits">
                     <?php if($errors->has('barcode')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('barcode')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="form-group">
               <button type="submit" class="btn btn-light btn-round px-5">Update</button>
            </div>
            </form>
         </div>
      </div>
   </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editbarcodeform']").validate({
         rules: {
            worker_id: {
               required: true,
            },
            barcode: {
               required: true,
            }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });

   document.getElementById('barcode').addEventListener('input', function(e) {
      const value = e.target.value;
      if (value.length > 10) {
         e.target.value = value.slice(0, 10); // Limit to 10 digits
      }
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\dimond\resources\views/admin/worker_barcode/edit.blade.php ENDPATH**/ ?>