
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">Add Worker Attendance</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Add Worker Attendance</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">

                    <?php echo Form::open([
                        'method' => 'POST',
                        'action' => 'AdminWorkerAttendanceController@store',
                        'files' => true,
                        'class' => 'form-horizontal',
                        'name' => 'addworkerattendanceform',
                    ]); ?>

                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-md-2">
                            <div class="mb-3">
                                <label for="worker_id">Worker</label>
                                <select name="worker_id" id="worker_id" class="form-select" required>
                                    <option value="">Select worker</option>
                                    <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->fname); ?>&nbsp;<?php echo e($worker->lname); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('worker_id')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('worker_id')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="mb-3">
                                <label for="date">Date</label>
                                <input type="date" name="date" class="form-control"
                                    id="date" placeholder="Enter number" value="" required>
                                <?php if($errors->has('date')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('date')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="mb-3">
                                <label for="check_in">Check In time</label>
                                <input type="datetime-local" name="check_in" class="form-control"
                                    id="check_in" value="">
                                <?php if($errors->has('check_in')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('check_in')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="mb-3">
                                <label for="check_out">Check Out time</label>
                                <input type="datetime-local" name="check_out" class="form-control"
                                    id="check_out" value="">
                                <?php if($errors->has('check_out')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('check_out')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="mb-3">
                                <label for="duration">Duration </label>
                                <input type="text" name="duration" class="form-control"
                                    id="duration" placeholder="Enter duration" value="" readonly>
                                <?php if($errors->has('duration')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('duration')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-md">Submit</button>
                        <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/attendance')); ?>">Back</a>
                    </div>
                    </form>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            $("form[name='addworkerattendanceform']").validate({
                rules: {
                    worker_id: {
                        required: true,
                    }
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });

        document.addEventListener('DOMContentLoaded', function() {
            const checkInInput = document.getElementById('check_in');
            const checkOutInput = document.getElementById('check_out');
            const durationInput = document.getElementById('duration');

            function calculateDuration() {
                const checkInTime = new Date(checkInInput.value);
                const checkOutTime = new Date(checkOutInput.value);

                if (checkInTime > checkOutTime) {
                    alert("Check-in time cannot be later than check-out time");
                    // checkOutInput.value = '';
                    // durationInput.value = '';
                    return;
                }

                if (checkInInput.value && checkOutInput.value) {
                    const duration = Math.abs(checkOutTime - checkInTime) / 1000;
                    const hours = Math.floor(duration / 3600);
                    const minutes = Math.floor((duration % 3600) / 60);
                    const seconds = Math.floor(duration % 60);
                    const formattedDuration =
                        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                    durationInput.value = formattedDuration;
                } else {
                    durationInput.value = '';
                }
            }

            checkInInput.addEventListener('input', calculateDuration);
            checkOutInput.addEventListener('input', calculateDuration);

            // Initial calculation
            calculateDuration();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/worker_attendance/create.blade.php ENDPATH**/ ?>