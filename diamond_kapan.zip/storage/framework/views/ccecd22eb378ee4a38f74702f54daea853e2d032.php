
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
         <h4 class="mb-sm-0 font-size-18">Edit Party</h4>

         <!-- <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
               <li class="breadcrumb-item active">Edit Party</li>
            </ol>
         </div> -->

      </div>
   </div>
</div>
<!-- end page title -->

<div class="row">
   <div class="col-xl-12">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title mb-4">Edit</h4>

            <?php echo Form::model($party, ['method'=>'PATCH', 'action'=> ['AdminPartyController@update', $party->id],'files'=>true,'class'=>'form-horizontal', 'name'=>'editpartyform']); ?>

            <?php echo csrf_field(); ?>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="fname" class="form-label">First Name</label>
                     <input type="text" name="fname" class="form-control" id="fname" placeholder="Enter First name" onkeypress='return (event.charCode != 32)' value="<?php echo e($party->fname); ?>" required>
                     <?php if($errors->has('fname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('fname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="lname" class="form-label">Last Name</label>
                     <input type="text" name="lname" class="form-control" id="lname" placeholder="Enter Last Name" onkeypress='return (event.charCode != 32)' value="<?php echo e($party->lname); ?>" required>
                     <?php if($errors->has('lname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('lname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="party_code">Party Code</label>
                     <input type="text" name="party_code" class="form-control" id="party_code" placeholder="Enter party code" onkeypress='return (event.charCode != 32)' value="<?php echo e($party->party_code); ?>" required>
                     <?php if($errors->has('party_code')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('party_code')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="mb-3">
               <label for="address">Address</label>
               <textarea type="text" name="address" class="form-control" id="address" placeholder="Enter Address"><?php echo e($party->address); ?></textarea>
               <?php if($errors->has('address')): ?>
               <div class="error text-danger"><?php echo e($errors->first('address')); ?></div>
               <?php endif; ?>
            </div>

            <div class="row">
               <div class="col-lg-4">
                  <div class="mb-3">
                     <label for="mobile">Mobile no</label>
                     <input type="number" name="mobile" class="form-control" id="mobile" placeholder="Enter number" value="<?php echo e($party->mobile); ?>">
                     <?php if($errors->has('mobile')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('mobile')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="mb-3">
                     <label for="gst_no">GST No</label>
                     <input type="text" name="gst_no" class="form-control" id="gst_no" placeholder="Enter GST No" value="<?php echo e($party->gst_no); ?>">
                     <?php if($errors->has('mobile')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('mobile')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <h4 class="card-title mb-4 mt-2">Party Rate (Round)</h4>

            <div class="row">
               <?php $__currentLoopData = $roundpartyrangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roundpartyrang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="<?php echo e($roundpartyrang->key); ?>" class="form-label">Rate (<?php echo e($roundpartyrang->min_value); ?> to <?php echo e($roundpartyrang->max_value); ?>)</label>
                     <input type="number" name="<?php echo e($roundpartyrang->key); ?>" class="form-control" id="<?php echo e($roundpartyrang->key); ?>" placeholder="Enter amount" value="<?php echo e($partyrateValues[$roundpartyrang->key] ?? ''); ?>">
                     <?php if($errors->has('$roundpartyrang->key')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('$roundpartyrang->key')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <h4 class="card-title mb-4 mt-2">Party Rate (Fancy)</h4>

            <div class="row">
               <?php $__currentLoopData = $otherpartyrangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherpartyrang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="<?php echo e($otherpartyrang->key); ?>" class="form-label">Rate (<?php echo e($otherpartyrang->min_value); ?> to <?php echo e($otherpartyrang->max_value); ?>)</label>
                     <input type="number" name="<?php echo e($otherpartyrang->key); ?>" class="form-control" id="<?php echo e($otherpartyrang->key); ?>" placeholder="Enter amount" value="<?php echo e($partyrateValues[$otherpartyrang->key] ?? ''); ?>">
                     <?php if($errors->has('$otherpartyrang->key')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('$otherpartyrang->key')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="d-flex gap-2">
               <button type="submit" class="btn btn-primary w-md">Update</button>
               <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/party')); ?>">Back</a>
            </div>
            </form>
         </div>
         <!-- end card body -->
      </div>
      <!-- end card -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editpartyform']").validate({
         rules: {
            fname: {
               required: true,
            },
            lname: {
               required: true,
            },
            // address: {
            //    required: true,
            // },
            // mobile: {
            //    required: true,
            // },
            party_code: {
               required: true,
            }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/party/edit.blade.php ENDPATH**/ ?>