
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
  <div class="col-lg-4">
    <div class="card">
      <div class="card-body">
        <?php if(session()->has('message')): ?>
        <div class="alert text-white" style="background-color:green">
          <?php echo e(session()->get('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card-title">
          <h4>ADD Designation</h4>
        </div>
        <hr>
        <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminDesignationController@store','files'=>true,'class'=>'form-horizontal','name'=>'designationform']); ?>

        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="category">Designation Category</label>
          <select name="category" id="category" class="custom-select form-control form-control-rounded" style="width:100%" required>
            <option value="">Select category</option>
            <option value="Inner">Inner</option>
            <option value="Outter">Outter</option>
          </select>
          <?php if($errors->has('category')): ?>
          <div class="error text-danger"><?php echo e($errors->first('category')); ?></div>
          <?php endif; ?>
        </div>
        <div class="form-group">
          <label for="name">Designation Name</label>
          <input type="text" name="name" class="form-control form-control-rounded" id="name" placeholder="Enter Designation" value="<?php echo e(old('name')); ?>" onkeypress='return (event.charCode != 32)' required>
          <?php if($errors->has('name')): ?>
          <div class="error text-danger"><?php echo e($errors->first('name')); ?></div>
          <?php endif; ?>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-light btn-round px-5"><i class="fa fa-plus"></i> ADD</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card">
      <?php if(session('success')): ?>
      <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
        <?php echo e(session('success')); ?>

      </div>
      <?php endif; ?>
      <div class="card-header d-flex justify-content-between align-items-center">
        <h4>Designation List</h4>
      </div>
      <div class="table-responsive">
        <table class="table align-items-center table-flush table-borderless">
          <thead>
            <tr>
              <th>Action</th>
              <th>Category</th>
              <th>Designation</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td>
                <?php if($designation->name != 'Grading'): ?>
                <a href="<?php echo e(route('admin.designation.edit', $designation->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:#0275d8;padding:8px;border-radius:500px;"></i></a>
                <a href="<?php echo e(route('admin.designation.destroy', $designation->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:red;padding:8px;border-radius:500px;"></i></a>
                <?php endif; ?>
              </td>
              <td><?php echo e($designation->category); ?></td>
              <td><?php echo e($designation->name); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(function() {
    $("form[name='designationform']").validate({
      rules: {
        name: {
          required: true,
        },
        category: {
          required: true,
        }
      },
      submitHandler: function(form) {
        form.submit();
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/designation/index.blade.php ENDPATH**/ ?>