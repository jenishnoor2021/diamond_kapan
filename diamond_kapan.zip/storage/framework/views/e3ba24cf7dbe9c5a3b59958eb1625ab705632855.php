
<?php $__env->startSection('content'); ?>
<style>
    .table>:not(caption)>*>* {
        padding: .25rem .75rem;
    }
</style>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Kapan Parts List</h4>
        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div id="right">
                    <div id="menu" class="mb-3">

                        <?php echo Form::open(['method'=>'get', 'action'=> 'AdminKapanPartsController@getKapanParts','class'=>'form-horizontal','name'=>'getKapanParts']); ?>

                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="kapans_id" class="form-label">kapans</label>
                                    <select name="kapans_id" id="kapans_id" class="form-select" onchange="this.form.submit();" required>
                                        <option value="">Select Kapan</option>
                                        <?php $__currentLoopData = $kapans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($kapan->id); ?>"
                                            <?php echo e(isset($selectedKapan) && $selectedKapan && $kapan->id == $selectedKapan->id ? 'selected' : ''); ?>>
                                            <?php echo e($kapan->kapan_name); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('kapans_id')): ?>
                                    <div class="error text-danger"><?php echo e($errors->first('kapans_id')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="d-flex gap-2 mb-3">
                                    <!-- <button type="submit" class="btn btn-primary w-md">Submit</button> -->
                                    <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/kapan_part')); ?>">Clear</a>
                                </div>
                            </div>
                        </div>

                        </form>

                    </div>
                </div>

                <?php if(count($kapan_parts) > 0): ?>

                <?php
                $totalInserted = $kapan_parts->sum('weight');
                $remaining = $selectedKapan->kapan_weight - $totalInserted;
                ?>

                <span class="text-danger" style="font-size:15px;">
                    "<?php echo e($selectedKapan->kapan_name); ?>" kapan total weight is
                    <strong id="kapanWeight"><?php echo e($selectedKapan->kapan_weight); ?></strong>

                    | Inserted Weight:
                    <strong id="insertedWeight"><?php echo e($totalInserted); ?></strong>

                    | Remaining:
                    <strong id="remainingWeight"
                        class="<?php echo e($remaining < 0 ? 'text-danger' : 'text-success'); ?>">
                        <?php echo e($remaining); ?>

                    </strong>
                </span>

                <?php
                $chunks = $kapan_parts->chunk( ceil($kapan_parts->count() / 2) );
                ?>

                <div class="row mt-3">

                    <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <table class="table">
                            <thead>
                                <tr align="center">
                                    <th class="text-primary" style="font-weight:700">No</th>
                                    <th>Name</th>
                                    <th>Weight</th>
                                    <th width="20%"></th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-primary" style="font-weight:700"><?php echo e($part->part_no); ?></td>

                                    <td>
                                        <input type="text"
                                            value="<?php echo e($part->name); ?>"
                                            class="form-control"
                                            readonly>
                                    </td>

                                    <td>
                                        <input type="number"
                                            name="parts[<?php echo e($part->id); ?>]"
                                            value="<?php echo e($part->weight); ?>"
                                            step="0.01"
                                            class="form-control kapan-weight-input"
                                            data-id="<?php echo e($part->id); ?>">
                                    </td>
                                    <td></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <?php endif; ?>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).on('change', '.toggle-status-switch', function() {
        const toggleSwitch = $(this);
        const agentId = toggleSwitch.data('id');
        const isChecked = toggleSwitch.is(':checked');

        $.ajax({
            url: "<?php echo e(route('admin.kapan.active')); ?>",
            type: "POST",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                id: agentId
            },
            success: function(response) {
                if (response.success) {
                    toggleSwitch.next('label').text(response.status);
                    alert('Status updated successfully');
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                // Revert toggle state in case of an error
                toggleSwitch.prop('checked', !isChecked);
            }
        });
    });

    $(document).on('focus', '.kapan-weight-input', function() {
        $(this).data('old', $(this).val());
    });


    $(document).on('change', '.kapan-weight-input', function() {
        let input = $(this);
        let partId = input.data('id');
        let weight = parseFloat(input.val()) || 0;

        $.ajax({
            url: "<?php echo e(route('admin.kapan.parts.update.single')); ?>",
            type: "POST",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                part_id: partId,
                weight: weight
            },
            success: function(res) {
                if (res.success) {

                    $('#insertedWeight').text(res.total_weight);

                    // Remaining = kapanWeight - inserted
                    let kapanWeight = parseFloat($('#kapanWeight').text());
                    let remaining = kapanWeight - res.total_weight;

                    $('#remainingWeight')
                        .text(remaining)
                        .removeClass('text-danger text-success')
                        .addClass(remaining < 0 ? 'text-danger' : 'text-success');

                    showAlert(res.message, 'success');
                } else {
                    showAlert(res.message, 'danger');
                    input.val(input.data('old'));
                }
            },
            error: function() {
                showAlert('Something went wrong!', 'danger');
                input.val(input.data('old'));
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/kapan_parts/index.blade.php ENDPATH**/ ?>