
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
         <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Party List</h4>
            <div class="card-action">
               <div class="dropdown-menu-right">
                  <a class="dropdown-item" style="background-color:darkorchid;" href="<?php echo e(route('admin.party.create')); ?>"><i class="fa fa-plus editable" style="font-size:15px;">&nbsp;ADD</i></a>
               </div>
            </div>
         </div>
         <div class="table-responsive">
            <table id="partytable" class="table align-items-center table-flush table-borderless">
               <thead>
                  <tr>
                     <th>Action</th>
                     <th>Party id</th>
                     <th>First name</th>
                     <th>Last Name</th>
                     <th>Party code</th>
                     <th>Address</th>
                     <th>Mobile no</th>
                     <th>GST no</th>
                     <th>Active/De-active</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php $__currentLoopData = $partys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <td>
                        <a href="<?php echo e(route('admin.party.edit', $party->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                        <a href="<?php echo e(route('admin.party.destroy', $party->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                     </td>
                     <td><?php echo e($party->id); ?></td>
                     <td><?php echo e($party->fname); ?></td>
                     <td><?php echo e($party->lname); ?></td>
                     <td><?php echo e($party->party_code); ?></td>
                     <td><?php if(strlen($party->address) > 40): ?>
                        <?php echo substr($party->address,0,40); ?>

                        <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                        <span class="read-more-content"> <?php echo e(substr($party->address,40,strlen($party->address))); ?>

                           <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span> </span>
                        <?php else: ?>
                        <?php echo e($party->address); ?>

                        <?php endif; ?>
                     </td>
                     <td><?php echo e($party->mobile); ?></td>
                     <td><?php echo e($party->gst_no); ?></td>
                     <td>
                        <?php if($party->is_active == 1): ?>
                        <a href="/admin/party/active/<?php echo e($party->id); ?>" class="btn btn-success">Active</a>
                        <?php else: ?>
                        <a href="/admin/party/active/<?php echo e($party->id); ?>" class="btn btn-danger">De-active</a>
                        <?php endif; ?>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/foobbshh/public_html/diamondhr/resources/views/admin/party/index.blade.php ENDPATH**/ ?>