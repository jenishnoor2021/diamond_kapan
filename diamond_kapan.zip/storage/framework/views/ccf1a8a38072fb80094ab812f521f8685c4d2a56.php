
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
   <div class="col-lg-8 mx-auto">
      <div class="card">
         <div class="card-body">
            <div class="card-title">Edit Worker</div>
            <hr>
            <?php echo Form::model($worker, ['method'=>'PATCH', 'action'=> ['AdminWorkerController@update', $worker->id],'files'=>true,'class'=>'form-horizontal','name'=>'editworkerform']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-6">
                  <div class="form-group">
                     <label for="fname">First Name</label>
                     <input type="text" name="fname" class="form-control form-control-rounded" id="fname" placeholder="Enter First name" onkeypress='return (event.charCode != 32)' value="<?php echo e($worker->fname); ?>" required>
                     <?php if($errors->has('fname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('fname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-6">
                  <div class="form-group">
                     <label for="lname">Last Name</label>
                     <input type="text" name="lname" class="form-control form-control-rounded" id="lname" placeholder="Enter Last Name" onkeypress='return (event.charCode != 32)' value="<?php echo e($worker->lname); ?>" required>
                     <?php if($errors->has('lname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('lname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <div class="form-group">
               <label for="designation">Designation</label>
               <select name="designation" id="designation" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select designation</option>
                  <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($designation->name); ?>" <?php echo e($worker->designation == $designation->name ? "selected" : ''); ?>><?php echo e($designation->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
               <?php if($errors->has('designation')): ?>
               <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
               <?php endif; ?>
            </div>
            <div class="form-group">
               <label for="address">Address</label>
               <textarea type="text" name="address" class="form-control form-control-rounded" id="address" placeholder="Enter Address" required><?php echo e($worker->address); ?></textarea>
               <?php if($errors->has('address')): ?>
               <div class="error text-danger"><?php echo e($errors->first('address')); ?></div>
               <?php endif; ?>
            </div>
            <div class="row">
               <div class="col-6">
                  <div class="form-group">
                     <label for="mobile">Mobile no</label>
                     <input type="number" name="mobile" class="form-control form-control-rounded" id="mobile" placeholder="Enter number" value="<?php echo e($worker->mobile); ?>" required>
                     <?php if($errors->has('mobile')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('mobile')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-6">
                  <div class="form-group">
                     <label for="aadhar_no">Aadhar Number</label>
                     <input type="text" name="aadhar_no" class="form-control form-control-rounded" id="aadhar_no" placeholder="Enter aadhar no" oninput="formatAadharInput(this)" value="<?php echo e($worker->aadhar_no); ?>" required>
                     <?php if($errors->has('aadhar_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('aadhar_no')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <input type="checkbox" id="myCheckbox"> Show Bank detail
            <!-- Your div tag -->
            <div id="myDiv" style="display: none;">
               <div class="row">
                  <div class="col-6">
                     <div class="form-group">
                        <label for="bank_name">Bank name</label>
                        <input type="text" name="bank_name" class="form-control form-control-rounded" id="bank_name" placeholder="Enter bank name" value="<?php echo e($worker->bank_name); ?>">
                     </div>
                  </div>
                  <div class="col-6">
                     <div class="form-group">
                        <label for="ifsc_code">IFSC code</label>
                        <input type="text" name="ifsc_code" class="form-control form-control-rounded" id="ifsc_code" placeholder="Enter IFSC code" value="<?php echo e($worker->ifsc_code); ?>">
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-6">
                     <div class="form-group">
                        <label for="account_holder_name">Account Holder name</label>
                        <input type="text" name="account_holder_name" class="form-control form-control-rounded" id="account_holder_name" placeholder="Enter Account Holder name" value="<?php echo e($worker->account_holder_name); ?>">
                     </div>
                  </div>
                  <div class="col-6">
                     <div class="form-group">
                        <label for="account_no">Account Number</label>
                        <input type="number" name="account_no" class="form-control form-control-rounded" id="account_no" placeholder="Enter Account number" value="<?php echo e($worker->account_no); ?>">
                     </div>
                  </div>
               </div>
            </div>
            <div class="form-group">
               <button type="submit" class="btn btn-light btn-round px-5">Update</button>
            </div>
            </form>
         </div>
      </div>
   </div>
</div><!--End Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editworkerform']").validate({
         rules: {
            fname: {
               required: true,
            },
            lname: {
               required: true,
            },
            address: {
               required: true,
            },
            mobile: {
               required: true,
            },
            designation: {
               required: true,
            },
            aadhar_no: {
               required: true,
            }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<script>
   document.addEventListener('DOMContentLoaded', function() {
      var checkbox = document.getElementById('myCheckbox');
      var div = document.getElementById('myDiv');

      checkbox.addEventListener('change', function() {
         // If the checkbox is checked, show the div; otherwise, hide it
         div.style.display = checkbox.checked ? 'block' : 'none';
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\dimond\resources\views/admin/worker/edit.blade.php ENDPATH**/ ?>