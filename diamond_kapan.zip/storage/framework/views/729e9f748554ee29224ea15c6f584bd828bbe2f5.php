
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
         <h4 class="mb-sm-0 font-size-18">ADD income</h4>
      </div>
   </div>
</div>
<!-- end page title -->

<div class="row">
   <div class="col-xl-12">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title mb-4">ADD</h4>

            <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminIncomeController@store','files'=>true,'class'=>'form-horizontal','name'=>'addincomeform']); ?>

            <?php echo csrf_field(); ?>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="khatas_id" class="form-label">Khata</label>
                     <select name="khatas_id" class="form-control" required>
                        <?php $__currentLoopData = $khatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($khata->id); ?>"><?php echo e($khata->fname); ?> - <?php echo e($khata->lname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="amount" class="form-label">Amount</label>
                     <input type="number" name="amount" class="form-control" id="amount" placeholder="Enter amount" value="<?php echo e(old('amount')); ?>" required>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="income_date" class="form-label">Date</label>
                     <input type="date" name="income_date" class="form-control" id="income_date" placeholder="Enter date" value="<?php echo e(now()->toDateString()); ?>" required>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="income_type" class="form-label">Income Type</label>
                     <select name="income_type" class="form-control" required>
                        <option value="cash">Cash</option>
                        <option value="online">Online</option>
                        <option value="cheque">Cheque</option>
                     </select>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="note" class="form-label">Note</label>
                     <textarea type="text" name="note" class="form-control" id="note" placeholder="Enter note"><?php echo e(old('note')); ?></textarea>
                  </div>
               </div>
            </div>

            <div class="d-flex gap-2">
               <button type="submit" class="btn btn-primary w-md">Submit</button>
               <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/income')); ?>">Back</a>
            </div>
            </form>
         </div>
         <!-- end card body -->
      </div>
      <!-- end card -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='addpolishform']").validate({
         rules: {
            name: {
               required: true,
            },
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/income/create.blade.php ENDPATH**/ ?>