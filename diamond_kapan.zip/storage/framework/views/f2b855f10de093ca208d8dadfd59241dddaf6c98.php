
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Edit Designation</h4>

            <!-- <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Edit Designation</li>
                    </ol>
                </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">

                <?php echo Form::model($designation, [
                'method' => 'PATCH',
                'action' => ['AdminDesignationController@update', $designation->id],
                'files' => true,
                'class' => 'form-horizontal',
                'name' => 'editdesignationform',
                ]); ?>

                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="category">Designation Category</label>
                            <select name="category" id="category" class="form-select" required>
                                <option value="">Select category</option>
                                <option value="Inner" <?php echo e($designation->category == 'Inner' ? 'selected' : ''); ?>>Inner
                                </option>
                                <option value="Outter" <?php echo e($designation->category == 'Outter' ? 'selected' : ''); ?>>Outter
                                </option>
                            </select>
                            <?php if($errors->has('category')): ?>
                            <div class="error text-danger"><?php echo e($errors->first('category')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="name">Designation Name</label>
                            <input type="text" name="name" class="form-control" id="name"
                                placeholder="Enter First name" onkeypress='return (event.charCode != 32)'
                                value="<?php echo e($designation->name); ?>">
                            <?php if($errors->has(' name')): ?>
                            <div class="error text-danger"><?php echo e($errors->first('name')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="rate_apply_on">Rate Calculate On</label>
                            <select name="rate_apply_on" id="rate_apply_on" class="form-select" style="width:100%"
                                required>
                                <option value="">Select weight</option>
                                <option value="issue_weight"
                                    <?php echo e($designation->rate_apply_on == 'issue_weight' ? 'selected' : ''); ?>>Issue weight
                                </option>
                                <option value="return_weight"
                                    <?php echo e($designation->rate_apply_on == 'return_weight' ? 'selected' : ''); ?>>Return weight
                                </option>
                                <option value="diff_weight"
                                    <?php echo e($designation->rate_apply_on == 'diff_weight' ? 'selected' : ''); ?>>Diffrence
                                    weight</option>
                                <option value="ready_to_ruff_weight" <?php echo e($designation->rate_apply_on == 'ready_to_ruff_weight' ? 'selected' : ''); ?>>Ready To Ruff</option>
                            </select>
                            <?php if($errors->has('rate_apply_on')): ?>
                            <div class="error text-danger"><?php echo e($errors->first('rate_apply_on')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary w-md">update</button>
                    <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/designation')); ?>">Back</a>
                </div>
                </form>
            </div>
            <!-- end card body -->
        </div>
        <!-- end card -->
    </div>
    <!-- end col -->
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function() {
        $("form[name='editdesignationform']").validate({
            rules: {
                name: {
                    required: true,
                },
                category: {
                    required: true,
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/designation/edit.blade.php ENDPATH**/ ?>