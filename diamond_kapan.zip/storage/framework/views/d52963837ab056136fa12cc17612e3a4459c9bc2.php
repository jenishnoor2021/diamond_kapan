<?php

use Carbon\Carbon;
use App\Models\Dimond;
use App\Models\Process;
?>

<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Worker Summary</h4>

            <!-- <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Worker Summary</li>
                    </ol>
                </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-block-helper me-2"></i>
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <form id="myForm" action="<?php echo e(route('admin.workersummary')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <div data-repeater-list="group-a">
                        <div data-repeater-item class="row">
                            <div class="mb-3 col-lg-2">
                                <label for="category">Category</label>
                                <select name="category" id="category" class="form-select" required>
                                    <option value="">Select category</option>
                                    <option value="all" <?php echo e(request()->category == 'all' ? 'selected' : ''); ?>>ALL
                                    </option>
                                    <option value="Inner" <?php echo e(request()->category == 'Inner' ? 'selected' : ''); ?>>Inner
                                        Worker</option>
                                    <option value="Outter" <?php echo e(request()->category == 'Outter' ? 'selected' : ''); ?>>
                                        Outter Worker</option>
                                </select>
                                <?php if($errors->has('category')): ?>
                                <div class="error text-danger"><?php echo e($errors->first('category')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3 col-lg-2">
                                <label for="designation">Designation</label>
                                <select name="designation" id="designation" class="form-select" required>
                                    <option value="">Select designation</option>
                                    <option value="all" <?php echo e(request()->designation == 'all' ? 'selected' : ''); ?>>ALL
                                    </option>
                                    <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($designation->name); ?>"
                                        <?php echo e(request()->designation == $designation->name ? 'selected' : ''); ?>>
                                        <?php echo e($designation->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('designation')): ?>
                                <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3 col-lg-2">
                                <label for="worker_name">Worker Name</label>
                                <select name="worker_name" id="worker_name" class="form-select" required>
                                    <option value="">Select worker</option>
                                    <option value="all" <?php echo e(request()->worker_name == 'all' ? 'selected' : ''); ?>>ALL
                                    </option>
                                    <?php $__currentLoopData = $workerLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($workerList->fname); ?>"
                                        <?php echo e(request()->worker_name == $workerList->fname ? 'selected' : ''); ?>>
                                        <?php echo e($workerList->fname); ?>&nbsp;&nbsp;<?php echo e($workerList->lname); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('worker_name')): ?>
                                <div class="error text-danger"><?php echo e($errors->first('worker_name')); ?></div>
                                <?php endif; ?>
                            </div>

                            
                    </div>

                    <div class="d-flex align-self-center">
                        <div class="gap-2">
                            <button type="button" id="button1" class="btn btn-success mt-2 w-md">Report</button>
                            <button type="button" id="button2" class="btn btn-info mt-2 w-md">Export Report</button>
                            <a class="btn btn-light mt-2 w-md" href="/admin/worker_summary">Clear</a>
                        </div>
                    </div>

            </div>
            </form>
        </div>
    </div>

    <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-body">
            <center>
                <h4 style="margin-top:10px"><?php echo e($worker->fname); ?>&nbsp;<?php echo e($worker->lname); ?></h4>
            </center>
            <?php
            $workerprocess = Process::where('worker_name', $worker->fname)->where('return_weight', null)->get();
            ?>

            <?php if(count($workerprocess)>0): ?>
            <table id="" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                <thead>
                    <tr>
                        <th>Show</th>
                        <th>Party Name</th>
                        <th>Diamond Name</th>
                        <th>Issue Date</th>
                        <th>Diamond Barcode</th>
                        <th>Created Date</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $workerprocess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerpro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $dimond = Dimond::where('barcode_number', $workerpro->dimonds_barcode)->first();
                    ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.dimond.show', $workerpro->dimonds_barcode)); ?>"
                                class="btn btn-outline-info"><i class="fa fa-eye"></i></a>
                        </td>
                        <td><?php echo e($dimond->parties->fname); ?></td>
                        <td><?php echo e($dimond->dimond_name); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($workerpro->issue_date)->format('d-m-Y')); ?></td>
                        <td><?php echo e($workerpro->dimonds_barcode); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($dimond->created_at)->format('d-m-Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
            <?php elseif(request()->category != ''): ?>
            <center><span class="text-danger">No record found</span></center>
            <?php endif; ?>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#designation').change(function() {
            var designation = $(this).val();
            if (designation == 'all') {
                $('#worker_name').append('<option value="all" selected>ALL</option>');
            } else if (designation && designation != 'all') {
                $.ajax({
                    type: 'POST',
                    url: '/admin/get-workers',
                    data: {
                        '_token': '<?php echo e(csrf_token()); ?>',
                        'designation': designation,
                    },
                    success: function(data) {
                        $('#worker_name').empty();
                        $('#worker_name').append(
                            '<option value="">Select worker</option><option value="all">ALL</option>'
                        );
                        $.each(data, function(key, value) {
                            $('#worker_name').append('<option value="' + value
                                .fname + '">' + value.fname + ' ' + value
                                .lname + '</option>');
                        });
                    }
                });
            } else {
                $('#worker_name').empty();
            }
        });
        $('#category').change(function() {
            var category = $(this).val();
            if (category) {
                $.ajax({
                    type: 'POST',
                    url: '/admin/get-designation',
                    data: {
                        '_token': '<?php echo e(csrf_token()); ?>',
                        'category': category,
                    },
                    success: function(data) {
                        $('#designation').empty();
                        $('#designation').append(
                            '<option value="">Select designation</option><option value="all">ALL</option>'
                        );
                        $.each(data, function(key, value) {
                            $('#designation').append('<option value="' + value
                                .name + '">' + value.name + '</option>');
                        });
                    }
                });
            } else {
                $('#designation').empty();
            }
        });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.getElementById('myForm');
        var button1 = document.getElementById('button1');
        var button2 = document.getElementById('button2');

        button1.addEventListener('click', function() {
            // Change the form action for button 1
            if ($("#worker_name").val() == '') {
                alert("Please Select Worker");
                return false;
            }


            form.action = "<?php echo e(route('admin.workersummary')); ?>";
            // Submit the form
            form.submit();
        });

        button2.addEventListener('click', function() {
            if ($("#worker_name").val() == '') {
                alert("Please Select Worker");
                return false;
            }
            // Change the form action for button 2
            form.action = "<?php echo e(route('admin.workersummary.export')); ?>";
            // Submit the form
            form.submit();
        });
    });

    $(document).ready(function() {
        $("#workersummaryTable").DataTable({
            dom: 'Blfrtip',
            buttons: [{
                    extend: 'pdf',
                },
                {
                    extend: 'csv',
                },
                {
                    extend: 'excel',
                }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/reports/workersummary.blade.php ENDPATH**/ ?>