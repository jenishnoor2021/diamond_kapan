<?php

use Carbon\Carbon;
use App\Models\Dimond;
use App\Models\Process;
?>


<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<style>
  .dt-button.buttons-html5 {
    background-color: aliceblue;
  }
</style>
<?php $__env->stopSection(); ?>
<div class="row mt-3">
  <div class="col-lg-12 mx-auto">
    <div class="card">
      <div class="card-body">
        <div class="card-title">
          <h4>Worker Summary</h4>
        </div>
        <hr>
        <form id="myForm" action="<?php echo e(route('admin.workersummary')); ?>" method="GET">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-2">
              <div class="form-group">
                <label for="category">Category</label>
                <select name="category" id="category" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select category</option>
                  <option value="all" <?php echo e(request()->category == 'all' ? 'selected' : ''); ?>>ALL</option>
                  <option value="Inner" <?php echo e(request()->category == 'Inner' ? 'selected' : ''); ?>>Inner Worker</option>
                  <option value="Outter" <?php echo e(request()->category == 'Outter' ? 'selected' : ''); ?>>Outter Worker</option>
                </select>
                <?php if($errors->has('designation')): ?>
                <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-3">
              <div class="form-group">
                <label for="designation">Designation</label>
                <select name="designation" id="designation" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select designation</option>
                  <option value="all" <?php echo e(request()->designation == 'all' ? 'selected' : ''); ?>>ALL</option>
                  <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($designation->name); ?>" <?php echo e(request()->designation == $designation->name ? 'selected' : ''); ?>><?php echo e($designation->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('designation')): ?>
                <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-3">
              <div class="form-group">
                <label for="worker_name">Worker Name</label>
                <select name="worker_name" id="worker_name" class="custom-select form-control form-control-rounded" required>
                  <option value="">Select worker</option>
                  <option value="all" <?php echo e(request()->worker_name == 'all' ? 'selected' : ''); ?>>ALL</option>
                  <?php $__currentLoopData = $workerLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($workerList->fname); ?>" <?php echo e(request()->worker_name == $workerList->fname ? 'selected' : ''); ?>><?php echo e($workerList->fname); ?>&nbsp;&nbsp;<?php echo e($workerList->lname); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('party_id')): ?>
                <div class="error text-danger"><?php echo e($errors->first('party_id')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <!-- <div class="col-3">
              <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" class="form-control form-control-rounded" id="start_date" value="<?php echo e(request()->start_date); ?>" required>
                <?php if($errors->has('start_date')): ?>
                <div class="error text-danger"><?php echo e($errors->first('start_date')); ?></div>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-3">
              <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" class="form-control form-control-rounded" id="end_date" value="<?php echo e(request()->end_date); ?>" required>
                <?php if($errors->has('end_date')): ?>
                <div class="error text-danger"><?php echo e($errors->first('end_date')); ?></div>
                <?php endif; ?>
              </div>
            </div> -->
          </div>
          <div class="form-group">
            <button type="button" id="button1" class="btn btn-light btn-round px-5">Report</button>
            <button type="button" id="button2" class="btn btn-light btn-round px-5">Export Report</button>
            <a href="/admin/worker_summary" class="btn btn-light btn-round px-5">Clear</a>
          </div>
        </form>
      </div>
      <div>
        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <center>
          <h4 style="margin-top:20px"><?php echo e($worker->fname); ?>&nbsp;<?php echo e($worker->lname); ?></h4>
        </center>
        <div class="table-responsive">
          <table id="" class="table align-items-center table-flush table-borderless">
            <thead>
              <tr>
                <th>Show</th>
                <th>Party Name</th>
                <th>Diamond Name</th>
                <th>Issue Date</th>
                <th>Diamond Barcode</th>
                <th>Created Date</th>
              </tr>
            </thead>
            <tbody>
              <?php

              $workerprocess = Process::where('worker_name', $worker->fname)->where('return_weight', null)->get();
              ?>
              <?php $__currentLoopData = $workerprocess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerpro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
              $dimond = Dimond::where('barcode_number', $workerpro->dimonds_barcode)->first();
              ?>
              <tr>
                <td>
                  <a href="<?php echo e(route('admin.dimond.show', $workerpro->dimonds_barcode)); ?>"><i class="fa fa-eye" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                </td>
                <td><?php echo e($dimond->parties->fname); ?></td>
                <td><?php echo e($dimond->dimond_name); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($workerpro->issue_date)->format('d-m-Y')); ?></td>
                <td><?php echo e($workerpro->dimonds_barcode); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($dimond->created_at)->format('d-m-Y')); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>

<script>
  $(document).ready(function() {
    $('#designation').change(function() {
      var designation = $(this).val();
      if (designation == 'all') {
        $('#worker_name').append('<option value="all" selected>ALL</option>');
      } else if (designation && designation != 'all') {
        $.ajax({
          type: 'POST',
          url: '/admin/get-workers',
          data: {
            '_token': '<?php echo e(csrf_token()); ?>',
            'designation': designation,
          },
          success: function(data) {
            $('#worker_name').empty();
            $('#worker_name').append('<option value="">Select worker</option><option value="all">ALL</option>');
            $.each(data, function(key, value) {
              $('#worker_name').append('<option value="' + value.fname + '">' + value.fname + ' ' + value.lname + '</option>');
            });
          }
        });
      } else {
        $('#worker_name').empty();
      }
    });
    $('#category').change(function() {
      var category = $(this).val();
      if (category) {
        $.ajax({
          type: 'POST',
          url: '/admin/get-designation',
          data: {
            '_token': '<?php echo e(csrf_token()); ?>',
            'category': category,
          },
          success: function(data) {
            $('#designation').empty();
            $('#designation').append('<option value="">Select designation</option><option value="all">ALL</option>');
            $.each(data, function(key, value) {
              $('#designation').append('<option value="' + value.name + '">' + value.name + '</option>');
            });
          }
        });
      } else {
        $('#designation').empty();
      }
    });
  });
</script>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('myForm');
    var button1 = document.getElementById('button1');
    var button2 = document.getElementById('button2');

    button1.addEventListener('click', function() {
      // Change the form action for button 1
      if ($("#worker_name").val() == '') {
        alert("Please Select Worker");
        return false;
      }


      form.action = "<?php echo e(route('admin.workersummary')); ?>";
      // Submit the form
      form.submit();
    });

    button2.addEventListener('click', function() {
      if ($("#worker_name").val() == '') {
        alert("Please Select Worker");
        return false;
      }
      // Change the form action for button 2
      form.action = "<?php echo e(route('admin.workersummary.export')); ?>";
      // Submit the form
      form.submit();
    });
  });

  $(document).ready(function() {
    $("#workersummaryTable").DataTable({
      dom: 'Blfrtip',
      buttons: [{
          extend: 'pdf',
        },
        {
          extend: 'csv',
        },
        {
          extend: 'excel',
        }
      ]
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/foobbshh/public_html/diamondhr/resources/views/admin/reports/workersummary.blade.php ENDPATH**/ ?>