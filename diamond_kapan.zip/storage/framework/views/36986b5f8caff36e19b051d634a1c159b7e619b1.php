
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
         <h4 class="mb-sm-0 font-size-18">Edit Detail</h4>
      </div>
   </div>
</div>
<!-- end page title -->

<div class="row">
   <div class="col-xl-12">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title mb-4">Edit</h4>

            <?php echo $__env->make('includes.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo Form::model($data, ['method'=>'PATCH', 'action'=> ['AdminDiamondController@purchaseUpdate', $data->id],'files'=>true,'class'=>'form-horizontal', 'name'=>'editPurchaseform']); ?>

            <?php echo csrf_field(); ?>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Certificate #</label>
                     <input type="text" name="certi_no" id="certi_no" class="form-control" value="<?php echo e($data->certi_no); ?>" placeholder="Enter certi no" required>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Certificate Url</label>
                     <input type="text" name="Certificate_url" class="form-control" value="<?php echo e($data->Certificate_url); ?>" placeholder="Enter Certificate Url" required>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Availability</label>
                     <input type="text" name="availability" id="availability" class="form-control" placeholder="Enter ceavailability" value="<?php echo e($data->availability); ?>" required>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Return Weight</label>
                     <input type="number"
                        step="0.01"
                        name="return_weight"
                        class="form-control return-weight"
                        id="return_weight"
                        value="<?php echo e($data->return_weight); ?>"
                        max=""
                        data-issue-weight=""
                        placeholder="returm weight"
                        required>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Return Date</label>
                     <input type="date"
                        name="return_date"
                        class="form-control return-date"
                        value="<?php echo e($data->return_date); ?>"
                        min=""
                        data-issue-date=""
                        required>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Shape</label>
                     <select name="r_shape" id="r_shape" class="form-select" required>
                        <?php $__currentLoopData = $shapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($shape->shape_type); ?>" <?php echo e($shape->shape_type == $data->r_shape ? 'selected' : ''); ?>><?php echo e($shape->shape_type); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Color</label>
                     <select name="r_color" id="r_color" class="form-select" required>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($color->c_name); ?>" <?php echo e($color->c_name == $data->r_color ? 'selected' : ''); ?>><?php echo e($color->c_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Clarity</label>
                     <select name="r_clarity" id="r_clarity" class="form-select" required>
                        <?php $__currentLoopData = $clarity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($clar->name); ?>" <?php echo e($clar->name == $data->r_clarity ? 'selected' : ''); ?>><?php echo e($clar->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Polish</label>
                     <select name="r_polish" id="r_polish" class="form-select" required>
                        <?php $__currentLoopData = $polish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pol->name); ?>" <?php echo e($data->r_polish == $pol->name ? 'selected' : ''); ?>><?php echo e($pol->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Symmetry</label>
                     <select name="r_symmetry" id="r_symmetry" class="form-select" required>
                        <?php $__currentLoopData = $symmetry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($symme->name); ?>" <?php echo e($symme->name == $data->r_symmetry ? 'selected' : ''); ?>><?php echo e($symme->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Price</label>
                     <input type="number" step="0.01" name="price" id="price" value="<?php echo e($data->price); ?>" class="form-control" placeholder="Enter Price">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Total price</label>
                     <input type="number" step="0.01" name="total_price" id="total_price" value="<?php echo e($data->total_price); ?>" class="form-control" placeholder="Enter total price">
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Image Link</label>
                     <input type="text" name="image_link" class="form-control" value="<?php echo e($data->image_link); ?>" placeholder="Enter image link">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>video Link</label>
                     <input type="text" name="video_link" class="form-control" value="<?php echo e($data->video_link); ?>" placeholder="Enter video link">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Depth Percent</label>
                     <input type="number" step="0.01" name="depth_percent" value="<?php echo e($data->depth_percent); ?>" class="form-control" placeholder="Enter depth percent">
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Table Percent</label>
                     <input type="number" step="0.01" name="table_percent" value="<?php echo e($data->table_percent); ?>" class="form-control" placeholder="Enter table percent">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Fluorescence Intensity</label>
                     <input type="text" name="fluorescence_intensity" value="<?php echo e($data->fluorescence_intensity); ?>" class="form-control" placeholder="Enter fluorescence intensity">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Lab</label>
                     <input type="text" name="lab" class="form-control" value="<?php echo e($data->lab); ?>" placeholder="Enter Lab">
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Measurements</label>
                     <input type="text" name="measurements" class="form-control" value="<?php echo e($data->measurements); ?>" placeholder="Enter measurements">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>BGM</label>
                     <input type="text" name="bgm" class="form-control" value="<?php echo e($data->bgm); ?>" placeholder="None">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>H&A</label>
                     <select name="h_and_a" id="h_and_a" class="form-select">
                        <option value="No" <?php echo e($data->h_and_a == 'No' ? 'selected' : ''); ?>>No</option>
                        <option value="Yes" <?php echo e($data->h_and_a == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                     </select>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>City</label>
                     <select name="city" id="city" class="form-select" required>
                        <option value="SURAT">SURAT</option>
                     </select>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>State</label>
                     <select name="state" id="state" class="form-select" required>
                        <option value="GUJARAT">GUJARAT</option>
                     </select>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Country</label>
                     <select name="country" id="country" class="form-select">
                        <option value="India">India</option>
                     </select>
                  </div>
               </div>
            </div>


            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Eye Clean</label>
                     <select name="eye_clean" id="eye_clean" class="form-select">
                        <option value="Yes" <?php echo e($data->eye_clean == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                        <option value="No" <?php echo e($data->eye_clean == 'No' ? 'selected' : ''); ?>>No</option>
                     </select>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label>Growth Type</label>
                     <input type="text" name="growth_type" class="form-control" value="<?php echo e($data->growth_type); ?>" placeholder="CVD">
                  </div>
               </div>
            </div>

            <div class="d-flex gap-2">
               <button type="submit" class="btn btn-primary w-md">Update</button>
               <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/purchase')); ?>">Back</a>
            </div>
            </form>
         </div>
         <!-- end card body -->
      </div>
      <!-- end card -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $('#return_weight, #price').on('input', function() {
      let weight = parseFloat($('#return_weight').val()) || 0;
      let price = parseFloat($('#price').val()) || 0;

      $('#total_price').val((weight * price).toFixed(2));
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\diamond_kapan\resources\views/admin/diamond/purchase_edit.blade.php ENDPATH**/ ?>