<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Print Slip</title>
  <style>
    p {
      font-size: 8px;
      font-family: Arial, Helvetica, sans-serif;
      margin-left: 27px;
    }

    .barcode-container {
      margin-left: 30px;
      margin-top: -10px;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }

    .barcode {
      width: 80px;
      height: 50px;
    }

    @media  print {
      .no-print {
        display: none;
      }
    }
  </style>
</head>

<body>
  <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
  <script>
    const diamondData = [{
        name: 'Diamond 1',
        weight: '1.5g',
        barcode_number: '123456789012'
      },
      {
        name: 'Diamond 2',
        weight: '2.0g',
        barcode_number: '987654321098'
      },
      {
        name: 'Diamond 1',
        weight: '1.5g',
        barcode_number: '123456789012'
      },
      {
        name: 'Diamond 2',
        weight: '2.0g',
        barcode_number: '987654321098'
      },
      {
        name: 'Diamond 2',
        weight: '2.0g',
        barcode_number: '987654321098'
      },
      {
        name: 'Diamond 2',
        weight: '2.0g',
        barcode_number: '987654321098'
      },
      {
        name: 'Diamond 2',
        weight: '2.0g',
        barcode_number: '987654321098'
      }

      // Add more diamonds as needed
    ];

    window.onload = function() {
      diamondData.forEach((diamond, index) => {
        generateBarcode(diamond.barcode_number, index);
      });
    };

    function generateBarcode(value, index) {
      const barcodeDiv = document.createElement('div');
      barcodeDiv.className = 'barcode-container';

      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.className = 'barcode';
      svg.id = `barcode${index}`;

      const info = document.createElement('p');
      info.innerHTML = `<b>SID: ${diamondData[index].name}&nbsp;|&nbsp;RW: ${diamondData[index].weight}</b>`;

      const label = document.createElement('p');
      label.style.fontSize = '8px';
      label.style.marginTop = '-10px';
      label.style.marginLeft = '40px';
      label.innerText = 'DI Diamond';

      barcodeDiv.appendChild(info);
      barcodeDiv.appendChild(svg);
      barcodeDiv.appendChild(label);
      document.body.appendChild(barcodeDiv);

      JsBarcode(svg, value, {
        format: "CODE128",
        displayValue: true,
        height: 100,
        width: 4,
        fontOptions: "bold",
        fontSize: 40,
      });
    }
  </script>

  <button class="no-print" onclick="window.print()">Print</button>
</body>

</html>



<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Print Slip</title>
  <style>
    p {
      font-size: 6px;
      font-family: Arial, Helvetica, sans-serif;
      margin-left: 35px;
    }

    #barcode {
      width: 80px;
      height: 50px;
    }

    @media  print {
      .no-print {
        display: none;
      }
    }
  </style>
</head>

<body>
  <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
  <script>
    window.onload = function() {
      generateBarcode('<?php echo e($dimond->barcode_number); ?>');
    };
  </script>
  <div>
    <p><b>SID: <?php echo e($dimond->dimond_name); ?>&nbsp;|&nbsp;RW: <?php echo e($dimond->weight); ?></b></p>
    <div style="margin-left:30px;margin-top:-10px"><svg id="barcode"></svg></div>
    <p style="font-size:8px;margin-top:-10px;margin-left:40px">DI Diamond</p>
  </div>
  <button class="no-print" onclick="window.print()">Print</button>

  <script>
    function generateBarcode(value) {
      JsBarcode("#barcode", value, {
        format: "CODE128",
        displayValue: true,
        height: 100,
        width: 4,
        fontOptions: "bold",
        fontSize: 40,
      });
    }
  </script>
</body>

</html> --><?php /**PATH E:\CHINTANSIR\diamondtwo_github\resources\views/admin/dimond/pdfView.blade.php ENDPATH**/ ?>