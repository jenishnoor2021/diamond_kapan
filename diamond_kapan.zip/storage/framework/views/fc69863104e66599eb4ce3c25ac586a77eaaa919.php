<?php

use App\Models\Process;
?>

<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Diamond List</h4>

            <!-- <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                    <li class="breadcrumb-item active">Diamond List</li>
                </ol>
            </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <div id="right">
                    <div id="menu" class="mb-3">

                        <span id="menu-navi"
                            class="d-sm-flex flex-wrap text-center text-sm-start justify-content-sm-between">
                            <div class="gap-1">
                                <a class="btn btn-info waves-effect waves-light" href="<?php echo e(route('admin.dimond.create')); ?>">
                                    <i class="fa fa-plus editable" style="font-size:15px;">&nbsp;ADD</i>
                                </a>
                                <a class="btn btn-primary waves-effect waves-light" href="<?php echo e(route('admin.dimond.import')); ?>" style="font-size:15px;">
                                    Import
                                </a>
                            </div>

                            <h4 id="renderRange" class="render-range fw-bold pt-1 mx-3">
                                <form method="GET" action="<?php echo e(route('dimond.detail')); ?>" class="mx-auto">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" id="inputField1" class="form-control" name="inputField"
                                        placeholder="Search barcode" required>
                                </form>
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($error); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                            </h4>

                            <div class="align-self-start mt-3 mt-sm-0 mb-2">
                            </div>
                        </span>

                    </div>
                </div>

                <table id="datatable" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>PArty Name</th>
                            <th>Dimond Name</th>
                            <th>Row Weight</th>
                            <th>Polished Weight</th>
                            <th>Barcode</th>
                            <!-- <th>Barcode show</th> -->
                            <th>Detail</th>
                            <th>Status</th>
                            <th>Process</th>
                            <!-- <th>Shap</th>
                                     <th>clarity</th>
                                     <th>color</th>
                                     <th>cut</th>
                                     <th>polish</th>
                                     <th>symmetry</th> -->
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $dimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $process = Process::where('dimonds_id', $dimond->id)->latest()->first();
                        $designation = isset($process) ? $process->designation : '';
                        ?>
                        <tr>
                            <td>
                                <a href="/admin/print-image/<?php echo e($dimond->id); ?>" target="_blank"
                                    class="btn btn-primary">Print</a>
                                <a href="<?php echo e(route('admin.dimond.show', $dimond->barcode_number)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('admin.dimond.edit', $dimond->id)); ?>" class="btn btn-outline-primary waves-effect waves-light"><i class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.dimond.destroy', $dimond->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');" class="btn btn-outline-danger waves-effect waves-light"><i class="fa fa-trash"></i></a>
                            </td>
                            <td><?php echo e($dimond->parties->party_code); ?></td>
                            <td><?php echo e($dimond->dimond_name); ?></td>
                            <td><?php echo e($dimond->weight); ?></td>
                            <td><?php echo e($dimond->required_weight); ?></td>
                            <td><?php echo $dimond->barcode_number; ?></td>
                            <!-- <td><svg id="barcode_<?php echo e($index); ?>" style="display:none"></svg>
                                    <button id="<?php echo e($index); ?>" onclick="getbarcode(this.id,<?php echo $dimond->barcode_number; ?>)">show</button>
                                 </td> -->
                            <td>
                                <div id="animalstatus<?php echo e($dimond->id); ?>" onclick="addappdata(this.id)"
                                    style="border:0px solid;"><i class="fa fa-plus-circle mt-2 text-warning"
                                        aria-hidden="true"></i>show
                                </div>
                                <div id="showsolddetailsanimalstatus<?php echo e($dimond->id); ?>" style="display:none">
                                    <p><span class="text-warning">Shap :</span> <?php echo e($dimond->shape); ?></p>
                                    <p><span class="text-warning">clarity :</span> <?php echo e($dimond->clarity); ?></p>
                                    <p><span class="text-warning">color :</span> <?php echo e($dimond->color); ?></p>
                                    <p><span class="text-warning">cut :</span> <?php echo e($dimond->cut); ?></p>
                                    <p><span class="text-warning">polish :</span> <?php echo e($dimond->polish); ?></p>
                                    <p><span class="text-warning">symmetry :</span> <?php echo e($dimond->symmetry); ?></p>
                                </div>
                            </td>
                            <td><?php echo $dimond->status; ?></td>
                            <td><?php echo e($designation); ?></td>
                            <!-- <td><?php echo e($dimond->shape); ?></td>
                                            <td><?php echo e($dimond->clarity); ?></td>
                                            <td><?php echo e($dimond->color); ?></td>
                                            <td><?php echo e($dimond->cut); ?></td>
                                            <td><?php echo e($dimond->polish); ?></td>
                                            <td><?php echo e($dimond->symmetry); ?></td> -->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function getbarcode(index, value) {
        document.getElementById('barcode_' + index).style.display = "block";
        JsBarcode("#barcode_" + index, value, {
            format: "CODE128",
            displayValue: true,
            height: 100,
            width: 4,
            fontOptions: "bold",
            fontSize: 40,
        });
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-focus on the input field when the page loads
        document.getElementById('inputField1').focus();
    });

    function addappdata(cli_id) {
        // $("#showsolddetails"+cli_id).show();
        var div = document.getElementById("showsolddetails" + cli_id);
        if (div.style.display !== "block") {
            div.style.display = "block";
        } else {
            div.style.display = "none";
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template\resources\views/admin/dimond/index.blade.php ENDPATH**/ ?>