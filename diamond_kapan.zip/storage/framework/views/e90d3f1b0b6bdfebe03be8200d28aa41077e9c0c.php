
<?php $__env->startSection('style'); ?>
<style>
   form {
      width: 300px;
      padding: 20px;
      border-radius: 5px;
   }

   input {
      width: 100%;
      padding: 2px;
      margin-bottom: 16px;
      box-sizing: border-box;
      background-color: transparent;
      color: white
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <?php if(session('success')): ?>
         <div class="alert text-white pl-3 pt-2 pb-2" style="background-color:green">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
         <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Dimond List</h4>
            <div class="flex">
               <form method="GET" action="<?php echo e(route('dimond.detail')); ?>" class="mx-auto">
                  <?php echo csrf_field(); ?>
                  <input type="text" id="inputField" name="inputField" placeholder="Search barcode" required>
               </form>
               <?php if($errors->any()): ?>
               <div class="alert alert-danger">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <p><?php echo e($error); ?></p>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
               <?php endif; ?>
            </div>

            <div class="card-action">
               <div class="dropdown-menu-right">
                  <a class="dropdown-item" style="background-color:darkorchid;" href="<?php echo e(route('admin.dimond.create')); ?>">
                     <i class="fa fa-plus editable" style="font-size:15px;">&nbsp;ADD</i>
                  </a>
               </div>
            </div>
         </div>
         <div class="table-responsive">
            <table id="dimondtable" class="table align-items-center table-flush table-borderless">
               <thead>
                  <tr>
                     <th>Action</th>
                     <th>PArty Name</th>
                     <th>Dimond Name</th>
                     <th>Row Weight</th>
                     <th>Polished Weight</th>
                     <th>Barcode</th>
                     <!-- <th>Barcode show</th> -->
                     <th>Detail</th>
                     <th>Status</th>
                     <!-- <th>Shap</th>
                     <th>clarity</th>
                     <th>color</th>
                     <th>cut</th>
                     <th>polish</th>
                     <th>symmetry</th> -->
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php $__currentLoopData = $dimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <td>
                        <a href="/admin/print-image/<?php echo e($dimond->id); ?>" target="_blank" class="btn btn-secondary">Print</a>
                        <a href="<?php echo e(route('admin.dimond.show', $dimond->barcode_number)); ?>"><i class="fa fa-eye" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                        <a href="<?php echo e(route('admin.dimond.edit', $dimond->id)); ?>"><i class="fa fa-edit" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                        <a href="<?php echo e(route('admin.dimond.destroy', $dimond->id)); ?>" onclick="return confirm('Sure ! You want to delete ?');"><i class="fa fa-trash" style="color:white;font-size:15px;background-color:rgba(255, 255, 255, 0.25);padding:8px;"></i></a>
                     </td>
                     <td><?php echo e($dimond->parties->party_code); ?></td>
                     <td><?php echo e($dimond->dimond_name); ?></td>
                     <td><?php echo e($dimond->weight); ?></td>
                     <td><?php echo e($dimond->required_weight); ?></td>
                     <td><?php echo $dimond->barcode_number; ?></td>
                     <!-- <td><svg id="barcode_<?php echo e($index); ?>" style="display:none"></svg>
                        <button id="<?php echo e($index); ?>" onclick="getbarcode(this.id,<?php echo $dimond->barcode_number ?>)">show</button>
                     </td> -->
                     <td>
                        <div id="animalstatus<?php echo e($dimond->id); ?>" onclick="addappdata(this.id)" style="border:0px solid;"><i class="fa fa-plus-circle mt-2 text-warning" aria-hidden="true"></i>show
                        </div>
                        <div id="showsolddetailsanimalstatus<?php echo e($dimond->id); ?>" style="display:none">
                           <p><span class="text-warning">Shap :</span> <?php echo e($dimond->shape); ?></p>
                           <p><span class="text-warning">clarity :</span> <?php echo e($dimond->clarity); ?></p>
                           <p><span class="text-warning">color :</span> <?php echo e($dimond->color); ?></p>
                           <p><span class="text-warning">cut :</span> <?php echo e($dimond->cut); ?></p>
                           <p><span class="text-warning">polish :</span> <?php echo e($dimond->polish); ?></p>
                           <p><span class="text-warning">symmetry :</span> <?php echo e($dimond->symmetry); ?></p>
                        </div>
                     </td>
                     <td><?php echo $dimond->status; ?></td>
                     <!-- <td><?php echo e($dimond->shape); ?></td>
                     <td><?php echo e($dimond->clarity); ?></td>
                     <td><?php echo e($dimond->color); ?></td>
                     <td><?php echo e($dimond->cut); ?></td>
                     <td><?php echo e($dimond->polish); ?></td>
                     <td><?php echo e($dimond->symmetry); ?></td> -->
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div><!--End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   function getbarcode(index, value) {
      document.getElementById('barcode_' + index).style.display = "block";
      JsBarcode("#barcode_" + index, value, {
         format: "CODE128",
         displayValue: true,
         height: 100,
         width: 4,
         fontOptions: "bold",
         fontSize: 40,
      });
   }
</script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
<script>
   document.addEventListener('DOMContentLoaded', function() {
      // Auto-focus on the input field when the page loads
      document.getElementById('inputField').focus();
   });

   function addappdata(cli_id) {
      // $("#showsolddetails"+cli_id).show();
      var div = document.getElementById("showsolddetails" + cli_id);
      if (div.style.display !== "block") {
         div.style.display = "block";
      } else {
         div.style.display = "none";
      }
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\dimond\resources\views/admin/dimond/index.blade.php ENDPATH**/ ?>