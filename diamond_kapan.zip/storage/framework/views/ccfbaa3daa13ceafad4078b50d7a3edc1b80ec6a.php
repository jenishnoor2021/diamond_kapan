
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
   <div class="col-12">
      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
         <h4 class="mb-sm-0 font-size-18">Edit Worker</h4>

         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="javascript: void(0);">Worker</a></li>
               <li class="breadcrumb-item active">Edit Worker</li>
            </ol>
         </div>

      </div>
   </div>
</div>
<!-- end page title -->

<div class="row">
   <div class="col-xl-12">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title mb-4">Edit</h4>

            <?php echo Form::model($worker, ['method'=>'PATCH', 'action'=> ['AdminWorkerController@update', $worker->id],'files'=>true,'class'=>'form-horizontal','name'=>'editworkerform']); ?>

            <?php echo csrf_field(); ?>
            <div class="row">
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="fname">First Name</label>
                     <input type="text" name="fname" class="form-control" id="fname" placeholder="Enter First name" onkeypress='return (event.charCode != 32)' value="<?php echo e($worker->fname); ?>" required>
                     <?php if($errors->has('fname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('fname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="lname">Last Name</label>
                     <input type="text" name="lname" class="form-control" id="lname" placeholder="Enter Last Name" onkeypress='return (event.charCode != 32)' value="<?php echo e($worker->lname); ?>" required>
                     <?php if($errors->has('lname')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('lname')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="mb-3">
                     <label for="designation">Designation</label>
                     <select name="designation" id="designation" class="form-select" required>
                        <option value="">Select designation</option>
                        <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designation->name); ?>" <?php echo e($worker->designation == $designation->name ? "selected" : ''); ?>><?php echo e($designation->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                     <?php if($errors->has('designation')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('designation')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="mb-3">
               <label for="remark">Remark / katori</label>
               <textarea type="text" name="remark" class="form-control" id="remark" placeholder="Enter remark"><?php echo e($worker->remark); ?></textarea>
               <?php if($errors->has('remark')): ?>
               <div class="error text-danger"><?php echo e($errors->first('remark')); ?></div>
               <?php endif; ?>
            </div>

            <div class="mb-3">
               <label for="address">Address</label>
               <textarea type="text" name="address" class="form-control" id="address" placeholder="Enter Address"><?php echo e($worker->address); ?></textarea>
               <?php if($errors->has('address')): ?>
               <div class="error text-danger"><?php echo e($errors->first('address')); ?></div>
               <?php endif; ?>
            </div>

            <div class="row">
               <div class="col-lg-4">
                  <div class="mb-3">
                     <label for="mobile">Mobile no</label>
                     <input type="number" name="mobile" class="form-control" id="mobile" placeholder="Enter number" value="<?php echo e($worker->mobile); ?>">
                     <?php if($errors->has('mobile')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('mobile')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="mb-3">
                     <label for="aadhar_no">Aadhar Number</label>
                     <input type="text" name="aadhar_no" class="form-control" id="aadhar_no" placeholder="Enter aadhar no" oninput="formatAadharInput(this)" value="<?php echo e($worker->aadhar_no); ?>">
                     <?php if($errors->has('aadhar_no')): ?>
                     <div class="error text-danger"><?php echo e($errors->first('aadhar_no')); ?></div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>

            <div class="mb-3">
               <div class="form-check">
                  <label class="form-check-label" for="roundCheckbox">
                     <input class="form-check-input" type="checkbox" id="roundCheckbox">
                     Round Rate
                  </label>
               </div>
            </div>

            <div id="roundDiv" style="display: none;">
               <div class="row">
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="round_1">Rate (0.00 to 1.99)</label>
                        <input type="number" name="round_1" class="form-control" id="round_1" placeholder="Enter amount" value="<?php echo e($worker->round_1); ?>">
                        <?php if($errors->has('round_1')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('round_1')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="round_2">Rate (2.00 to 4.99)</label>
                        <input type="number" name="round_2" class="form-control" id="round_2" placeholder="Enter amount" value="<?php echo e($worker->round_2); ?>">
                        <?php if($errors->has('round_2')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('round_2')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="round_3">Rate (5.00 to more)</label>
                        <input type="number" name="round_3" class="form-control" id="round_3" placeholder="Enter amount" value="<?php echo e($worker->round_3); ?>">
                        <?php if($errors->has('round_3')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('round_3')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>

            <div class="mb-3">
               <div class="form-check">
                  <label class="form-check-label" for="fancyCheckbox">
                     <input class="form-check-input" type="checkbox" id="fancyCheckbox">
                     Fancy Rate
                  </label>
               </div>
            </div>

            <div id="fancyDiv" style="display: none;">
               <div class="row">
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_0">Rate (0.00 to 0.99)</label>
                        <input type="number" name="fancy_0" class="form-control" id="fancy_0" placeholder="Enter amount" value="<?php echo e($worker->fancy_0); ?>">
                        <?php if($errors->has('fancy_0')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_0')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_1">Rate (1.00 to 1.49)</label>
                        <input type="number" name="fancy_1" class="form-control" id="fancy_1" placeholder="Enter amount" value="<?php echo e($worker->fancy_1); ?>">
                        <?php if($errors->has('fancy_1')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_1')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_2">Rate (1.50 to 1.99)</label>
                        <input type="number" name="fancy_2" class="form-control" id="fancy_2" placeholder="Enter amount" value="<?php echo e($worker->fancy_2); ?>">
                        <?php if($errors->has('fancy_2')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_2')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_3">Rate (2.00 to 2.99)</label>
                        <input type="number" name="fancy_3" class="form-control" id="fancy_3" placeholder="Enter amount" value="<?php echo e($worker->fancy_3); ?>">
                        <?php if($errors->has('fancy_3')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_3')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_4">Rate (3.00 to 3.99)</label>
                        <input type="number" name="fancy_4" class="form-control" id="fancy_4" placeholder="Enter amount" value="<?php echo e($worker->fancy_4); ?>">
                        <?php if($errors->has('fancy_4')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_4')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_5">Rate (4.00 to 4.99)</label>
                        <input type="number" name="fancy_5" class="form-control" id="fancy_5" placeholder="Enter amount" value="<?php echo e($worker->fancy_5); ?>">
                        <?php if($errors->has('fancy_5')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_5')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_6">Rate (5.00 to 9.99)</label>
                        <input type="number" name="fancy_6" class="form-control" id="fancy_6" placeholder="Enter amount" value="<?php echo e($worker->fancy_6); ?>">
                        <?php if($errors->has('fancy_6')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_6')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="fancy_7">Rate (10.00 to more)</label>
                        <input type="number" name="fancy_7" class="form-control" id="fancy_7" placeholder="Enter amount" value="<?php echo e($worker->fancy_7); ?>">
                        <?php if($errors->has('fancy_7')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('fancy_7')); ?></div>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>

            <div class="mb-3">
               <div class="form-check">
                  <label class="form-check-label" for="myCheckbox">
                     <input class="form-check-input" type="checkbox" id="myCheckbox">
                     Add Bank detail
                  </label>
               </div>
            </div>

            <div id="myDiv" style="display: none;">
               <div class="row">
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="bank_name">Bank name</label>
                        <input type="text" name="bank_name" class="form-control" id="bank_name" placeholder="Enter bank name" value="<?php echo e($worker->bank_name); ?>">
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="ifsc_code">IFSC code</label>
                        <input type="text" name="ifsc_code" class="form-control" id="ifsc_code" placeholder="Enter IFSC code" value="<?php echo e($worker->ifsc_code); ?>">
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="account_holder_name">Account Holder name</label>
                        <input type="text" name="account_holder_name" class="form-control" id="account_holder_name" placeholder="Enter Account Holder name" value="<?php echo e($worker->account_holder_name); ?>">
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="mb-3">
                        <label for="account_no">Account Number</label>
                        <input type="number" name="account_no" class="form-control" id="account_no" placeholder="Enter Account number" value="<?php echo e($worker->account_no); ?>">
                     </div>
                  </div>
               </div>
            </div>

            <div class="d-flex gap-2">
               <button type="submit" class="btn btn-primary w-md">Update</button>
               <a class="btn btn-light w-md" href="<?php echo e(URL::to('/admin/worker')); ?>">Back</a>
            </div>
            </form>
         </div>
         <!-- end card body -->
      </div>
      <!-- end card -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
   $(function() {

      $("form[name='editworkerform']").validate({
         rules: {
            fname: {
               required: true,
            },
            lname: {
               required: true,
            },
            // address: {
            //    required: true,
            // },
            // mobile: {
            //    required: true,
            // },
            designation: {
               required: true,
            },
            // aadhar_no: {
            //    required: true,
            // }
         },
         submitHandler: function(form) {
            form.submit();
         }
      });
   });
</script>
<script>
   document.addEventListener('DOMContentLoaded', function() {
      var checkbox = document.getElementById('myCheckbox');
      var div = document.getElementById('myDiv');

      var roundcheckbox = document.getElementById('roundCheckbox');
      var rounddiv = document.getElementById('roundDiv');

      var fancycheckbox = document.getElementById('fancyCheckbox');
      var fancydiv = document.getElementById('fancyDiv');

      checkbox.addEventListener('change', function() {
         div.style.display = checkbox.checked ? 'block' : 'none';
      });

      roundcheckbox.addEventListener('change', function() {
         rounddiv.style.display = roundcheckbox.checked ? 'block' : 'none';
      });

      fancycheckbox.addEventListener('change', function() {
         fancydiv.style.display = fancycheckbox.checked ? 'block' : 'none';
      });
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/worker/edit.blade.php ENDPATH**/ ?>