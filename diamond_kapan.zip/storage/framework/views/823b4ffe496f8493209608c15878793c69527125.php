<?php

use Carbon\Carbon;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expanse Report</title>
    <link href="<?php echo e(asset('assets/css/pdfCss.css')); ?>" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="container">
        <center>
            <h4>Expanse Report</h4>
            <h1 style="margin-top:-10px">DHYANI IMPEX</h1>
            <p style="font-size:10px;margin-top:-12px">E-102, FIRST FLOOR, Happyness Residency, BEHIND S HRUSHTI ROW
                HOUSE,<br /> Surat Surat, GUJARAT, 394107</p>
        </center>
        <div class="row">
            <div class="column-left">
                <div class="d-flex align-items-center justify-content-center">
                    <p><strong class="align-center title">Bill
                            Date:</strong><?php echo e(\Carbon\Carbon::parse(Carbon::now())->format('d-m-Y H:i:s')); ?></p>
                </div>
            </div>
            <div class="column-right">
            </div>
            <div style="clear: both;"></div>
            <!-- Rest of your code ... -->
            <!-- Content for the center and table -->
        </div>
        <br />
        <table>
            <thead>
                <tr>
                    <th>Sr.</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th width="20%">Amount</th>
                </tr>
            </thead>
            <?php
                $sum = 0;
            ?>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('d-m-Y')); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <?php
                            $sum += $item->amount;
                        ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3">
                        <b>
                            <h4>Total Amount</h4>
                        </b>
                    </td>
                    <td>
                        <b>
                            <h4><?php echo e($sum); ?></h4>
                        </b>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/expense/expense-pdf-template.blade.php ENDPATH**/ ?>