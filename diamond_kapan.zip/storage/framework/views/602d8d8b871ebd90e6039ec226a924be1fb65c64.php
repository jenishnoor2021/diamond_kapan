<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
  /* Loader overlay only for content area */
  .loader-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0,0,0,.2);
          z-index: 9999;
          display: flex;
          align-items: center;
          justify-content: center;
      }

      .loader-overlay.hidden {
          display: none;
      }

      .loader {
          border: 5px solid #f3f3f3;
          border-top: 5px solid #3498db;
          border-radius: 50%;
          width: 50px;
          height: 50px;
          animation: spin 1s linear infinite;
      }

      @keyframes  spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
      }
</style>
</head>

<body class="bg-theme bg-theme1">

  <!-- start loader -->
  <!-- <div id="pageloader-overlay" class="visible incoming">
    <div class="loader-wrapper-outer">
      <div class="loader-wrapper-inner">
        <div class="loader"></div>
      </div>
    </div>
  </div> -->
  <!-- end loader -->

  <!-- Start wrapper-->
  <div id="wrapper">

    <!--Start sidebar-wrapper-->
    <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
      <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!--End sidebar-wrapper-->

    <!--Start topbar header-->
    <header class="topbar-nav">
      <?php echo $__env->make('includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <!--End topbar header-->

    <div class="clearfix"></div>

    <div class="content-wrapper" style="position: relative;">
      <div class="container-fluid">

         <!-- Loader specific to the content area -->
         <div id="content-loader" class="loader-overlay hidden">
          <div class="loader"></div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
      </div>
      <!-- End container-fluid-->
    </div><!--End content-wrapper-->

    <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\diamondhr\resources\views/layouts/admin.blade.php ENDPATH**/ ?>