
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">Diamond Slip</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                        <li class="breadcrumb-item active">Diamond Slip</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-check-all me-2"></i>
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-block-helper me-2"></i>
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.diamondslip')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <div data-repeater-list="group-a">
                            <div data-repeater-item class="row">
                                <div class="mb-3 col-lg-2">
                                    <label for="party_id">Party Name</label>
                                    <select name="party_id" id="party_id" class="form-select" required>
                                        <option value="">Select party</option>
                                        <option value="All" <?php echo e(request()->party_id == 'All' ? 'selected' : ''); ?>>ALL
                                        </option>
                                        <?php $__currentLoopData = $partyLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($partyList->id); ?>"
                                                <?php echo e(request()->party_id == $partyList->id ? 'selected' : ''); ?>>
                                                <?php echo e($partyList->fname); ?>&nbsp;&nbsp;<?php echo e($partyList->lname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('party_id')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('party_id')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="start_date">Start Date:</label>
                                    <input type="date" name="start_date" class="form-control" id="start_date"
                                        value="<?php echo e(request()->start_date); ?>">
                                    <?php if($errors->has('start_date')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('start_date')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3 col-lg-2">
                                    <label for="end_date">End Date:</label>
                                    <input type="date" name="end_date" class="form-control" id="end_date"
                                        value="<?php echo e(request()->end_date); ?>">
                                    <?php if($errors->has('end_date')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('end_date')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="col-lg-2 align-self-center">
                                    <div class="d-flex gap-2">
                                        <input type="submit" class="btn btn-success w-md" value="Submit" />
                                        <a class="btn btn-light w-md" href="/admin/dimond_slip">Clear</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>

            <?php if(count($dimonds) > 0): ?>
                <div class="card">
                    <div class="card-body">

                        <table id="" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                            <thead>
                                <tr>
                                    <th>Select</th>
                                    <th>Dimond Name</th>
                                    <th>Row Weight</th>
                                    <th>Polished Weight</th>
                                    <!-- <th>Barcode</th> -->
                                    <!-- <th>Status</th> -->
                                    <th>Shap</th>
                                    <th>clarity</th>
                                    <th>color</th>
                                    <!-- <th>cut</th> -->
                                    <!-- <th>polish</th> -->
                                    <!-- <th>symmetry</th> -->
                                    <th>Deliverd</th>
                                </tr>
                            </thead>
                            <form id="checkboxForm" action="<?php echo e(route('admin.diamondslippdf')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-warning waves-effect waves-light">Generate
                                    PDF</button>
                                <input type="hidden" id="selectedIds" name="selectedIds">

                                <tbody>
                                    <?php $__currentLoopData = $dimonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dimond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" id="parties_id" name="parties_id"
                                            value="<?php echo e($dimond->parties_id); ?>">

                                        <tr>
                                            <td><input type="checkbox" class="checkbox form-check-input" name="selected[]"
                                                    value="<?php echo e($dimond->id); ?>"></td>
                                            <td><?php echo e($dimond->dimond_name); ?></td>
                                            <td><?php echo e($dimond->weight); ?></td>
                                            <td><?php echo e($dimond->required_weight); ?></td>
                                            <!-- <td><?php echo $dimond->barcode_number; ?></td> -->
                                            <!-- <td><?php echo $dimond->status; ?></td> -->
                                            <td><?php echo e($dimond->shape); ?></td>
                                            <td><?php echo e($dimond->clarity); ?></td>
                                            <td><?php echo e($dimond->color); ?></td>
                                            <!-- <td><?php echo e($dimond->cut); ?></td> -->
                                            <!-- <td><?php echo e($dimond->polish); ?></td> -->
                                            <!-- <td><?php echo e($dimond->symmetry); ?></td> -->
                                            <td><?php echo e(\Carbon\Carbon::parse($dimond->delevery_date)->format('d-m-Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </form> 
                        </table>

                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var selectedIds = [];

            var checkboxes = document.querySelectorAll('.checkbox');

            checkboxes.forEach(function(checkbox) {
                checkbox.addEventListener('change', function() {
                    if (this.checked) {
                        selectedIds.push(this.value);
                    } else {
                        var index = selectedIds.indexOf(this.value);
                        if (index !== -1) {
                            selectedIds.splice(index, 1);
                        }
                    }

                    document.getElementById('selectedIds').value = selectedIds.join(',');
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\admin-dia-chi-template\resources\views/admin/reports/diamondslip.blade.php ENDPATH**/ ?>