
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Worker Barcode</h4>

            <!-- <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                        <li class="breadcrumb-item active">Worker Barcode</li>
                    </ol>
                </div> -->

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">
                    Generate Worker Barcode
                </h4>

                <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session()->get('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <?php echo Form::open([
                'method' => 'POST',
                'action' => 'AdminWorkerBarcodeController@store',
                'files' => true,
                'class' => 'form-horizontal',
                'name' => 'workerbarcodeform',
                ]); ?>

                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="mb-3">
                        <label for="category">Worker List</label>
                        <select name="worker_id" id="worker_id" class="form-select" required>
                            <option value="">Select worker</option>
                            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->fname); ?> <?php echo e($worker->lname); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('worker_id')): ?>
                        <div class="error text-danger"><?php echo e($errors->first('worker_id')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div>
                        <button type="submit" class="btn btn-primary w-md">Submit</button>
                    </div>

                </div>
                </form>

            </div>
        </div>
    </div> <!-- end col -->

    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">Worker Barcode List</h4>

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="mdi mdi-check-all me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <table id="workerbarcodelist" class="table table-bordered dt-responsive nowrap w-100 mt-3">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Print</th>
                            <th>Worker Name</th>
                            <th>Barcode</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $barcodeLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcodeList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.worker-barcode.edit', $barcodeList->id)); ?>"
                                    class="btn btn-outline-primary waves-effect waves-light"><i
                                        class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.worker-barcode.destroy', $barcodeList->id)); ?>"
                                    onclick="return confirm('Sure ! You want to delete ?');"
                                    class="btn btn-outline-danger waves-effect waves-light"><i
                                        class="fa fa-trash"></i></a>
                            </td>
                            <td>
                                <a href="/admin/print-worker-barcode/<?php echo e($barcodeList->id); ?>" target="_blank"
                                    class="btn btn-outline-info waves-effect waves-light">Print</a>
                            </td>
                            <td><?php echo e($barcodeList->worker->fname); ?>&nbsp;<?php echo e($barcodeList->worker->lname); ?></td>
                            <td><?php echo e($barcodeList->barcode); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->

</div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function() {
        $("form[name='workerbarcodeform']").validate({
            rules: {
                worker_id: {
                    required: true,
                },
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CHINTANSIR\admin-diamond-chintbhai-template_github\resources\views/admin/worker_barcode/index.blade.php ENDPATH**/ ?>